<?php 
session_start();
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php");
VerifTempsLog();

if(isset($_GET['id']) and isset($_GET['typdm'])){
	$IdDmd0 = (int)$_GET['id'];
	$typdm  = (int)$_GET['typdm'];//Le type de demande: 1:interne et 0:location
}
if($typdm==1){//demande interne
    $chp = "dmddet_id, outilref_id, outilref_libelle,outilref_ref, outilref_descrip, dmddet_etat_enreg, dmddet_etat_acc, dmddet_etat_traite, outilref_etat_mvt";
	$tbl = DEMANDES_DET." LEFT JOIN ".OUTILS_REF." ON dmddet_outils=outilref_id";
	$cnd = "dmddet_dmdid=$IdDmd0 AND dmddet_etat_enreg=1";
	$reqDet = selections($chp,$tbl,$cnd,"dmddet_id DESC");
	$resDet = $pdo->query($reqDet);
?>
    <tbody>
        <?php 
        $i = 0;
        while($col = $resDet->fetch()){
          $dmddet_id 		 	= $col['dmddet_id'];
		  $dmddet_outils 	 	= $col['outilref_id'];
		  $outil_libelle 	 	= $col['outilref_libelle'];
		  $outilref_ref			= $col['outilref_ref'];
		  $outilref_descrip		= $col['outilref_descrip'];
		  $dmddet_etat_enreg 	= $col['dmddet_etat_enreg'];
		  $dmddet_etat_acc		= $col['dmddet_etat_acc'];
		  $dmddet_etat_traite	= $col['dmddet_etat_traite'];
		  $outilref_etat_mvt	= $col['outilref_etat_mvt'];
		  
          $i++;
        ?>
        <tr class="even gradeA" data-numligne="<?php echo $i; ?>">
          <td align="left"><?php echo $outil_libelle; ?></td>
          <td align="left"><?php echo nl2br($outilref_descrip); ?>
            <input id="IdDmd_<?php echo $i; ?>" name="IdDmd_<?php echo $i; ?>" value="<?php echo $IdDmd0; ?>" type="hidden">
            <input id="IdDetDmd_<?php echo $i; ?>" name="IdDetDmd_<?php echo $i; ?>" value="<?php echo $dmddet_id; ?>" type="hidden">
            <input id="IdOutil_<?php echo $i; ?>" name="IdOutil_<?php echo $i; ?>" value="<?php echo $dmddet_outils; ?>" type="hidden">
          </td>
            <td align="left"><?php echo $outilref_ref;?></td>
            <td align="center">
              <?php if($outilref_etat_mvt==0){?>
              <button class="btn btn-link"><i class="fa fa-warning fa-sm text-orange" title="L'outil n'est plus disponible !"></i></button>
              <button class="btn btn-link ButtonValideTraiteDmdIntRejet" data-rep="2" data-toggle="tooltip" data-placement="top" title="Rej&eacute;ter"><i class="fa fa-times fa-sm text-rouge"></i></button>
              <?php }elseif($dmddet_etat_acc==0){?>
              <button class="btn btn-link ButtonValideTraiteDmdIntAccord" data-rep="1" data-toggle="tooltip" data-placement="top" title="Valider"><i class="fa fa-check fa-sm text-vert"></i></button>
              <button class="btn btn-link ButtonValideTraiteDmdIntRejet" data-rep="2" data-toggle="tooltip" data-placement="top" title="Rej&eacute;ter"><i class="fa fa-times fa-sm text-rouge"></i></button>
              <?php }else{?><i class="fa fa-lock fa-sm text-orange" title="D&eacute;j&agrave; traité !"></i><?php }?>
            </td>
            <td align="center"> <?php if($dmddet_etat_acc==1){?>			
              <i class="fa fa-check-circle fa-sm text-vert" title="Accept&eacute;"></i>
              <?php }elseif($dmddet_etat_acc==2){?>
              <i class="fa fa-minus-circle fa-sm text-rouge" title="Rej&eacute;t&eacute;"></i>
              <?php }else{?>
              <i class="fa fa-question fa-sm text-jaune" title="En attente"></i><?php }?>
              </td> 
        </tr>
        <?php 
        }
        ?>
    </tbody>
<?php 
}else{//demande location
  $chp = "dmddet_id, outilref_id, outilref_libelle, outilref_ref, outilref_descrip, outilref_prixloc_part, outilref_prixloc_soc, dmddet_nbrejrs, dmddet_etat_enreg, dmddet_etat_acc, dmddet_etat_traite, outilref_etat_mvt";
  $tbl = DEMANDES_DET." LEFT JOIN ".OUTILS_REF." ON dmddet_outils=outilref_id";
  $cnd = "dmddet_dmdid=$IdDmd0 AND dmddet_etat_enreg=1";
  $reqDet = selections($chp,$tbl,$cnd,"dmddet_id DESC");
  $resDet = $pdo->query($reqDet);
  ?>
  <tbody>
  <?php 
  $i = 0;
  $montant = 0;
  $Total = 0;
  while($col = $resDet->fetch()){
	$dmddet_id 		 	= $col['dmddet_id'];
	$dmddet_outils 	 	= $col['outilref_id'];
	$outil_libelle 	 	= $col['outilref_libelle'];
	$outil_prix_loc_part = $col['outilref_prixloc_part'];
	$outil_prix_loc_scte = $col['outilref_prixloc_soc'];
	$dmddet_nbrejrs 	 = $col['dmddet_nbrejrs'];
	$outilref_ref		= $col['outilref_ref'];
	$outilref_descrip	= $col['outilref_descrip'];
	$dmddet_etat_enreg 	= $col['dmddet_etat_enreg'];
	$dmddet_etat_acc	= $col['dmddet_etat_acc'];
	$dmddet_etat_traite	= $col['dmddet_etat_traite'];
	$outilref_etat_mvt	= $col['outilref_etat_mvt'];

    if($dmd_type_clt==0)$Prix = $outil_prix_loc_part;
    elseif($dmd_type_clt==1)$Prix = $outil_prix_loc_scte;
    else $Prix = "";
    $montant = $dmddet_nbrejrs*$Prix ;
    $i++;
    ?>
      <tr class="even gradeA" data-numligne="<?php echo $i; ?>">
          <td align="left"><?php echo "<strong>".$outil_libelle."</strong>";?></td>
          <td align="center"><?php echo nl2br($outilref_descrip); ?>
          <input id="IdDmd_<?php echo $i; ?>" name="IdDmd_<?php echo $i; ?>" value="<?php echo $IdDmd0; ?>" type="hidden">
          <input id="IdDetDmd_<?php echo $i; ?>" name="IdDetDmd_<?php echo $i; ?>" value="<?php echo $dmddet_id; ?>" type="hidden">
          <input id="IdOutil_<?php echo $i; ?>" name="IdOutil_<?php echo $i; ?>" value="<?php echo $dmddet_outils; ?>" type="hidden">
          </td>
          <td align="center"><?php echo $dmddet_nbrejrs; ?></td>
          <td align="right"><?php echo number_format($Prix,0,'',' '); ?></td>
          <td align="right"><?php echo number_format($montant,0,'',' '); ?></td>
          <td align="left"><?php echo $outilref_ref;?></td>
          <td align="center">
              <?php if($outilref_etat_mvt==0){?>
              <button class="btn btn-link"><i class="fa fa-warning fa-sm text-orange" title="L'outil n'est plus disponible !"></i></button>
              <button class="btn btn-link ButtonValideTraiteDmdLocRejet" data-rep="2" data-toggle="tooltip" data-placement="top" title="Rej&eacute;ter"><i class="fa fa-times fa-sm text-rouge"></i></button>
              <?php }elseif($dmddet_etat_acc==0){?>
              <button class="btn btn-link ButtonValideTraiteDmdLocAccord" data-rep="1" data-toggle="tooltip" data-placement="top" title="Valider"><i class="fa fa-check fa-sm text-vert"></i></button>
              <button class="btn btn-link ButtonValideTraiteDmdLocRejet" data-rep="2" data-toggle="tooltip" data-placement="top" title="Rej&eacute;ter"><i class="fa fa-times fa-sm text-rouge"></i></button>
              <?php }else{?><i class="fa fa-lock fa-sm text-orange" title="D&eacute;j&agrave; traité !"></i><?php }?>
          </td>
          <td align="center"> <?php if($dmddet_etat_acc==1){?>			
            <i class="fa fa-check-circle fa-sm text-vert" title="Accept&eacute;"></i>
            <?php }elseif($dmddet_etat_acc==2){?>
            <i class="fa fa-minus-circle fa-sm text-rouge" title="Rej&eacute;t&eacute;"></i>
            <?php }else{?>
            <i class="fa fa-question fa-sm text-jaune" title="En attente"></i><?php }?>
          </td> 
      </tr>    
      <?php 
      $Total+=$montant;
  }
      ?>
  </tbody>
  <tfoot>
      <tr>
        <th colspan="4" align="right">Total</th>
        <th align="right"><?php echo number_format($Total,0,'',' '); ?></th>
        <th align="center">&nbsp;</th>
        <th align="center">&nbsp;</th>
        <th align="center">&nbsp;</th>
      </tr>
   </tfoot>
   <?php
}
?>
