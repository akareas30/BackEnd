<?php
session_start();
ini_set('session.bug_compat_42', 0);
ini_set('session.bug_compat_warn', 0);
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php"); 
VerifTempsLog();

if(isset($_GET['dev'])){
  $IdCht  = (int)$_GET['dev'];
  if(!update(CHANTIERS,"cht_etat=0","cht_id=$IdCht")===true){
	  $array = array($IdCht);
	  echo json_encode($array);
  }
}