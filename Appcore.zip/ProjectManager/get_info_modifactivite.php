<?php
session_start();
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php");
VerifTempsLog(); 
if(isset($_GET['id'])){

   $idact  = $_GET['id'];
  
   $chp = "act_id, act_libelle, act_descrip, act_user_cre, DATE_FORMAT(act_date_cre, '%d/%m/%Y %H:%i:%s') AS date_cre, act_etat";
   $req = selections($chp,ACTIVITES,"act_id=$idact","act_id");
   $res = $pdo->query($req);				  
   $donnees = $res->fetch();
   echo json_encode($donnees);
   $pdo=null;
}
?>
