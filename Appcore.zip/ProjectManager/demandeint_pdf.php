<?php
//============================================================+
// File name   : example_005.php
// Begin       : 2008-03-04
// Last Update : 2013-05-14
//
// Description : Example 005 for TCPDF class
//               Multicell
//
// Author: Nicola Asuni
//
// (c) Copyright:
//               Nicola Asuni
//               Tecnick.com LTD
//               www.tecnick.com
//               info@tecnick.com
//============================================================+

/**
 * Creates an example PDF TEST document using TCPDF
 * @package com.tecnick.tcpdf
 * @abstract TCPDF - Example: Multicell
 * @author Nicola Asuni
 * @since 2008-03-04
 */

// Include the main TCPDF library 
session_start();
ini_set('session.bug_compat_42', 0);
ini_set('session.bug_compat_warn', 0);
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php"); 
VerifTempsLog();

if(isset($_GET['id'])){
	$IdDmd0 = (int)$_GET['id'];
}

$chp = "dmd_id, dmd_ref, cht_libelle, dmd_demandeur, dmd_motif, dmd_date_cre ,user_nom, user_prenom";
$tb = "(".DEMANDES." D  LEFT JOIN ".USERS." U ON D.dmd_user_cre=U.user_id) LEFT JOIN ".CHANTIERS." C ON C.cht_id=D.dmd_chantier ";
$cnd = "dmd_id=$IdDmd0";
$reqDet = selections($chp,$tb,$cnd,"dmd_id DESC");
$resDet = $pdo->query($reqDet);	
$col = $resDet->fetch();
$dmd_id 		= $col['dmd_id'];
$dmd_ref 		= $col['dmd_ref'];
$cht_libelle	= $col['cht_libelle'];
$dmd_demandeur 	= $col['dmd_demandeur'];
$dmd_motif	 	= $col['dmd_motif'];
$dmd_date_cre 	= $col['dmd_date_cre'];
$user_nom 		= $col['user_nom'];
$user_prenom 	= $col['user_prenom'];

$cht_libelle 	= html_entity_decode($cht_libelle);
$dmd_demandeur 	= html_entity_decode($dmd_demandeur);
$dmd_motif 		= html_entity_decode($dmd_motif);
$user_nom 		= html_entity_decode($user_nom);
$user_prenom 	= html_entity_decode($user_prenom);


require_once('TCPDF/examples/config/tcpdf_config_alt.php');
require_once('TCPDF/tcpdf.php');

// Extend the TCPDF class to create custom Header and Footer
class MYPDF extends TCPDF {

	//Page header
	public function Header() {
		// Logo
		$image_file = K_PATH_IMAGES.'logo_crb_valeur.gif';
		$ximg = 10;
		$yimg = 8;
		$this->Rect($ximg-1, $yimg-1, 17, 23, 'D', array(), array(255,255,255));
		$this->Image($image_file, $ximg, $yimg, 15, '', 'gif', '', 'T', false, 300, '', false, false, 0, false, false, false);
		// Set font
		$this->SetFont('helvetica', 'B', 18);
		// Title
		$x = $ximg-1+17;
		$this->Rect($x, $yimg-1, 175, 23, 'D', array(), array(255,255,255));
		$this->SetXY(26, 18);
		$this->Cell(0, 15, 'FICHE DE SORTIE DE MATÉRIEL', 0, false, 'C', 0, '', 0, false, 'M', 'M');
	}

	// Page footer
	public function Footer() {
		// Position at 15 mm from bottom
		$this->SetY(-15);
		// Set font
		$this->SetFont('helvetica', 'I', 7);
		// Page number
		$this->Cell(0, 10,'Édité le '.date('d-m-Y H:i:s'), 0, false, 'C', 0, '', 0, false, 'T', 'M');
		$this->Cell(0, 10, 'Page '.$this->getAliasNumPage().'/'.$this->getAliasNbPages(), 0, false, 'R', 0, '', 0, false, 'T', 'M');
	}
}


// create new PDF document
$pdf = new MYPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);


// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('CRB');
$pdf->SetTitle('CRB - FICHE SORTIE DE MATERIEL');
$pdf->SetSubject('GESTION DE MATERIEL');
$pdf->SetKeywords('CRB, CONSTRUCTIONS, RENOVATIONS, BATIMENTS, GROS OEUVRES, OEUVRES SECONDAIRES, CONSTRUCTIONS METALLIQUES');

// set default header data
$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 005', PDF_HEADER_STRING);

// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
	require_once(dirname(__FILE__).'/lang/eng.php');
	$pdf->setLanguageArray($l);
}

// ---------------------------------------------------------



// add a page
$pdf->AddPage();

// set cell padding
//$pdf->setCellPaddings(1, 1, 1, 1);

// set cell margins
//$pdf->setCellMargins(1, 1, 1, 1);

// set color for background
$pdf->SetFillColor(255, 255, 127);

// MultiCell($w, $h, $txt, $border=0, $align='J', $fill=0, $ln=1, $x='', $y='', $reseth=true, $stretch=0, $ishtml=false, $autopadding=true, $maxh=0)

// Multicell test

/*Les largeurs*/
$w_ref = 50;
$w_date = 25;
$w_projet = 105;
/*Ordonnee*/
$ny = 35;
$pdf->SetY($ny);

/*Abscisses*/
$nx = $pdf->GetX(); 
$x_ref = $nx;
$x_date = $x_ref+$w_ref;
$x_projet = $x_date+$w_date;
/*cell*/

// set font
$pdf->SetFont('times', 'B', 12);

$pdf->MultiCell($w_ref, 6, 'Référence', 1, 'L', 0, 0, $x_ref, $ny, true, 0, false, true, '6', 'M');
$pdf->MultiCell($w_date, 6, 'Date', 1, 'L', 0, 0, $x_date, $ny, true, 0, false, true, '6', 'M');
$pdf->MultiCell($w_projet, 6, 'Chantier', 1, 'L', 0, 0, $x_projet, $ny, true, 0, false, true, '6', 'M');

$pdf->SetFont('times', '', 11);

$ny = $pdf->GetY(); 
$pdf->MultiCell($w_ref, 15, $dmd_ref, 1, 'L', 0, 0, $x_ref, $ny+6, true, 0, false, true, '15', 'M');
$pdf->MultiCell($w_date, 15, getdateC($dmd_date_cre), 1, 'C', 0, 0, $x_date, $ny+6, true, 0, false, true, '15', 'M');
$pdf->MultiCell($w_projet, 15, $cht_libelle, 1, 'L', 0, 0, $x_projet, $ny+6, true, 0, false, true, '15', 'M');

$pdf->Ln();
$pdf->SetY(58);
$pdf->SetFont('times', 'B', 11);
$pdf->MultiCell(18, 9, 'MOTIF: ', 0, 'L', 0, 0, $nx,'', true, 0, false, true, '9', 'M');
$pdf->SetFont('times', '', 11);
$pdf->MultiCell('', 9, $dmd_motif, 0, 'L', 0, 0, $nx+18,'', true, 0, false, true, '9', 'M');

/*Les largeurs*/
$w_des = 100;
$w_ref = 40;
$w_date = 40;
/*Ordonnee*/
$pdf->SetY(65);
$ny = $pdf->GetY(); 
/*Abscisses*/
$nx = $pdf->GetX(); 
$x_des = $nx;
$x_ref = $x_des+$w_des;
$x_date = $x_ref+$w_ref;

$ny = $pdf->GetY(); 
//$ny = $ny+50;
$pdf->SetFont('times', 'B', 12);
$ny = $pdf->GetY(); 
$pdf->MultiCell($w_des, 7, 'DÉSIGNATION', 1, 'L', 0, 0, $x_des, $ny+5, true, 0, false, true, '7', 'M');
$pdf->MultiCell($w_ref, 7, 'RÉFÉRENCE', 1, 'L', 0, 0, $x_ref, $ny+5, true, 0, false, true, '7', 'M');
$pdf->MultiCell($w_date, 7, 'RETOUR / OBS.', 1, 'L', 0, 0, $x_date, $ny+5, true, 0, false, true, '7', 'M');

$pdf->SetFont('times', '', 10);

$chp = "outilref_libelle, outilref_ref, outilref_descrip, outilref_detail";
$tbl = DEMANDES_DET." LEFT JOIN ".OUTILS_REF." ON dmddet_outils=outilref_id";
$cnd = "dmddet_dmdid=$IdDmd0 AND dmddet_etat_enreg=1 AND (dmddet_etat_acc=0 OR dmddet_etat_acc=1)";

$reqRef = selections($chp,$tbl,$cnd,"outilref_libelle ASC");
$resRef = $pdo->query($reqRef);
$ny = $pdf->GetY();
$y = $ny+7;
while($colRef = $resRef->fetch()){
  $OUTIL_LIB   = $colRef['outilref_libelle'];
  $REF_LIBELLE = $colRef['outilref_ref'];
  $OUTIL_DESCRIP = $colRef['outilref_descrip'];
  $OUTIL_DETAIL = $colRef['outilref_detail'];
  $pdf->MultiCell($w_des, 10, $OUTIL_LIB.' / '.$OUTIL_DESCRIP, 1, 'L', 0, 0, $x_des, $y, true, 0, false, true, '10', 'M');
  $pdf->MultiCell($w_ref, 10, $REF_LIBELLE, 1, 'L', 0, 0, $x_ref, $y, true, 0, false, true, '10', 'M');
  $pdf->MultiCell($w_date, 10, '', 1, 'C', 0, 0, $x_date, $y, true, 0, false, true, '10', 'M');
  $y = $y+10;
}

$pdf->Ln(20);
$pdf->SetFont('times', 'B', 12);
$pdf->MultiCell($w_date, 7, 'Le Responsable', 0, 'L', 0, 0, '', '', true, 0, false, true, '7', 'M');
$pdf->SetX(-50);
$pdf->MultiCell($w_date, 7, 'Le Demandeur', 0, 'L', 0, 0, '', '', true, 0, false, true, '7', 'M');
$yd = $pdf->GetY();
$pdf->SetY($yd+8);
$pdf->SetX(-70);
$pdf->SetFont('times', '', 12);
$pdf->MultiCell(65, 15, $dmd_demandeur, 0, 'C', 0, 0, '', '', true, 0, false, true, '15', 'M');
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


// move pointer to last page
$pdf->lastPage();

// ---------------------------------------------------------

//Close and output PDF document
//$pdf->Output('test_exple.pdf', 'I');
$ref_format = str_replace("/","-",stripslashes($dmd_ref));
$filename = "SORTIE-OUTIL-".stripslashes($ref_format).".pdf";
$pdf->Output($filename, 'D');
//============================================================+
// END OF FILE
//============================================================+
