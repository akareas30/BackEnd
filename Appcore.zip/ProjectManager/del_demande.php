<?php
session_start();
ini_set('session.bug_compat_42', 0);
ini_set('session.bug_compat_warn', 0);
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php"); 
VerifTempsLog();

if(isset($_GET['dev'])){
  $IdDmd0  = (int)$_GET['dev'];
  if(!update(DEMANDES,"dmd_etat_enreg=0","dmd_id=$IdDmd0 AND dmd_etat_approuv<>1")===true){
	  $array = array($IdDmd0);
	  echo json_encode($array);
  }
}