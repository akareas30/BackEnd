<?php
session_start();
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php"); 
VerifTempsLog();

if(isset($_GET['id'])){
  $iddet  = $_GET['id'];
  $chp = "devdet_id, devdet_devid, devdet_rub1, devdet_rub2, devdet_materiel, devdet_qte, devdet_prixunit, devdet_etat_enreg, devdet_unite";
  $reqDet = selections($chp,DEVIS_DET,"devdet_id=$iddet","devdet_rub1 ASC, devdet_rub2 ASC, devdet_id DESC");
  $resDet = $pdo->query($reqDet);
  $donnees = $resDet->fetch();
  echo json_encode($donnees);
  $pdo=null;
}
?>
