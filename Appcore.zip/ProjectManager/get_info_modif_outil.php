<?php
session_start();
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php"); 
VerifTempsLog();
if(isset($_GET['id'])){

  $idoutil  = $_GET['id'];
  /*
  $chp = "clt_id, clt_type, clt_nom, clt_abrege, clt_code, clt_tel1, clt_mail, clt_ncc, clt_localisation, clt_interloc, DATE_FORMAT(clt_date_cre, '%d/%m/%Y %H:%i:%s') AS date_cre, clt_etat";
  */
  $chp = "outilref_id, outilref_libelle, outilref_prixloc_part, outilref_prixloc_soc, outilref_ref, outilref_serial, outilref_marque, outilref_descrip, outilref_detail, outilref_date_acquis";
  
  $req = selections($chp,OUTILS_REF,"outilref_id=$idoutil","outilref_id");
  $res = $pdo->query($req);
  $donnees = $res->fetch();
  echo json_encode($donnees);
  $pdo=null;
}
?>
