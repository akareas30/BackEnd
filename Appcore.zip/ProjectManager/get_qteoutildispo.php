<?php
session_start();
ini_set('session.bug_compat_42', 0);
ini_set('session.bug_compat_warn', 0);
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php"); 
VerifTempsLog();

if(isset($_GET['id'])){
  $IdOutil = (int)trim($_GET['id']);
  $typeClt = (int)trim($_GET['tclt']);
  
  //$req = selections("getQteDispo($IdOutil) as QteDispo",DUAL,"1","1");
  $cnd = "outilref_id=$IdOutil";
  $req = selections("outilref_prixloc_part,outilref_prixloc_soc",OUTILS_REF,$cnd,1);
  $res= $pdo->query($req);
  $col = $res->fetch();
  $PRIX_PART 	= $col['outilref_prixloc_part'];
  $PRIX_SOC 	= $col['outilref_prixloc_soc'];
  if($typeClt==0)$PRIX = $PRIX_PART; elseif($typeClt==1)$PRIX = $PRIX_SOC;else $PRIX = "";
  $array = array(number_format($PRIX,0,'',' '));
  echo json_encode($array);
}
?>
