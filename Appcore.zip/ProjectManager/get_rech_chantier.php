<?php		
	session_start();
	ini_set('session.bug_compat_42', 0);
	ini_set('session.bug_compat_warn', 0);
	require('inc/definitions.php');
	include("inc/cnt.php");
	include("inc/fonction.php");
	
	$q = strtoupper($_GET["q"]);
	if (!$q) return;
	$qc = strtoupper(trim(addslashes($q)));
	$cnd = "(cht_ref LIKE '%$qc%' OR cht_libelle LIKE '%$qc%') AND cht_etat=1";
	$req = selections("cht_id,cht_ref",CHANTIERS,$cnd,"cht_ref ASC");
	$res = $pdo->query($req);
	while($col = $res->fetch(PDO::FETCH_ASSOC)) {
		$data[] = $col;
	}
	echo json_encode($data);
	$res->closeCursor();
	//echo 'inconnu ...';

?>

