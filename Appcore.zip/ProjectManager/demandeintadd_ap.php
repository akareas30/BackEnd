<?php if(isset($_GET['act']) and  $_GET['act']=="add"){ ?>
<div class="row">
  <div class="col-lg-12">
      <h3 class="page-header">ENREGISTRER UNE DEMANDE INTERNE</h3>
  </div>
  <div class="col-lg-12">
      <h4>ETAPE 1/2: INFOS GENERALES DE LA DEMANDE</h4>
  </div>
  <!-- /.col-lg-12 -->
</div>
<?php 
if(isset($_POST['suiv'])){
	$chantId    = trim($_POST['chantId']);
	$motif  	= htmlentities(strtoupper(trim(addslashes($_POST['motif']))));
	$demandeur  = htmlentities(strtoupper(trim(addslashes($_POST['demandeur']))));
	
	$ref = getRefDmd(1);
   
	if($demandeur=="" or $motif==""){
	  ?><div class="alert alert-warning alert-dismissable">
	  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
	  <?php echo TXT_AVERT_CHP_OBLIGE; ?></div><?php
	}else{	
	   $tb = DEMANDES."(dmd_ref, dmd_type, dmd_chantier, dmd_demandeur, dmd_motif, dmd_date_cre, dmd_user_cre)";
	   $val = "'$ref',1,'$chantId','$demandeur','$motif',NOW(),".$_SESSION['AP_iduser'];
	   if($IdDmd0 = AjoutBDGetId($tb,$val)){
		   ?><script language="javascript">document.location="?yk=demandeintadd2&svt&dev=<?php echo $IdDmd0;?>"</script><?php
	   }else{
		   ?><div class="alert alert-danger alert-dismissable">
		  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		  <?php echo TXT_ALERT_ERROR_ENREG; ?></div><?php
	   }
	}
}
?>
<!-- /.row -->
<div class="row">
  <div class="col-lg-12">
      <div class="panelglobal panel-default-global">
          <form role="form" action="" method="post" id="formAddDevis">
          <div class="panel-body">
              <div class="row">              
                  <div class="col-lg-6">
                    <div class="form-group">
                        <label>Chantier</label>
                        <input class="form-control bs-autocomplete" id="libchant" placeholder="Indiquez le chantier" type="text" data-source="get_rech_chantier.php" data-hidden_field_id="chantId" data-item_id="cht_id" data-item_label="cht_ref" autocomplete="off" autofocus="autofocus">
                        <input class="form-control" id="chantId" name="chantId" type="hidden" readonly>
                     </div>
                     <div class="form-group">
                        <label>Demandeur *</label>
                        <input class="form-control" id="demandeur" name="demandeur" placeholder="Le nom du demandeur..." type="text" required="required">
                     </div>
                     <div class="form-group">
                        <label>Motif *</label>
                        <textarea name="motif" rows="3" class="form-control" id="motif" placeholder="Le motif de la demande ..." required="required"></textarea>
                    </div>
                    
                  </div>
              </div>
              <div class="row">
              <div class="col-lg-4 center-block">
                  <button name="suiv" id="suiv" type="submit" class="btn btn-warning btn-block">&nbsp;Suivant pour les d&eacute;tails...&nbsp;<i class="fa fa-long-arrow-right fa-lg"></i></button>
                  <p class="help-block">Cliquer sur Suivant pour saisir les d&eacute;tails de la demande</p>
              </div>
              </div>
          </div>
          </form>
      </div>
  </div>
</div>
<?php 
}

if(isset($_GET['act']) and $_GET['act']=="mod"){
	$IdDmd0 = $_GET['dev'];
	$chp = "dmd_id, dmd_motif, dmd_demandeur, dmd_chantier, cht_ref, dmd_etat_approuv";
	$tb = DEMANDES." D LEFT JOIN ".CHANTIERS." C ON D.dmd_chantier=C.cht_id";
	$cnd = "dmd_id=$IdDmd0";
	
	$reqLib = selections($chp,$tb,$cnd,1);
	$res = $pdo->query($reqLib);
	$col = $res->fetch();
	$old_dmd_id 		= $col['dmd_id'];
	$old_dmd_demandeur 	= $col['dmd_demandeur'];
	$old_dmd_chantier 	= $col['dmd_chantier'];
	$old_cht_ref 		= $col['cht_ref'];
	$old_dmd_motif 		= $col['dmd_motif'];
	$dmd_etat_approuv	= $col['dmd_etat_approuv'];

	if($dmd_etat_approuv==0){?>
	  <div class="row">
		<div class="col-lg-12">
			<h3 class="page-header">MODIFIER UNE DEMANDE INTERNE</h3>
		</div>
		<div class="col-lg-12">
			<h4>SAISIR LES INFOS A MODIFIER</h4>
		</div>
		<!-- /.col-lg-12 -->
	  </div>
	  <?php 
	  
	  if(isset($_POST['modif']) or isset($_POST['modifSuiv'])){
		  $chantId    = trim($_POST['chantId']);
		  $motif  	= htmlentities(strtoupper(trim(addslashes($_POST['motif']))));
		  $demandeur  = htmlentities(strtoupper(trim(addslashes($_POST['demandeur']))));
		  
		  if($demandeur=="" or $motif==""){
			  ?><div class="alert alert-warning alert-dismissable">
			  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			  <?php echo TXT_AVERT_CHP_OBLIGE; ?></div><?php
		  }else{	
		   $mod = "dmd_chantier='$chantId', dmd_motif='$motif', dmd_demandeur='$demandeur',dmd_date_mod=NOW(), dmd_user_mod=".$_SESSION['AP_iduser'];
		   if(!update(DEMANDES,$mod,"dmd_id=$old_dmd_id")===true){
			   ?><div class="alert alert-success alert-dismissable">
			  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			  <?php echo TXT_ALERT_SUCCES_MODIF; ?></div>
			  <?php 
			  if(isset($_POST['modif'])){?>
				  <script language="javascript">document.location="?yk=demandegestInt&act=add"</script><?php
			  }elseif(isset($_POST['modifSuiv'])){?>
				  <script language="javascript">document.location="?yk=demandeintadd2&svt&dev=<?php echo $old_dmd_id;?>"</script><?php
			  }else{?>
				  <script language="javascript">document.location="?yk=demandegestInt&act=add"</script><?php
				  }
		   }else{
			   ?><div class="alert alert-danger alert-dismissable">
			  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			  <?php echo TXT_ALERT_ERROR_MODIF; ?></div><?php
		   }
		  }
		  
	  }
	  
	  ?>
	  <!-- /.row -->
	  <div class="row">
		<div class="col-lg-12">
			<div class="panelglobal panel-default-global">
				<form role="form" action="" method="post" id="formModifDevis">
				<div class="panel-body">
					<div class="row">              
						<div class="col-lg-6">
						  <div class="form-group">
							  <label>Chantier</label>
							  <input class="form-control bs-autocomplete" id="libchant" placeholder="Indiquez le chantier" type="text" data-source="get_rech_chantier.php" data-hidden_field_id="chantId" data-item_id="cht_id" data-item_label="cht_ref" autocomplete="off" autofocus="autofocus" value="<?php echo $old_cht_ref; ?>">
							  <input class="form-control" id="chantId" name="chantId" type="hidden" value="<?php //echo $old_dmd_chantier; ?>" readonly="readonly">
						   </div>
						   <div class="form-group">
							  <label>Demandeur *</label>
							  <input class="form-control" id="demandeur" name="demandeur" placeholder="Le nom du demandeur..." type="text" required="required" value="<?php echo $old_dmd_demandeur; ?>">
						   </div>
						   <div class="form-group">
							  <label>Motif *</label>
							  <textarea name="motif" rows="3" class="form-control" id="motif" placeholder="Le motif de la demande ..." required="required"><?php echo $old_dmd_motif; ?></textarea>
						  </div>
						  
						</div>
					</div>
					<div class="row">
					<div class="col-lg-4 center-block" id="blcModDevisSuiv">
						<button name="modifSuiv" id="modifSuiv" type="submit" class="btn btn-warning  btn-block" onClick="return confirm('Confirmez-vous la modification ?');"><i class="fa fa-save fa-lg"></i>&nbsp;&nbsp;Modifier la demande et &eacute;diter les d&eacute;tails</button>
						<p class="help-block"><?php echo TXT_AVERT_CHP_OBLIGE; ?></p>
					</div>
					<div class="col-lg-4 center-block">
						<button name="modif" id="modif" type="submit" class="btn btn-success btn-block" onClick="return confirm('Confirmez-vous la modification ?');"><i class="fa fa-save fa-lg"></i>&nbsp;&nbsp;Modifier et Terminer</button><p class="help-block">&nbsp;</p>
					</div>
					<div class="col-lg-4">
						<a href="?yk=demandegestInt&act=add" class="btn btn-danger btn-block"><i class="fa fa-undo fa-lg"></i>&nbsp;&nbsp;Annuler</a>
					</div>
					</div>
				</div>
				</form>
			</div>
		</div>
	  </div>
	  <?php 
	}else{?>
	<div class="row">
		<div class="col-lg-12">
			<div>Modification impossible car demande a d&eacute;j&agrave; &eacute;t&eacute; trait&eacute;e pour les sorties</div>
		</div>
	</div><?php
	}
}
?>