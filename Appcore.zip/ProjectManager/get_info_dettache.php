<?php
session_start();
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php"); 
VerifTempsLog();

if(isset($_GET['id'])){
  $iddet  = $_GET['id'];
  $chp = "tch_id, tch_libelle, tch_debut, tch_fin_prevu, dev_ref, dev_id, dev_objet";
  $tb = TACHES." LEFT JOIN ".DEVIS." ON tch_devis=dev_id"; 
  $reqDet = selections($chp,$tb,"tch_id=$iddet","tch_id");
  $resDet = $pdo->query($reqDet);
  $donnees = $resDet->fetch();
  echo json_encode($donnees);
  $pdo=null;
}
?>