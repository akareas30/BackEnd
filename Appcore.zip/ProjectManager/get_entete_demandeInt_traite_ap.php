<?php 
session_start();
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php");
VerifTempsLog();

if(isset($_GET['id']) and isset($_GET['typdm'])){
	$IdDmd0 = (int)$_GET['id'];
	$typdm  = (int)$_GET['typdm'];//Le type de demande: 1:interne et 0:location
}
$chp = "dmd_id, dmd_ref, dmd_type_clt, dmd_clt, dmd_demandeur, dmd_motif, dmd_date_cre";
$reqDet = selections($chp,DEMANDES,"dmd_id=$IdDmd0","dmd_id DESC");
$resDet = $pdo->query($reqDet);	
$col = $resDet->fetch();
$dmd_id 		= $col['dmd_id'];
$dmd_ref 		= $col['dmd_ref'];
$dmd_type_clt	= $col['dmd_type_clt'];
$dmd_clt 		= $col['dmd_clt'];
$dmd_demandeur 	= $col['dmd_demandeur'];
$dmd_motif 		= $col['dmd_motif'];
$dmd_date_cre 	= $col['dmd_date_cre'];

if($dmd_type_clt==0)$typeClt = "Particulier";
elseif($dmd_type_clt==1)$typeClt = "Soci&eacute;t&eacute;";
else $typeClt="";

?>

<div class="row">
  <div class="col-sm-12">
      <h4 class="rapp">REF. DEMANDE: <span class="text-rouge"><?php echo $dmd_ref;?></span></h4>
  </div>
</div>
<?php if($typdm==1){?>
<div class="row page-header-st">
  <div class="col-sm-6">
      <div><h5>DEMANDEUR: <span class="text-rouge"><?php echo $dmd_demandeur;?></span></h5></div>
  </div>
  <div class="col-sm-6">
      <h5>MOTIF: 
      <span class="text-bleu"><?php echo $dmd_motif; ?>
   </div>
</div>
<?php }else{?>
<div class="row page-header-st">
  <div class="col-sm-12">
      <div><h5>CLIENT: <span class="text-rouge"><?php echo $dmd_clt." <span class=small><em>(".$typeClt.")</em></span>";?></span></h5></div>
  </div>
</div>
<?php }?>