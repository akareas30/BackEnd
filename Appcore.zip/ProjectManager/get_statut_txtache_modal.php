<?php
session_start();
ini_set('session.bug_compat_42', 0);
ini_set('session.bug_compat_warn', 0);
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php");
VerifTempsLog();

if(isset($_GET['tache'])){
	$IdTache 	= $_GET['tache'];
}

$chp = "tch_debut, tch_fin_prevu, tch_fin_eff, tch_taux";
$tb = TACHES;
$cnd = "tch_id = $IdTache";
$req = selections($chp,$tb,$cnd,"tch_id");
$res = $pdo->query($req);	
$col = $res->fetch();
$tch_debut 		= $col['tch_debut'];
$tch_fin_prevu 	= $col['tch_fin_prevu'];
$tch_fin_eff 	= $col['tch_fin_eff'];
$tch_taux 		= $col['tch_taux'];

$LeJour = date('Y-m-d');
$TimeJour 	 = new DateTime($LeJour);
$timeFinPrev = new DateTime($tch_fin_prevu);
$timeFinEff  = new DateTime($tch_fin_eff);
$JourFinEff = $timeFinEff->format('d-m-Y');

if($tch_taux<100){//Si taux <100 alors tache tjrs en cours
	$statut = '<span class="text-bleu">&nbsp;En cours ('.$tch_taux.'%)</span>'; 
}else{//tache terminé
	$statut = '<span class="text-vert">&nbsp;Termin&eacute;</span>';
	if($tch_fin_eff!=0){
	  $intervalEff = $timeFinPrev->diff($timeFinEff);
	  $NbreJourFinEff = $intervalEff->format('J%R%a');//Nbre entre la date fin effective et celle prevue
	  if(($timeFinEff>$timeFinPrev)==true){
		  $statut .='<span class="small text-rouge">&nbsp;&Agrave; '.$NbreJourFinEff.' ('.$JourFinEff.')</span>';
	  }else{
		  $statut .='<span class="small text-vert">&nbsp;&Agrave; '.$NbreJourFinEff.' ('.$JourFinEff.')</span>';
	  }
	}
}

echo "&nbsp;&nbsp;Statut: ".$statut;
?>