<div class="row">
  <div class="col-lg-12">
      <h3 class="page-header">GESTION DE CHANTIERS</h3>
  </div>
</div>
<!-- /.row -->

<?php
$Rechwhere = "";
if (isset($_POST['rfind'])){
	if($_POST['datedeb']!=""){
		$datedeb=trim($_POST['datedeb']); 
  }else $datedeb = dateCFrToEn('0000-00-00');
	
	if($_POST['datefin']!=""){
		$datefin=trim($_POST['datefin']); 
	}else $datefin = date('Y-m-d');
	
	$Rechwhere.= " AND cht_date_cre BETWEEN '$datedeb' AND '$datefin'";
	
	if($_POST['etat']!=""){
		$etat=trim($_POST['etat']); 
		$Rechwhere.= " AND cht_etat=$etat"; 
  }
		   
}else{
	$etat = 1;
	$Rechwhere= " AND cht_etat=$etat";
}
?>
<div class="row">
  <div class="col-lg-12">
      <div class="panelglobal panel-default-global">
          <div class="panel-body">
              <div class="row">
              <div class="col-lg-12">
                    <div class="panelrech panel-default">
                      <div class="panel-heading-rech">Zone de recherche</div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
              				<form role="form" method="post" id="rechUser">
                  <div class="col-lg-3">
                    <div class="form-group input-group">
                       <span class="input-group-addon">Date d&eacute;but</span>
                        <input type="date" class="form-control" placeholder="Date d&eacute;but" name="datedeb" id="datedeb" value="<?php echo $datedeb; ?>" >
                    </div>
                  </div>
                  <div class="col-lg-3">
                    <div class="form-group input-group">
                       <span class="input-group-addon">Date fin</span>
                        <input type="date" class="form-control" placeholder="Date fin" name="datefin" id="datefin" value="<?php echo $datefin; ?>" >
                    </div>
                  </div>
                  <div class="col-lg-3">
                    <div class="form-group input-group">
                       <span class="input-group-addon">Statut</span>
                        <select name="etat" id="etat" class="form-control">
                        <option value="">--Tout--</option>
                         <option value="1" <?php if($etat=="1"){?>selected="selected"<?php }?>>En cours</option>
                         <option value="2" <?php if($etat=="2"){?>selected="selected"<?php }?>>Termin&eacute;</option>
                         <option value="3" <?php if($etat=="3"){?>selected="selected"<?php }?>>Annul&eacute;</option>
                       </select>
                    </div>
                  </div>
                  <div class="col-lg-3">
                  <button type="submit" class="btn btn-primary btn-block" name="rfind" id="rfind">Rechercher&nbsp;&nbsp;<i class="glyphicon glyphicon-search"></i></button>
                  </div>
               </form>
               			</div>
                    </div>
               </div>
               <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">LISTE DES CHANTIERS &Agrave; G&Eacute;RER</div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
							<?php 
							$chp = "cht_id, cht_chef, cht_libelle, cht_descrip, cht_localise, cht_debut, cht_fin_prevu, cht_fin_eff, cht_date_cre, user_nom, user_prenom, cht_etat, clt_abrege, cht_observ";
							$tb = "(".CHANTIERS." CH LEFT JOIN ".CLIENTS." C ON CH.cht_client=C.clt_id) 
									LEFT JOIN ".USERS." U ON cht_user_cre=user_id";
							$cnd = "cht_etat <>0 $Rechwhere";
							$reqDet = selections($chp,$tb,$cnd,"cht_id DESC");
							$resDet = $pdo->query($reqDet);							
							?>
                            <table width="100%" class="table table-striped table-bordered table-hover" id="tb_gestchantier">
                                <thead>
                                    <tr>
                                        <th align="center">#</th>
                                        <th align="left">Chantier</th>
                                        <th align="left">Description</th>
                                        <th align="left">D&eacute;but/Fin</th>
                                        <th align="left">Client</th>
                                        <th align="left">Chef Chantier</th>
                                        <th align="left">Statut</th>
                                        <th align="left">Devis</th>
                                        <th align="left">D&eacute;tails</th> 
                                        <?php if($_SESSION['AP_user_profil']=="AD" || $_SESSION['AP_user_profil']=="DG" || $_SESSION['AP_user_profil']=="DT" || $_SESSION['AP_user_profil']=="CC"){?>                                       
                                        <th align="left">Actions</th>
                                        <?php }?>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php 
								$i = 0;
								$reqDev = null;
								while($col = $resDet->fetch()){
								  $cht_id 		= $col['cht_id'];
								  $cht_chef 	= $col['cht_chef'];
								  $cht_libelle	= $col['cht_libelle'];
								  $cht_descrip 	= $col['cht_descrip'];
								  $cht_localise = $col['cht_localise'];
								  $cht_debut 	= $col['cht_debut'];
								  $cht_fin_prevu= $col['cht_fin_prevu'];
								  $cht_fin_eff 	= $col['cht_fin_eff'];
								  $cht_date_cre = $col['cht_date_cre'];
								  $clt_abrege 	= $col['clt_abrege'];
								  $cht_etat 	= $col['cht_etat'];
								  $clt_abrege 	= $col['clt_abrege'];
								  $cht_observ 	= $col['cht_observ'];
								  $user_nom     = $col['user_nom'];
								  $user_prenom 	= $col['user_prenom'];
								  
								  $ch = "ID_CHANT, ID_DEV, REF_DEV, OBJET_DEV";
								  $tab = VT_DEVCHANT." D LEFT JOIN ".CHANTIERS." C ON D.ID_CHANT=C.cht_id";
								  $cd = "D.ID_CHANT=$cht_id AND ETAT_DEV=1";
								  $reqDev = selections($ch,$tab,$cd,"ID_CHANT DESC");
								  $resDev = $pdo->query($reqDev);	
								  
								  if($cht_etat==1) $statut = '<span class=text-bleu><i class="fa fa-pencil-square-o"></i>&nbsp;En cours</span>';
                                  elseif($cht_etat==2){
									  $statut = '<span class=text-vert><i class="fa fa-check-square-o"></i>&nbsp;Termin&eacute;</span>';
									  if($cht_fin_eff!=0){
										  $statut .='<br /><span class="small text-rouge">&nbsp;('.getdateC($cht_fin_eff).')<span/>';
									  }
								  }
                                  elseif($cht_etat==3){
									  $statut = '<span class=text-rouge><i class="fa fa-minus-circle"></i>&nbsp;Annul&eacute;</span>';
									  if($cht_fin_eff!=0){
										  $statut .='<br /><span class="small text-rouge">&nbsp;('.getdateC($cht_fin_eff).')<span/>';
									  }
								  }
								  $i++;
								  ?> 
                                    <tr id="<?php echo $cht_id;?>" class="even gradeA success">
                                        <td align="center"><?php echo $i ?></td>
                                        <td nowrap="nowrap">
										<?php echo "<span data-toggle='tooltip' data-placement='top' title='".$cht_observ."'><strong>".$cht_libelle."</strong></span>";
										if(!empty($cht_date_cre))echo "<br /><span class=small><em>Ajout&eacute; le ".getdateC($cht_date_cre)."<br />Par ".$user_prenom." ".$user_nom."</em></span>";?>
										</td>
                                        <td><?php echo nl2br($cht_descrip); ?></td>
                                        <td align="center"><?php echo getdateC($cht_debut).'<br />'.getdateC($cht_fin_prevu);?></td>
                                        <td align="left"><?php echo "<strong>".$clt_abrege."</strong>"; ?></td>
                                        <td align="left"><?php echo $cht_chef; ?></td>
                                        <td align="center"><?php echo $statut; ?></td>
                                        <td align="center" nowrap="nowrap" class="small">
                                        <?php 
										while($dev = $resDev->fetch()){?>
											<div data-toggle="tooltip" data-placement="left" title="<?php echo $dev['OBJET_DEV']; ?>">
                                            <button class="btnLien btn-link ButtonOuvrirDevisChant" data-id="<?php echo $dev['ID_DEV']; ?>" data-toggle="modal" data-backdrop="static"><?php echo $dev['REF_DEV']; ?></button>
                                            </div>
											<?php 
										}
										?>
                                        </td>
                                        <td align="center" nowrap="nowrap">
                                        <?php if($_SESSION['AP_user_profil']=="AD" || $_SESSION['AP_user_profil']=="DG" || $_SESSION['AP_user_profil']=="DT" || $_SESSION['AP_user_profil']=="CC"){?>
                                        <div><button class="btnLien btn-link ButtonPlannChantier" data-toggle="tooltip" data-placement="top" title="Planning du chantier <?php echo $cht_libelle; ?>" onclick="document.location.href='?yk=chantierplann&act=mod&cht=<?php echo $cht_id;?>'"><i class="fa fa-list-ol fa-sm text-vert"></i>&nbsp;Planning</button>&nbsp;</div><?php }?>
                                        <!--<div data-toggle="tooltip" data-placement="top" title="Les &Eacute;quipes du chantier <?php echo $cht_libelle; ?>">
                                          <button class="btnLien btn-link ButtonOuvrirEqp" data-title="Les &Eacute;quipes du chantier <?php echo $cht_libelle; ?>" data-id="<?php echo $cht_id;?>" data-toggle="modal" data-backdrop="static"><i class="fa fa-group fa-sm text-vert"></i>&nbsp;&Eacute;quipes&nbsp;&nbsp;&nbsp;</button></div>-->
                                          
                                          <div data-toggle="tooltip" data-placement="top" title="Voir la fiche Chantier">
                                          <button class="btnLien btn-link ButtonOuvrirFicheChantier" data-id="<?php echo $cht_id;?>" data-toggle="modal" data-backdrop="static"><i class="fa  fa-columns fa-sm text-bleu"></i>&nbsp;Fiche Chantier</button></div>
                                          
                                          <div data-toggle="tooltip" data-placement="top" title="Voir la fiche Rapport">
                                          <button class="btnLien btn-link ButtonOuvrirFicheRapport" data-id="<?php echo $cht_id;?>" data-toggle="modal" data-backdrop="static"><i class="fa fa-tasks fa-sm text-bleu"></i>&nbsp;Fiche Rapport</button></div>
                                          
                                        </td>
                                        
                                        <?php if($_SESSION['AP_user_profil']=="AD" || $_SESSION['AP_user_profil']=="DG" || $_SESSION['AP_user_profil']=="DT" || $_SESSION['AP_user_profil']=="CC"){?>
                                        <td align="center" nowrap="nowrap">
                                        <?php if($cht_etat==1){?>
                                        <div><button class="btnLien btn-link ButtonModifChantier" data-toggle="tooltip" data-placement="top" title="Modifier les infos du chantier <?php echo $cht_libelle; ?>" onclick="document.location.href='?yk=chantieradd&act=mod&cht=<?php echo $cht_id;?>'"><i class="fa fa-pencil fa-sm text-vert"></i>&nbsp;Modifier&nbsp;&nbsp;&nbsp;&nbsp;</button>&nbsp;</div>
                                          <div><button class="btnLien btn-link ButtonSuppChantier" data-toggle="tooltip" data-placement="top" title="Supprimer le chantier  <?php echo $cht_libelle; ?>"><i class="fa fa-trash-o fa-sm text-rouge"></i>&nbsp;Supprimer</button>&nbsp;</div>
										  <div><button class="btnLien btn-link ButtonAddTvxSuppl" data-toggle="tooltip" data-placement="top" title="G&eacute;rer les travaux suppl&eacute;mentaires" onclick="document.location.href='?yk=chantieradd2&act=supp&dev=<?php echo $cht_id;?>'"><i class="fa fa-plus-circle fa-sm text-orange"></i>&nbsp;Trvx. Supp.</button></div>
										  <?php }else{?><i class="fa fa-lock text-jaune" title="Aucune action disponible !"></i><?php }?>
                                          
                                          </td>
                                          <?php }?>
                                    </tr>
                                    <?php 
								}
									?>
                                </tbody>
                            </table>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                
              </div>
          </div>
      </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="modalOuvreEqp" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    <h4 class="modal-title" id="myModalLabel">Modal Equipe</h4>
</div>
<div class="modal-body">
    <table width="100%" class="table table-bordered table-hover" id="tb_addoutil">
      <thead>
          <tr>
              <th align="center">#</th>
              <th align="left">Equipe</th>
            </tr>
      </thead>
      <tbody>
          <tr class="even gradeA success">
              <td align="center">&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
      </tbody>
  </table>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times fa-lg"></i>&nbsp;&nbsp;Fermer</button>
</div>
</div>
<!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>
<!-- /.modal -->


<!-- Modal -->
<div class="modal fade" id="modalOuvrirDevisChant" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    <h4 class="modal-title" id="myModalLabel">Modal devis</h4>
</div>
<div class="modal-body">
    
</div>
<div class="modal-footer">
<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times fa-lg"></i>&nbsp;&nbsp;Fermer</button>
</div>
</div>
<!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<!-- Modal -->
<div class="modal fade" id="modalOuvrirFicheChantier" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header rapp55">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    <h4 class="modal-title" id="myModalLabel">FICHE SYNTHESE CHANTIER</h4>
</div>
<div class="modal-body rapp55">
    
</div>
<div class="modal-footer">
<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times fa-lg"></i>&nbsp;&nbsp;Fermer</button>
</div>
</div>
<!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<!-- Modal -->
<div class="modal fade" id="modalOuvrirFicheRapport" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header rapp55">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    <h4 class="modal-title" id="myModalLabel">FICHE RAPPORT CHANTIER</h4>
</div>
<div class="modal-body rapp55">
    
</div>
<div class="modal-footer">
<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times fa-lg"></i>&nbsp;&nbsp;Fermer</button>
</div>
</div>
<!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>
<!-- /.modal -->