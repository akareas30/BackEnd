<?php
session_start();
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php"); 
VerifTempsLog();

if(isset($_GET['id'])){
  $iddet  = $_GET['id'];
  $chp = "eq_id, eq_idcht, act_id, eq_hrnom, eq_hrcontact, act_libelle";
  $tb = CHANTIERS_EQP." LEFT JOIN ".ACTIVITES." ON eq_idact=act_id"; 
  $reqDet = selections($chp,$tb,"eq_id=$iddet","eq_id ASC");
  $resDet = $pdo->query($reqDet);	
  $donnees = $resDet->fetch();
  echo json_encode($donnees);
  $pdo=null;
}
?>