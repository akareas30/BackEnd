<div class="navbar-header">
  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
      <span class="sr-only">Toggle navigation</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
  </button>
  <a href="?" class="navbar-brand"><img src="img/logo_crb_head.png" width="240" height="70" class="img-responsive"></a>
</div>
<!-- /.navbar-header -->

<ul class="nav navbar-top-links navbar-right">
  <!-- /.dropdown -->
  <li class="dropdown">
      <a class="dropdown-toggle" data-toggle="dropdown" href="#">
          <i class="fa fa-bell fa-lg"></i> <i class="fa fa-caret-down"></i>
      </a>
      <ul class="dropdown-menu dropdown-alerts">
          <!--<li>
              <a href="#">
                  <div>
                      <i class="fa fa-twitter fa-fw"></i> 3 New Followers
                      <span class="pull-right text-muted small">12 minutes ago</span>
                  </div>
              </a>
          </li>-->
          <li class="divider"></li>
          <!--<li>
              <a href="#">
                  <div>
                      <i class="fa fa-envelope fa-fw"></i> Message Sent
                      <span class="pull-right text-muted small">4 minutes ago</span>
                  </div>
              </a>
          </li>-->
          <li class="divider"></li>
          <!--<li>
              <a href="#">
                  <div>
                      <i class="fa fa-tasks fa-fw"></i> New Task
                      <span class="pull-right text-muted small">4 minutes ago</span>
                  </div>
              </a>
          </li>-->
          <li class="divider"></li>
          <!--<li>
              <a class="text-center" href="#">
                  <strong>See All Alerts</strong>
                  <i class="fa fa-angle-right"></i>
              </a>
          </li>-->
      </ul>
      <!-- /.dropdown-alerts -->
  </li>
  <!-- /.dropdown -->
  <li class="dropdown">
      
          <a class="dropdown-toggle" data-toggle="dropdown" href="#"><?php echo $_SESSION['AP_user_prenom'].' '.$_SESSION['AP_user_nom'].' {'.$_SESSION['AP_user_profil'].'}'; ?>&nbsp;&nbsp;<i class="fa fa-user fa-lg"></i> <i class="fa fa-caret-down"></i></a>
      <ul class="dropdown-menu dropdown-user">
          <li><a href="?yk=compte&act=add"><i class="fa fa-user fa-fw"></i> Mon compte</a>
          </li>
          <li class="divider"></li>
          <li><a href="?d=<?php echo md5(time()); ?>"><i class="fa fa-sign-out fa-fw"></i> D&eacute;connexion</a>
          </li>
      </ul>
      <!-- /.dropdown-user -->
  </li>
  <!-- /.dropdown -->
</ul>
<!-- /.navbar-top-links -->