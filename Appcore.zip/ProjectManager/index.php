<?php 
session_start();
ini_set('session.bug_compat_42', 0);
ini_set('session.bug_compat_warn', 0);
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php"); 
//$_SESSION['AP_user_profil']	= "GM";
//$_SESSION['AP_iduser'] = 1;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
	<!--<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />-->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>PROJECT MANAGER - <?php 	echo $_SESSION['AP_user_prenom']." ".$_SESSION['AP_user_nom'];?></title>
	<link rel="shortcut icon" type="image/x-icon" href="img/crb.ico" />
    
    <link href="vendor/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="vendor/metisMenu/metisMenu.min.css" rel="stylesheet">
    
    <!-- DataTables CSS -->
    <link href="vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">
	<link href="dist/css/sb-admin.css" rel="stylesheet">
    <!-- Morris Charts CSS -->
    <link href="vendor/morrisjs/morris.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    
    <!-- Custom Autocomplete -->
    <link href="vendor/jQueryUI-autocomplete/jqueryui-autocomplete-bootstrap.css" rel="stylesheet">
    <link href="vendor/jquery-ui-1.12.1/jquery-ui-custom.css" rel="stylesheet">
    
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body class="fixed-nav sticky-footer" id="haut">
	<?php 
	VerifTempsLog();
	if (isset($_GET['d'])){
			Logout();
	}
	if($_SESSION['AP_deconexion']==1){?>
    <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="margin-bottom: 0">
        <?php include("head.php");?>
        <?php include("menu.php");?>
        </nav>
        
        <div id="page-wrapper" role="main">
            <?php 
			if(isset($_GET["yk"])){
				$LeFichier=$_GET["yk"]."_ap.php";
				if(file_exists($LeFichier)){
					include($LeFichier);
				}else{
					include("nopage.html"); 
				}
			}else{
 				include("home_ap.php");
			}
			?>
        </div>

    </div>

    <footer class="sticky-footer" role="contentinfo">
          <div class="container">
            <div class="text-center">
              <small>Copyright &copy; CRB <?php echo date("Y"); ?></small>
            </div>
          </div>
        </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#haut">
      <i class="fa fa-angle-up"></i>
    </a>
	<?php 
	}else{
	?><script language="javascript">document.location="log.php"</script><?php
	}
	?>
    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

	<!-- jQuery Validation -->
    <script src="vendor/jquery-validation/dist/jquery.validate.min.js"></script>
    
    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript 
    <script src="vendor/raphael/raphael.min.js"></script>
    <script src="vendor/morrisjs/morris.min.js"></script>
    <script src="data/morris-data.js"></script>-->

    <!-- Custom Theme JavaScript -->
    <script src="dist/js/sb-admin-2.js"></script>
    <script src="dist/js/sb-admin.min.js"></script>
    
    <!-- DataTables JavaScript -->
    <script src="vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="vendor/datatables-responsive/dataTables.responsive.js"></script>
    <script type="text/javascript" src="vendor/jQueryUI-autocomplete/jquery-ui-1.10.4.custom/development-bundle/ui/jquery.ui.core.js"></script>
	<script type="text/javascript" src="vendor/jQueryUI-autocomplete/jquery-ui-1.10.4.custom/development-bundle/ui/jquery.ui.widget.js"></script>
	<script type="text/javascript" src="vendor/jQueryUI-autocomplete/jquery-ui-1.10.4.custom/development-bundle/ui/jquery.ui.autocomplete.js"></script>
	<script type="text/javascript" src="vendor/jQueryUI-autocomplete/jquery-ui-1.10.4.custom/development-bundle/ui/jquery.ui.menu.js"></script>
	<script type="text/javascript" src="vendor/jQueryUI-autocomplete/jqueryui-autocomplete-bootstrap.js"></script>
    <script type="text/javascript" src="vendor/jquery-ui-1.12.1/jquery-ui.min.js"></script>
    
        <!-- Flot Charts JavaScript -->
    <script src="vendor/flot/excanvas.min.js"></script>
    <script src="vendor/flot/jquery.flot.js"></script>
    <script src="vendor/flot/hashtable.js"></script>
    <script src="vendor/flot/jquery.numberformatter-1.2.3.min.js"></script>
    <script src="vendor/flot/jquery.flot.pie.js"></script>
<!--    <script src="vendor/flot/jquery.flot.resize.js"></script>-->
    <script src="vendor/flot/jquery.flot.time.js"></script>
    <script src="vendor/flot-tooltip/jquery.flot.tooltip.min.js"></script>
    <script src="data/flot-data.js"></script>
    <script src="js/appcore.js"></script>
        
<script>
$(document).ready(function() {
  $("#formCreActivite").validate();
  $("#formModAct").validate();
  $("#formAddOutil").validate();
  $("#formModifOutil").validate();
  $("#formCreUser").validate();
  $("#formModUser").validate();
  $("#formCreClt").validate();
  $("#formModClt").validate();
  $("#formAddDetOut").validate();
  $("#formModifDevis").validate();
  $("#formAddChantier").validate();
  $("#formAddDetTache").validate();
  $("#formModChantier").validate();
  $("#formAddDevis").validate({
	rules: {
	  objet: {
		required: true,
		maxlength: 150
	  }
	},
	messages: {
	  objet: {
		maxlength: jQuery.validator.format("{0} Caract&egrave;res maximum autoris&eacute;s pour ce champ !")
	  }
	}
  });
  
  $("#formMajCpteGle").validate();
  
  $("#formMajCpteMdp").validate({
	rules: {
	  mdpnew: "required",
	  mdpnew_conf: {
		equalTo: "#mdpnew"
	  }
	},
	messages: {
	  mdpnew_conf: {
		equalTo: jQuery.validator.format("Les deux mots de passe ne concordent pas!")
	  }
	}
  });
});    
</script> 
 
<script>
$(document).ready(function() {
	$('#tb_listestand').DataTable({
		responsive: true,
		columnDefs: [
			{
				"bSortable": false,
				"aTargets": [-1, -2, 0]
			}
		]
	});
	
	$('#tb_listestand_outil').DataTable({
		responsive: true,
		columnDefs: [
			{
				"bSortable": false,
				"aTargets": [-1, -2, -3, 0]
			}
		]
	});
	
	$('#tb_addoutil').DataTable({
		responsive: true,
		orderable: false,
		bFilter: true,
		bSort: false,
		bLengthChange: true,
		lengthMenu:[[20,40,60,75,100,-1],[20,40,60,75,100,"Toutes les"]],
		//lengthMenu:[10,25,50,75,100],
	});
	
	$('#tb_devisdet').DataTable({
		responsive: true,
		orderable: false,
		bFilter: false,
		bSort: false,
		bLengthChange: false,
		bInfo: false, 
		paging: false
	});
	
	$('#tb_adddevis').DataTable({
		responsive: true,
		orderable: false,
		bFilter: false,
		bSort: false,
		bLengthChange: true,
		lengthMenu:[[20,40,60,75,100,-1],[20,40,60,75,100,"Toutes"]],
		//lengthMenu:[10,25,50,75,100],
	});
	
	$('#tb_adddmd').DataTable({
		responsive: true,
		orderable: false,
		bFilter: false,
		bSort: false,
		bLengthChange: true,
		lengthMenu:[[20,40,60,75,100,-1],[20,40,60,75,100,"Toutes"]],
		//lengthMenu:[10,25,50,75,100],
	});
	
	$('#tb_addtache').DataTable({
		responsive: true,
		orderable: false,
		bFilter: false,
		bSort: false,
		bLengthChange: true,
		lengthMenu:[[20,40,60,75,100,-1],[20,40,60,75,100,"Toutes les"]],
		//lengthMenu:[10,25,50,75,100],
	});
	
	$('#tb_plann').DataTable({
		responsive: true,
		orderable: false,
		bFilter: true,
		bSort: false,
		bLengthChange: true,
		lengthMenu:[[20,40,60,75,100,-1],[20,40,60,75,100,"Toutes les"]],
		//lengthMenu:[10,25,50,75,100],
	});
	
	$('#tb_addeqp').DataTable({
		responsive: true,
		orderable: false,
		bFilter: false,
		bSort: false,
		bLengthChange: true,
		lengthMenu:[[20,40,60,75,100,-1],[20,40,60,75,100,"Toutes"]],
		//lengthMenu:[10,25,50,75,100],
	});
	
	$('#tb_gestdevis').DataTable({
		responsive: true,
		columnDefs: [
			{
				"bSortable": false,	"aTargets": [-1, -2, -3, 0]
			}
		]
	});
	
	$('#tb_dmdetatsorti').DataTable({
		responsive: true,
		columnDefs: [
			{
				"bSortable": false,	"aTargets": [0]
			}
		]
	});
	
	$('#tb_gestchantier').DataTable({
		responsive: true,
		columnDefs: [
			{
				"bSortable": false,	"aTargets": [-1, -2, -3, -4, 0, 2, 3, 4, 5]
			}
		]
	});
	
});
</script>
<?php $pdo=null;?>
</body>

</html>
