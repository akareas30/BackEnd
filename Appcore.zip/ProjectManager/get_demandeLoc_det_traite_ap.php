<?php 
session_start();
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php");
VerifTempsLog();

if(isset($_GET['id'])){
	$IdDmd0 = (int)$_GET['id'];
}
$chp = "dmd_id, dmd_ref, dmd_type_clt, dmd_clt, dmd_date_cre";
$reqDet = selections($chp,DEMANDES,"dmd_id=$IdDmd0","dmd_id DESC");
$resDet = $pdo->query($reqDet);	
$col = $resDet->fetch();
$dmd_id 		= $col['dmd_id'];
$dmd_ref 		= $col['dmd_ref'];
$dmd_type_clt	= $col['dmd_type_clt'];
$dmd_clt 		= $col['dmd_clt'];
$dmd_date_cre 	= $col['dmd_date_cre'];

if($dmd_type_clt==0)$typeClt = "Particulier";
elseif($dmd_type_clt==1)$typeClt = "Soci&eacute;t&eacute;";
else $typeClt="";
?>

<div class="row">
  <div class="col-sm-12">
      <h4 class="rapp">REF. DEMANDE: <span class="text-rouge"><?php echo $dmd_ref;?></span></h4>
  </div>
</div>
<div class="row page-header-st">
  <div class="col-sm-12">
      <div><h5>CLIENT: <span class="text-rouge"><?php echo $dmd_clt." <span class=small><em>(".$typeClt.")</em></span>";?></span></h5></div>
  </div>
</div>


<?php 
$chp = "dmddet_id, outilref_id, outilref_libelle, outilref_ref, outilref_descrip, outilref_prixloc_part, outilref_prixloc_soc, dmddet_nbrejrs, dmddet_etat_enreg, dmddet_etat_acc, dmddet_etat_traite";
$tbl = DEMANDES_DET." LEFT JOIN ".OUTILS_REF." ON dmddet_outils=outilref_id";
$cnd = "dmddet_dmdid=$IdDmd0 AND dmddet_etat_enreg=1 AND (dmddet_etat_acc=0 OR dmddet_etat_acc=1)";
$reqDet = selections($chp,$tbl,$cnd,"dmddet_id DESC");
$resDet = $pdo->query($reqDet);
?>
<div class="row">
  <div class="col-sm-12">
        <table width="100%" class="table tableDetDevis table-bordered">
        <thead>
             <tr>
                <th align="left">Outil demand&eacute;</th>
                <th align="left">Description</th>
                <th align="center">Nbre Jr</th>
                <th align="right">PU/Jr</th>
                <th align="right">Co&ucirc;t</th>
                <th align="left" nowrap="nowrap">R&eacute;f&eacute;rence</th>
            </tr>
        </thead>        
        <?php 
		  $i = 0;
		  $montant = 0;
		  $Total = 0;
		  while($col = $resDet->fetch()){
			$dmddet_id 		 	= $col['dmddet_id'];
			$dmddet_outils 	 	= $col['outilref_id'];
			$outil_libelle 	 	= $col['outilref_libelle'];
			$outil_prix_loc_part = $col['outilref_prixloc_part'];
			$outil_prix_loc_scte = $col['outilref_prixloc_soc'];
			$dmddet_nbrejrs 	 = $col['dmddet_nbrejrs'];
			$outilref_ref		= $col['outilref_ref'];
			$outilref_descrip	= $col['outilref_descrip'];
			$dmddet_etat_enreg 	= $col['dmddet_etat_enreg'];
			$dmddet_etat_acc	= $col['dmddet_etat_acc'];
			$dmddet_etat_traite	= $col['dmddet_etat_traite'];
	
			if($dmd_type_clt==0)$Prix = $outil_prix_loc_part;
			elseif($dmd_type_clt==1)$Prix = $outil_prix_loc_scte;
			else $Prix = "";
			$montant = $dmddet_nbrejrs*$Prix ;
			$i++;
			?>
			  <tr class="even gradeA" data-numligne="<?php echo $i; ?>">
				  <td><?php echo "<strong>".$outil_libelle."</strong>";?></td>
				  <td align="left"><?php echo nl2br($outilref_descrip); ?></td>
				  <td align="center"><?php echo $dmddet_nbrejrs; ?></td>
				  <td align="right"><?php echo number_format($Prix,0,'',' '); ?></td>
				  <td align="right"><?php echo number_format($montant,0,'',' '); ?></td>
				  <td align="left"><?php echo $outilref_ref; ?></td>
			  </tr>    
			  <?php 
			  $Total+=$montant;
		  }
			  ?>
		  </tbody>
		  <tfoot>
			  <tr>
				<th colspan="4" align="right">Total</th>
				<th align="right"><?php echo number_format($Total,0,'',' '); ?></th>
				<th align="center">&nbsp;</th>
			  </tr>
		   </tfoot>        
    </table>
	</div>
</div>