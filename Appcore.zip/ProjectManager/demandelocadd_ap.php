<?php if(isset($_GET['act']) and  $_GET['act']=="add"){ ?>
<div class="row">
  <div class="col-lg-12">
      <h3 class="page-header">ENREGISTRER UNE DEMANDE DE LOCATION</h3>
  </div>
  <div class="col-lg-12">
      <h4>ETAPE 1/2: INFOS GENERALES DE LA DEMANDE</h4>
  </div>
  <!-- /.col-lg-12 -->
</div>
<?php 
if(isset($_POST['suiv'])){
	$typeclt = trim($_POST['typeclt']);
	$libclt  = htmlentities(strtoupper(trim(addslashes($_POST['libclt']))));
	
	$ref = getRefDmd(0);
   
	if($typeclt=="" or $libclt==""){
	  ?><div class="alert alert-warning alert-dismissable">
	  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
	  <?php echo TXT_AVERT_CHP_OBLIGE; ?></div><?php
	}else{	
	   $tb = DEMANDES."(dmd_ref, dmd_type, dmd_type_clt, dmd_clt, dmd_date_cre, dmd_user_cre)";
	   $val = "'$ref',0,'$typeclt','$libclt',NOW(),".$_SESSION['AP_iduser'];
	   if($IdDmd0 = AjoutBDGetId($tb,$val)){
		   ?><script language="javascript">document.location="?yk=demandelocadd2&svt&dev=<?php echo $IdDmd0;?>"</script><?php
	   }else{
		   ?><div class="alert alert-danger alert-dismissable">
		  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
		  <?php echo TXT_ALERT_ERROR_ENREG; ?></div><?php
	   }
	}
}
?>
<!-- /.row -->
<div class="row">
  <div class="col-lg-12">
      <div class="panelglobal panel-default-global">
          <form role="form" action="" method="post" id="formAddDevis">
          <div class="panel-body">
              <div class="row">              
                  <div class="col-lg-6">
                    <div class="form-group">
                        <label>Type Client *</label>
                        <select name="typeclt" id="typeclt" class="form-control" required="required">
                         <option value="">-- Type de client --</option>
                         <option value="0" <?php if($typeclt=="0"){?>selected="selected"<?php }?>>PARTICULIER</option>
                         <option value="1" <?php if($typeclt=="1"){?>selected="selected"<?php }?>>SOCI&Eacute;T&Eacute;</option>
                         </select>
                     </div>
                     <div class="form-group">
                        <label>Client *</label>
                        <input class="form-control" id="libclt" name="libclt" placeholder="Le nom du client..." type="text" required="required">
                     </div>
                  </div>
              </div>
              <div class="row">
              <div class="col-lg-4 center-block">
                  <button name="suiv" id="suiv" type="submit" class="btn btn-warning btn-block">&nbsp;Suivant pour les d&eacute;tails...&nbsp;<i class="fa fa-long-arrow-right fa-lg"></i></button>
                  <p class="help-block">Cliquer sur Suivant pour saisir les d&eacute;tails de la demande</p>
              </div>
              </div>
          </div>
          </form>
      </div>
  </div>
</div>
<?php 
}

if(isset($_GET['act']) and $_GET['act']=="mod"){
	$IdDmd0 = $_GET['dev'];
	$reqLib = selections("dmd_id, dmd_type_clt, dmd_clt, dmd_etat_approuv",DEMANDES,"dmd_id=$IdDmd0",1);
	$res = $pdo->query($reqLib);
	$col = $res->fetch();
	$old_dmd_id 		= $col['dmd_id'];
	$old_dmd_type_clt 	= $col['dmd_type_clt'];
	$old_dmd_clt 		= $col['dmd_clt'];
	$dmd_etat_approuv	= $col['dmd_etat_approuv'];
	
	if($dmd_etat_approuv==0){
	?>
	<div class="row">
	  <div class="col-lg-12">
		  <h3 class="page-header">MODIFIER UNE DEMANDE DE LOCATION</h3>
	  </div>
	  <div class="col-lg-12">
		  <h4>SAISIR LES INFOS A MODIFIER</h4>
	  </div>
	  <!-- /.col-lg-12 -->
	</div>
	<?php 
	
	if(isset($_POST['modif']) or isset($_POST['modifSuiv'])){
		$typeclt = trim($_POST['typeclt']);
		$libclt  = htmlentities(strtoupper(trim(addslashes($_POST['libclt']))));
		
		if($typeclt=="" or $libclt==""){
			?><div class="alert alert-warning alert-dismissable">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			<?php echo TXT_AVERT_CHP_OBLIGE; ?></div><?php
		}else{	
		 $mod = "dmd_type_clt='$typeclt', dmd_clt='$libclt', dmd_date_mod=NOW(), dmd_user_mod=".$_SESSION['AP_iduser'];
		 if(!update(DEMANDES,$mod,"dmd_id=$old_dmd_id")===true){
			 ?><div class="alert alert-success alert-dismissable">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			<?php echo TXT_ALERT_SUCCES_MODIF; ?></div>
			<?php 
			if(isset($_POST['modif'])){?>
				<script language="javascript">document.location="?yk=demandegestLoc&act=add"</script><?php
			}elseif(isset($_POST['modifSuiv'])){?>
				<script language="javascript">document.location="?yk=demandelocadd2&svt&dev=<?php echo $old_dmd_id;?>"</script><?php
			}else{?>
				<script language="javascript">document.location="?yk=demandegestLoc&act=add"</script><?php
				}
		 }else{
			 ?><div class="alert alert-danger alert-dismissable">
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			<?php echo TXT_ALERT_ERROR_MODIF; ?></div><?php
		 }
		}
		
	}
	
	?>
	<!-- /.row -->
	<div class="row">
	  <div class="col-lg-12">
		  <div class="panelglobal panel-default-global">
			  <form role="form" action="" method="post" id="formModifDevis">
			  <div class="panel-body">
				  <div class="row">              
					  <div class="col-lg-6">
						<div class="form-group">
							<label>Type Client *</label>
							<select name="typeclt" id="typeclt" class="form-control" required="required">
							 <option value="">-- Type de client --</option>
							 <option value="0" <?php if($old_dmd_type_clt=="0"){?>selected="selected"<?php }?>>PARTICULIER</option>
							 <option value="1" <?php if($old_dmd_type_clt=="1"){?>selected="selected"<?php }?>>SOCI&Eacute;T&Eacute;</option>
							 </select>
						 </div>
						 <div class="form-group">
							<label>Client *</label>
							<input class="form-control" id="libclt" name="libclt" value="<?php echo $old_dmd_clt; ?>" placeholder="Le nom du client..." type="text" required="required">
						 </div>
					  </div>
				  </div>
				  <div class="row">
				  <div class="col-lg-4 center-block" id="blcModDevisSuiv">
					  <button name="modifSuiv" id="modifSuiv" type="submit" class="btn btn-warning  btn-block" onClick="return confirm('Confirmez-vous la modification ?');"><i class="fa fa-save fa-lg"></i>&nbsp;&nbsp;Modifier la demande et &eacute;diter les d&eacute;tails</button>
					  <p class="help-block"><?php echo TXT_AVERT_CHP_OBLIGE; ?></p>
				  </div>
				  <div class="col-lg-4 center-block">
					  <button name="modif" id="modif" type="submit" class="btn btn-success btn-block" onClick="return confirm('Confirmez-vous la modification ?');"><i class="fa fa-save fa-lg"></i>&nbsp;&nbsp;Modifier et Terminer</button><p class="help-block">&nbsp;</p>
				  </div>
				  <div class="col-lg-4">
					  <a href="?yk=demandegestLoc&act=add" class="btn btn-danger btn-block"><i class="fa fa-undo fa-lg"></i>&nbsp;&nbsp;Annuler</a>
				  </div>
				  </div>
			  </div>
			  </form>
		  </div>
	  </div>
	</div>
	<?php 
  }else{?>
	<div class="row">
		<div class="col-lg-12">
			<div>Modification impossible car demande a d&eacute;j&agrave; &eacute;t&eacute; trait&eacute;e pour les sorties</div>
		</div>
	</div><?php
	}
}
?>