<?php if(isset($_GET['act']) and  $_GET['act']=="add"){ ?>
<div class="row">
  <div class="col-lg-12">
      <h3 class="page-header">ENREGISTRER UN CLIENT</h3>
  </div>
  <div class="col-lg-12">
      <h4>SAISIR LES INFOS CLIENTS</h4>
  </div>
  <!-- /.col-lg-12 -->
</div>

<div class="row">
  <div class="col-lg-6">
<?php 
if(isset($_POST['enreg'])){
	$nom    = strtoupper(trim(addslashes($_POST['nom'])));
	$typeclt = strtoupper(trim(addslashes($_POST['typeclt'])));
	$sigle  = strtoupper(trim(addslashes($_POST['sigle'])));
	$interloc = strtoupper(trim(addslashes($_POST['interloc'])));
	$email  = trim(addslashes($_POST['email']));	
	$tel  = trim(addslashes($_POST['tel']));
	$adresse = strtoupper(trim(addslashes($_POST['adresse'])));
	$ncc = strtoupper(trim(addslashes($_POST['ncc'])));
	
	if($sigle=="")$sigle=$nom;
	//$code = "";

	if($nom=="" or $typeclt==""){
		?><div class="alert alert-warning alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <?php echo TXT_AVERT_CHP_OBLIGE; ?></div><?php
	}else{	
	 $tb = CLIENTS."(clt_type,clt_nom,clt_abrege,clt_code,clt_tel1,clt_mail,clt_ncc,clt_localisation,clt_interloc,clt_user_cre,clt_date_cre)";
	 
	 $val = "'$typeclt','$nom','$sigle','$code','$tel','$email','$ncc','$adresse','$interloc',".$_SESSION['AP_iduser'].",NOW()";
	 if(!AjoutBD($tb,$val)===true){
		 ?><div class="alert alert-success alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <?php echo TXT_ALERT_SUCCES_ENREG; ?></div><?php
	 }else{
		 ?><div class="alert alert-danger alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <?php echo TXT_ALERT_ERROR_ENREG; ?></div><?php
	 }
	}
}
?>
  </div>
</div>
<!-- /.row -->
<div class="row">
  <div class="col-lg-12">
      <div class="panelglobal panel-default-global">
          <form role="form" action="" method="post" id="formCreClt">
          <div class="panel-body">
              <div class="row">
                  <div class="col-lg-6">
                  <div class="form-group">
                  <label>Type Client *</label>
                    <select name="typeclt" id="typeclt" class="form-control" required="required">
                     <option value="">-- Type de client --</option>
                     <option value="0" <?php if($typeclt=="0"){?>selected="selected"<?php }?>>PARTICULIER</option>
                     <option value="1" <?php if($typeclt=="1"){?>selected="selected"<?php }?>>SOCI&Eacute;T&Eacute;</option>
                   </select>
                   </div>
                    <div class="form-group">
                        <label>D&eacute;signation *</label>
                        <input name="nom" id="nom" type="text" class="form-control" placeholder="Le nom du client" required="required" value="<?php echo $nom; ?>">
                    </div>
                    <div class="form-group">
                        <label>Sigle ou abbr&eacute;viation</label>
                        <input name="sigle" id="sigle" type="text" class="form-control" placeholder="Le sigle ou l'abbr&eacute;viation" value="<?php echo $sigle; ?>">
                    </div>
                    <div class="form-group">
                        <label>Interlocuteur</label>
                        <input name="interloc" id="interloc" type="text" class="form-control" placeholder="Notre interlocuteur chez le client" value="<?php echo $interloc; ?>">
                    </div>
                  </div>
                  <!-- /.col-lg-6 (nested) -->
                  <div class="col-lg-6">
                    <div class="form-group">
                    <label>T&eacute;l&eacute;phone</label>
                    <input name="tel" id="tel" type="tel" class="form-control" placeholder="Le num&eacute;ro de t&eacute;l&eacute;phone" value="<?php echo $tel; ?>">
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input name="email" id="email" type="email" class="form-control" placeholder="L'adresse mail" value="<?php echo $email; ?>" >
                    </div>
                    <div class="form-group">
                        <label>Adresse</label>
                        <input name="adresse" id="adresse" type="text" class="form-control" placeholder="L'adresse du client" value="<?php echo $adresse; ?>"  >
                    </div>
                    <div class="form-group">
                        <label>NCC </label>
                        <input name="ncc" id="ncc" type="text" class="form-control" placeholder="Le num&eacute; NCC" value="<?php echo $ncc; ?>" >
                    </div>
                  </div>
              </div>
              <div class="row">
              <div class="col-lg-4 center-block">
                  <button name="enreg" id="enreg" type="submit" class="btn btn-success btn-block"><i class="fa fa-save fa-lg"></i>&nbsp;&nbsp;Enregistrer</button>
                  <p class="help-block"><?php echo TXT_AVERT_CHP_OBLIGE; ?></p>
              </div>&nbsp;
              <div class="col-lg-4 center-block">
                  <a href="?yk=client&amp;act=li" class="btn btn-danger btn-block"><i class="fa fa-undo fa-lg"></i>&nbsp;&nbsp;Annuler</a>
              </div>
              </div>
          </div>
          </form>
      </div>
  </div>
</div>
<?php 
}
?>


<?php if(isset($_GET['act']) and  $_GET['act']=="li"){ ?>
<div class="row">
  <div class="col-lg-12">
      <h3 class="page-header">LISTE DES CLIENTS</h3>
  </div>
</div>
<!-- /.row -->
<?php
if (isset($_POST['rfind'])){
	$per = "";
	if($_POST['typeclt']!=""){
		$typeclt=addslashes(strtoupper(trim($_POST['typeclt']))); 
		$Rechwhere.= " AND clt_type=$typeclt"; 
   }
	 if($_POST['etat']!=""){
		$etat=trim($_POST['etat']); 
		$Rechwhere.= " AND clt_etat=$etat"; 
   }
		   
}
?>
<div class="row">
  <div class="col-lg-12">
      <div class="panelglobal panel-default-global">
          <div class="panel-body">
              <div class="row">
              <div class="col-lg-12">
                    <div class="panelrech panel-default">
                      <div class="panel-heading-rech">Zone de recherche</div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
              				<form role="form" method="post" id="rechClt">
                  <div class="col-lg-3">
                    <div class="form-group input-group">
                       <span class="input-group-addon">Type client</span>
                        <select name="typeclt" id="typeclt" class="form-control">
                     <option value="">-- Type de client --</option>
                     <option value="0" <?php if($typeclt=="0"){?>selected="selected"<?php }?>>PARTICULIER</option>
                     <option value="1" <?php if($typeclt=="1"){?>selected="selected"<?php }?>>SOCI&Eacute;T&Eacute;</option>
                   </select>
                    </div>
                  </div>
                  <div class="col-lg-3">
                    <div class="form-group input-group">
                       <span class="input-group-addon">Etat</span>
                        <select name="etat" id="etat" class="form-control">
                     <option value="">-- Tout --</option>
                     <option value="1">ACTIF</option>
                     <option value="0">INACTIF</option>
                   </select>
                    </div>
                  </div>
                  <div class="col-lg-3">
                  <button type="submit" class="btn btn-primary btn-block" name="rfind" id="rfind">Rechercher&nbsp;&nbsp;<i class="glyphicon glyphicon-search"></i></button>
                  </div>
               </form>
               			</div>
                    </div>
               </div>
               <?php 
				  $chp = "clt_id, clt_type, clt_nom, clt_abrege, clt_code, clt_tel1, clt_mail, clt_ncc, clt_localisation, clt_interloc, clt_user_cre, clt_date_cre, clt_etat";
			  
				  $cnd = "1 $Rechwhere";
				  $req = selections($chp,CLIENTS,$cnd,"clt_id DESC");//echo $req;
				  $res = $pdo->query($req);
			   ?>
               <div class="col-lg-12">
                             <table width="100%" class="table table-bordered table-hover" data-page-length='10' id="tb_listestand" >
                                <thead>
                                    <tr>
                                        <th align="center">#</th>
                                        <th align="left">Client</th>
                                        <th align="left">Interlocuteur</th>
                                        <th align="left">Type</th>
                                        <th align="left">Contact</th>
                                        <th align="center">Etat</th>
                                        <th align="center">Modif.</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php 
								$i=0;
								while($col = $res->fetch()){
									$clt_id 			= $col['clt_id'];
									$clt_type 			= $col['clt_type'];
									$clt_nom	 		= $col['clt_nom'];
									$clt_abrege 		= $col['clt_abrege'];
									$clt_code 			= $col['clt_code'];
									$clt_tel1 	 		= $col['clt_tel1'];
									$clt_mail  			= $col['clt_mail'];
									$clt_ncc 			= $col['clt_ncc'];
									$clt_localisation 	= $col['clt_localisation'];
									$clt_interloc 	 	= $col['clt_interloc'];
									$clt_user_cre  		= $col['clt_user_cre'];
									$clt_date_cre 		= $col['clt_date_cre'];
									$clt_etat 	 		= $col['clt_etat'];
									$i++;
									if($clt_nom!=$clt_abrege)$clt_nom="<strong>".$clt_nom."</strong> (".$clt_abrege.")";
									else $clt_nom="<strong>".$clt_nom."</strong>";
									
									if($clt_type==0)$typeClt="PARTICULIER"; else $typeClt="SOCI&Eacute;T&Eacute;";
								?>
                                    <tr class="even gradeA success">
                                        <td align="center"><?php echo $i;?></td>
                                        <td><?php echo $clt_nom;if(!empty($clt_date_cre))echo "<br /><span class=small><em>Ajout&eacute; le ".getdateL($clt_date_cre)."</em></span>";?></td>
                                        <td><?php echo $clt_interloc; ?></td>
                                        <td><?php echo $typeClt; ?></td>
                                        <td><?php 
										if(!empty($clt_tel1))echo '<i class="fa fa-phone"></i>&nbsp;'.$clt_tel1;
										if(!empty($clt_mail))echo '<br /><i class="fa fa-envelope-o"></i>&nbsp;'.$clt_mail;
										if(!empty($clt_localisation))echo '<br /><i class="fa fa-location-arrow"></i>&nbsp;'.$clt_localisation;?></td>
                                        <td align="center" class="center">
                                        <?php 
										if($clt_etat == 1){?>											
										<button class="btn btn-link ButtonActiver" value="1" data-id="<?php echo $clt_id;?>" data-toggle="tooltip" data-placement="top" data-tb="myCltTb" title="Actif: Cliquez pour D&eacute;sactiver"><i class="fa fa-check-circle fa-lg text-vert"></i></button>
                                        <button class="btn btn-link ButtonDesactiver" value="0" data-id="<?php echo $clt_id;?>" data-toggle="tooltip" data-placement="top" data-tb="myCltTb" title="Inactif: Cliquez pour Activer" style="display:none;"><i class="fa fa-minus-circle fa-lg text-jaune"></i></button><?php 
										}else {?>
										<button data-tb="myCltTb" class="btn btn-link ButtonActiver" value="1" data-id="<?php echo $clt_id;?>" data-toggle="tooltip" data-placement="top" title="Actif: Cliquez pour D&eacute;sactiver" style="display:none;"><i class="fa fa-check-circle fa-lg text-vert"></i></button>
                                        <button data-tb="myCltTb" class="btn btn-link ButtonDesactiver" value="0" data-id="<?php echo $clt_id;?>" data-toggle="tooltip" data-placement="top" title="Inactif: Cliquez pour Activer"><i class="fa fa-minus-circle fa-lg text-jaune"></i></button> <?php 
										}?>
                                        </td>
                                     <td align="center" class="center">
                                     <div data-toggle="tooltip" data-placement="top" title="Modifier <?php echo $clt_abrege; ?>">
                                <button class="btn btn-link editClient" data-id="<?php echo $clt_id;?>" data-toggle="modal" data-backdrop="static" ><i class="fa fa-pencil fa-lg"></i></button></div>
                                      </td>
                                    </tr>
									<?php 
								}
									?>
                                </tbody>
                            </table>
                        <!--</div>
                    </div>-->
                </div>
              </div>
          </div>
      </div>
  </div>
</div>
<!-- Modal -->
<div class="modal fade" id="ModalModifClt" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">           
            <div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
<h4 class="modal-title" id="myModalLabel">Modifier</h4>
            </div>
<div class="row">
  <div class="col-lg-12">
      <div class="panelglobal panel-default-global">
          <form action="update_info_clt.php" method="POST" id="formModClt">
          <div class="panel-body">
              <div class="row">
                  <div class="col-lg-6">
                  <div class="form-group">
                  <input name="id" id="id" type="hidden" value="" />
                    <input name="dateadd" id="dateadd" type="hidden" value="" />
                  <label>Type Client *</label>
                    <select name="typeclt" id="typeclt" class="form-control" required="required">
                     <option value="">-- Type de client --</option>
                     <option value="0">PARTICULIER</option>
                     <option value="1">SOCI&Eacute;T&Eacute;</option>
                   </select>
                   </div>
                    <div class="form-group">
                        <label>D&eacute;signation *</label>
                        <input name="nom" id="nom" type="text" class="form-control" placeholder="Le nom du client" required="required" value="">
                    </div>
                    <div class="form-group">
                        <label>Sigle ou abbr&eacute;viation</label>
                        <input name="sigle" id="sigle" type="text" class="form-control" placeholder="Le sigle ou l'abbr&eacute;viation" value="">
                    </div>
                    <div class="form-group">
                        <label>Interlocuteur</label>
                        <input name="interloc" id="interloc" type="text" class="form-control" placeholder="Notre interlocuteur chez le client" value="">
                    </div>
                  </div>
                  <!-- /.col-lg-6 (nested) -->
                  <div class="col-lg-6">
                    <div class="form-group">
                    <label>T&eacute;l&eacute;phone</label>
                    <input name="tel" id="tel" type="tel" class="form-control" placeholder="Le num&eacute;ro de t&eacute;l&eacute;phone" value="">
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input name="email" id="email" type="email" class="form-control" placeholder="L'adresse mail" value="" >
                    </div>
                    <div class="form-group">
                        <label>Adresse</label>
                        <input name="adresse" id="adresse" type="text" class="form-control" placeholder="L'adresse du client" value=""  >
                    </div>
                    <div class="form-group">
                        <label>NCC </label>
                        <input name="ncc" id="ncc" type="text" class="form-control" placeholder="Le num&eacute; NCC" value="" >
                    </div>
                  </div>
              </div>
          </div>
          </form>
      </div>
  </div>
</div>
            </div>
            <div class="modal-footer">
                 <button name="submitClt" id="submitClt" type="button" class="btn btn-success"><i class="fa fa-save fa-lg"></i>&nbsp;&nbsp;Modifier</button>
 
 <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times fa-lg"></i>&nbsp;&nbsp;Fermer</button>
 
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->   
<?php 
}
?>