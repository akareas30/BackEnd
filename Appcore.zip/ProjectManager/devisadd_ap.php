<?php if($_SESSION['AP_user_profil']!="CP" && $_SESSION['AP_user_profil']!="GM"){
	if(isset($_GET['act']) and  $_GET['act']=="add"){ ?>
<div class="row">
  <div class="col-lg-12">
      <h3 class="page-header">ENREGISTRER UN DEVIS</h3>
  </div>
  <div class="col-lg-12">
      <h4>ETAPE 1/2: INFOS GENERALES DU DEVIS</h4>
  </div>
  <!-- /.col-lg-12 -->
</div>
<?php 
if(isset($_POST['suiv'])){
	$avertis="";$succes="";$error="";
	$clientId   = strtoupper(trim(addslashes($_POST['clientId'])));
	$objet  	= htmlspecialchars(strtoupper(trim(addslashes($_POST['objet']))));
	$ref = getRefDevis();
   
	if($clientId=="" or $objet==""){
		?><div class="alert alert-warning alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <?php echo TXT_AVERT_CHP_OBLIGE; ?></div><?php
	}else{	
	 $tb = DEVIS."(dev_ref, dev_clt, dev_objet, dev_date_cre, dev_user_cre)";
	 $val = "'$ref','$clientId','$objet',NOW(),".$_SESSION['AP_iduser'];
	 if($IdDevis0 = AjoutBDGetId($tb,$val)){
		 ?><script language="javascript">document.location="?yk=devisadd2&svt&dev=<?php echo $IdDevis0;?>"</script><?php
	 }else{
		 ?><div class="alert alert-danger alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <?php echo TXT_ALERT_ERROR_ENREG; ?></div><?php
	 }
	}
}
?>
<!-- /.row -->
<div class="row">
  <div class="col-lg-12">
      <div class="panelglobal panel-default-global">
          <form role="form" action="" method="post" id="formAddDevis">
          <div class="panel-body">
              <div class="row">              
                  <div class="col-lg-6">
                    <div class="form-group">
                        <label>Client *</label>
                        <input class="form-control bs-autocomplete" id="libclt" value="" placeholder="Indiquez le client" type="text" data-source="get_rech_client.php" data-hidden_field_id="clientId" data-item_id="clt_id" data-item_label="clt_nom" autocomplete="off" autofocus="autofocus">
                        <input class="form-control" id="clientId" name="clientId" value="" type="hidden" readonly>
                     </div>
                     <div class="form-group">
                        <label>Objet *</label>
                        <textarea name="objet" rows="3" class="form-control" id="objet" placeholder="L'objet du devis"></textarea>
                    </div>
                    
                  </div>
              </div>
              <div class="row">
              <div class="col-lg-4 center-block">
                  <button name="suiv" id="suiv" type="submit" class="btn btn-warning btn-block">&nbsp;Suivant pour &eacute;diter le devis...&nbsp;<i class="fa fa-long-arrow-right fa-lg"></i></button>
                  <p class="help-block">Cliquer sur Suivant pour saisir les d&eacute;tails du devis</p>
              </div>
              </div>
          </div>
          </form>
      </div>
  </div>
</div>
<?php 
}

if(isset($_GET['act']) and $_GET['act']=="mod"){
	$iddevis = $_GET['dev'];
	$chp = "dev_id, dev_ref, dev_clt, dev_objet, C.clt_nom, dev_etat_accepte, dev_observ";
	$tb  = DEVIS." D LEFT JOIN ".CLIENTS." C ON D.dev_clt=C.clt_id";
	$cnd = "dev_id=$iddevis";
	$req = selections($chp,$tb,$cnd,"dev_id");
	$res = $pdo->query($req);
	$col = $res->fetch(); 
	
	$old_dev_id    = $col['dev_id'];
	$old_dev_ref   = $col['dev_ref'];
	$old_dev_clt   = $col['dev_clt'];
	$old_dev_objet = $col['dev_objet'];
	$old_clt_nom   = $col['clt_nom'];
	$old_dev_etat_accepte = $col['dev_etat_accepte'];
	$old_dev_observ   = $col['dev_observ'];
?>
<div class="row">
  <div class="col-lg-12">
      <h3 class="page-header">MODIFIER UN DEVIS</h3>
  </div>
  <div class="col-lg-12">
      <h4>SAISIR LES INFOS A MODIFIER</h4>
  </div>
  <!-- /.col-lg-12 -->
</div>
<?php 

if(isset($_POST['modif']) or isset($_POST['modifSuiv'])){
	$clientId   = strtoupper(trim(addslashes($_POST['clientId'])));
	$objet  	= htmlspecialchars(strtoupper(trim(addslashes($_POST['objet']))));
	$observ 	= htmlspecialchars(trim(addslashes($_POST['observ'])));
	$etat   	= strtoupper(trim(addslashes($_POST['etat'])));
	if(empty($etat))$etat=$old_dev_etat_accepte;
	 
	if($objet==""){
		?><div class="alert alert-warning alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <?php echo TXT_AVERT_CHP_OBLIGE; ?></div><?php
	}else{	
	 $mod = "dev_clt='$clientId', dev_objet='$objet',dev_date_mod=NOW(), dev_etat_accepte=$etat, dev_observ='$observ', dev_user_mod=".$_SESSION['AP_iduser'];
	 if(!update(DEVIS,$mod,"dev_id=$old_dev_id")===true){
		 ?><div class="alert alert-success alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <?php echo TXT_ALERT_SUCCES_MODIF; ?></div>
        <?php 
		if(isset($_POST['modif'])){?>
			<script language="javascript">document.location="?yk=devisgest&act=add"</script><?php
		}elseif(isset($_POST['modifSuiv']) and $etat==0){?>
			<script language="javascript">document.location="?yk=devisadd2&svt&dev=<?php echo $old_dev_id;?>"</script><?php
		}else{?>
			<script language="javascript">document.location="?yk=devisgest&act=add"</script><?php
			}
	 }else{
		 ?><div class="alert alert-danger alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <?php echo TXT_ALERT_ERROR_MODIF; ?></div><?php
	 }
	}
	
}

?>
<!-- /.row -->
<div class="row">
  <div class="col-lg-12">
      <div class="panelglobal panel-default-global">
          <form role="form" action="" method="post" id="formModifDevis">
          <div class="panel-body">
              <div class="row">              
                  <div class="col-lg-6">
                    <div class="form-group">
                        <label>Client *</label>
                        <input class="form-control bs-autocomplete" id="libclt" value="<?php echo $old_clt_nom; ?>" placeholder="Indiquez le client" type="text" data-source="get_rech_client.php" data-hidden_field_id="clientId" data-item_id="clt_id" data-item_label="clt_nom" autocomplete="off" disabled="disabled">
                        <input class="form-control" id="clientId" name="clientId" value="<?php echo $old_dev_clt; ?>" type="hidden" readonly>
                     </div>
                     <div class="form-group">
                        <label>Objet *</label>
                        <textarea name="objet" rows="3" class="form-control" id="objet" placeholder="L'objet du devis" autofocus="autofocus"><?php echo $old_dev_objet; ?></textarea>
                    </div>
                    
                  </div>
                  <div class="col-lg-6">
                  <?php if($_SESSION['AP_user_profil']=="AD" || $_SESSION['AP_user_profil']=="DG" || $_SESSION['AP_user_profil']=="DT"){
				?>
                    <div class="form-group">
                        <label>Changer le statut</label>
                        <select name="etat" id="etat" class="form-control">
                                 <option value="0" <?php if($old_dev_etat_accepte=="0"){?>selected="selected"<?php }?>>En attente</option>
                                 <option value="1" <?php if($old_dev_etat_accepte=="1"){?>selected="selected"<?php }?>>Accept&eacute;</option>
                                 <option value="10" <?php if($old_dev_etat_accepte=="10"){?>selected="selected"<?php }?>>R&eacute;fus&eacute;</option>
                                 <option value="11" <?php if($old_dev_etat_accepte=="11"){?>selected="selected"<?php }?>>Annul&eacute;</option>
                               </select>
                    </div>
                    <?php }?>
                     <div class="form-group">
                        <label>Observation</label>
                        <textarea name="observ" rows="3" class="form-control" id="observ" placeholder="Faire des observations"><?php echo $old_dev_observ; ?></textarea>
                    </div>
                    
                  </div>
              </div>
              <div class="row">
              <div class="col-lg-4 center-block" id="blcModDevisSuiv">
                  <button name="modifSuiv" id="modifSuiv" type="submit" class="btn btn-warning  btn-block" onClick="return confirm('Confirmez-vous la modification ?');"><i class="fa fa-save fa-lg"></i>&nbsp;&nbsp;Modifier le devis et &eacute;diter les d&eacute;tails</button>
                  <p class="help-block"><?php echo TXT_AVERT_CHP_OBLIGE; ?></p>
              </div>
              <div class="col-lg-4 center-block">
                  <button name="modif" id="modif" type="submit" class="btn btn-success btn-block" onClick="return confirm('Confirmez-vous la modification ?');"><i class="fa fa-save fa-lg"></i>&nbsp;&nbsp;Modifier et Terminer</button><p class="help-block">&nbsp;</p>
              </div>
              <div class="col-lg-4">
                  <a href="?yk=devisgest&act=add" class="btn btn-danger btn-block"><i class="fa fa-undo fa-lg"></i>&nbsp;&nbsp;Annuler</a>
              </div>
              </div>
          </div>
          </form>
      </div>
  </div>
</div>
<?php 
}
}else{
?><script language="javascript">document.location="index.php"</script><?php 
}
?>