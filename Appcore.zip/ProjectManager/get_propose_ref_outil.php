<?php
session_start();
ini_set('session.bug_compat_42', 0);
ini_set('session.bug_compat_warn', 0);
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php"); 
VerifTempsLog();

if(isset($_GET['dref'])){
  $dref = trim($_GET['dref']);
  $tail = trim($_GET['tail']);
  
  $chp = "SUBSTR(outilref_ref, 1, $tail) AS PREFX, COUNT(SUBSTR(outilref_ref, 1, $tail)) AS NBRE"; 
  $cnd = "SUBSTR(outilref_ref, 1, $tail) LIKE '$dref%' GROUP BY SUBSTR(outilref_ref, 1, $tail)";
  
  $req = selections($chp,OUTILS_REF,$cnd,1);
  $res = $pdo->query($req);
  $col = $res->fetch();
  $PREFX	= $col['PREFX'];
  $NBRE 	= $col['NBRE'];
  
  $pref = str_replace('-','',$dref);
  $pref = substr($pref,0,$tail);
  
  $NBRE++;
  while(strlen($NBRE)<3) $NBRE = '0'.$NBRE;
  $refPropose = $pref.'-'.date('y').'-'.$NBRE;
   
  $array = array($refPropose);
  echo json_encode($array);
}
?>
