<div class="row">
  <div class="col-lg-12">
      <h3 class="page-header">GESTION DES DEMANDES INTERNES</h3>
  </div>
  <!--<div class="col-lg-12">
      <h4>ETAPE 2/2: DETAILS DU DEMANDE D'OUTILS: <span class="text-rouge"><?php echo stripslashes($dmd_ref)."&nbsp;|&nbsp;".$dev_objet?></span></h4>
  </div>-->
  <!-- /.col-lg-12 -->
</div>


<!-- /.row -->
<div class="row">
 <div class="col-lg-12">
      <div class="panel panel-default">
          <div class="panel-heading">LISTE DES DEMANDES INTERNES &Agrave; G&Eacute;RER</div>
          <!-- /.panel-heading -->
          <div class="panel-body">
              <?php 
			  if($_SESSION['AP_user_profil']!="AD" && $_SESSION['AP_user_profil']!="DG" && $_SESSION['AP_user_profil']!="GM"){
				$cplmt = " AND dmd_user_cre=".$_SESSION['AP_iduser'];
			  }
              $chp = "dmd_id, dmd_ref, dmd_type, cht_libelle, dmd_demandeur, dmd_motif, dmd_date_cre, dmd_user_cre, dmd_etat_enreg, dmd_etat_approuv ,user_nom, user_prenom";
              $tb = "(".DEMANDES." D  LEFT JOIN ".USERS." U ON D.dmd_user_cre=U.user_id) LEFT JOIN ".CHANTIERS." C ON C.cht_id=D.dmd_chantier ";
              $cnd = "dmd_type=1 and dmd_etat_enreg=1 AND dmd_etat_approuv=0".$cplmt;
              $reqDet = selections($chp,$tb,$cnd,"dmd_id DESC");
              $resDet = $pdo->query($reqDet);							
              ?>
              <table width="100%" class="table table-striped table-bordered table-hover" id="tb_gestdevis">
                  <thead>
                      <tr>
                          <th width="2%" align="center">#</th>
                          <th width="25%" align="left">R&eacute;f.</th>
                          <th width="20%" align="left">Demandeur</th>
                          <th width="18%" align="left">Motif</th>
                          <th width="18%" align="left">Chantier</th>
                          <th width="4%" align="left">Statut</th>
                          <th width="8%" align="left">Actions</th>
                          <th width="5%" align="center">D&eacute;tails</th>
                      </tr>
                  </thead>
                  <tbody>
                  <?php 
                    $i = 0;
                    while($col = $resDet->fetch()){
                      $dmd_id 		 	= $col['dmd_id'];
                      $dmd_ref 	 		= $col['dmd_ref'];
                      $dmd_type			= $col['dmd_type'];
                      $cht_libelle	 	= $col['cht_libelle'];
                      $dmd_demandeur 	= $col['dmd_demandeur'];
                      $dmd_motif 		= $col['dmd_motif'];
                      $dmd_date_cre 	= $col['dmd_date_cre'];
                      $dmd_etat_enreg 	= $col['dmd_etat_enreg'];
					  $dmd_user_cre 	= $col['dmd_user_cre'];
					  $dmd_etat_approuv = $col['dmd_etat_approuv'];
                      $user_nom     	= $col['user_nom'];
                      $user_prenom 	    = $col['user_prenom'];
                      
                      if($dmd_etat_approuv==0) $statut = '<span class=text-bleu><i class="fa fa-pencil-square-o"></i>&nbsp;En attente</span>';
                        elseif($dmd_etat_approuv==1) $statut = '<span class=text-vert><i class="fa fa-check-square-o"></i>&nbsp;Trait&eacute;e</span>';
                        elseif($dmd_etat_approuv==2) $statut = '<span class=text-rouge><i class="fa fa-minus-circle"></i>&nbsp;Rej&eacute;t&eacute;e</span>';
                       
                      $i++;
                      ?>
                  <tr id="<?php echo $dmd_id;?>" class="even gradeA success">
                      <td align="center"><?php echo $i ?></td>
                      <td><?php echo "<strong>".$dmd_ref."</strong>";
              if(!empty($dmd_date_cre))echo "<br /><span class=small><em>Ajout&eacute; le ".getdateL($dmd_date_cre)."<br />Par ".$user_prenom." ".$user_nom."</em></span>";?></td>
                      <td><?php if($dmd_demandeur!="")echo "<strong>".$dmd_demandeur."</strong>";?></td>
                      <td><?php echo nl2br($dmd_motif); ?></td>
                      <td align="left"><?php echo nl2br($cht_libelle); ?></td>
                      <td align="center"><?php echo $statut; ?></td>
                      <td align="center" valign="middle">
                      <?php if($dmd_etat_approuv==0){                   
					  if($_SESSION['AP_iduser']==$dmd_user_cre){
					  ?>
                      <div><button class="btnLien btn-link ButtonModifDevis" data-toggle="tooltip" data-placement="top" title="Modifier les infos de la demande <?php echo $dmd_ref; ?>" onclick="document.location.href='?yk=demandeintadd&act=mod&dev=<?php echo $dmd_id;?>'"><i class="fa fa-pencil text-vert"></i>&nbsp;Modifier</button>&nbsp;&nbsp;&nbsp;&nbsp;</div>
                      <?php }?>
                     <div><button class="btnLien btn-link ButtonSuppDmdInt" data-toggle="tooltip" data-placement="top" title="Supprimer la demande  <?php echo $dmd_ref; ?>"><i class="fa fa-trash-o text-rouge"></i>&nbsp;Supprimer</button></div>
                      <?php if($_SESSION['AP_user_profil']=="AD" || $_SESSION['AP_user_profil']=="DG" || $_SESSION['AP_user_profil']=="GM"){?>
                     <div data-toggle="tooltip" data-placement="top" title="Traiter la demande">
                      <button class="btnLien btn-link ButtonOpenTraiteDmdInt" data-title="<?php echo $dmd_ref; ?>" data-toggle="modal" data-backdrop="static"><i class="fa fa-cog"></i>&nbsp;Traiter</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
                      <?php }?>
              
              <?php }else{?><i class="fa fa-lock text-jaune" title="Aucune action disponible !"></i><?php }?>
                        </td>
                      <td align="center">                      
                      <div data-toggle="tooltip" data-placement="top" title="Voir les d&eacute;tails de la demande <?php echo $dmd_ref; ?>">
                      <button class="btnLien btn-link ButtonOuvrirDetDmdInt" data-title="<?php echo $dmd_ref; ?>" data-toggle="modal" data-backdrop="static"><i class="fa fa-folder-open-o fa-lg text-bleu"></i></button>
                      <?php if($_SESSION['AP_user_profil']=="AD" || $_SESSION['AP_user_profil']=="DG" || $_SESSION['AP_user_profil']=="GM"){?>
                      <a href="demandeint_pdf.php?id=<?php echo $dmd_id; ?>" class="btnLien btn-link"><i class="fa fa-file-pdf-o fa-lg text-rouge"></i></a>
                      <?php }?>
                      </div>                      
                      </td>
                  </tr>
                  <?php 
              }
              ?>
              </tbody>
              </table>
              <!-- /.table-responsive -->
          </div>
          <!-- /.panel-body -->
      </div>
      <!-- /.panel -->
  </div>
                
              </div>
<!-- Modal -->
<div class="modal fade" id="ModalTraiteDmdInt" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header rapp55">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    <h4 class="modal-title" id="myModalLabel">TRAITEMENT DE DEMANDE INTERNE</h4>
</div>
<div class="modal-body rapp55">
    <!-- moda body -->
    <div id="enteteGestDmd">
    </div>
    <form method="post" id="formTraiteDmdInt" action="">
    <table width="100%" class="table tableDetDevis table-bordered" id="tb_traiteDmdInt">
        <thead>
             <tr>
                <th width="24%" align="left" nowrap="nowrap">Outil</th>
                <th width="43%" align="left" nowrap="nowrap">Description</th>
                <th width="20%" align="left" nowrap="nowrap">Référence</th>
                <th width="10%" align="center" nowrap="nowrap">Traiter</th>
                <th width="3%" align="center" nowrap="nowrap">Etat</th>
             </tr>
        </thead>
        <tbody>
        </tbody> 
    </table>
    </form>
    <!-- fin moda body -->
    
</div>
<div class="modal-footer">
<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times fa-lg"></i>&nbsp;&nbsp;Fermer</button>

</div>
</div>
<!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>
<!-- /.modal -->


<!-- Modal -->
<div class="modal fade" id="ModalDetailDmd" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header rapp55">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    <h4 class="modal-title" id="myModalLabel">DETAIL DE DEMANDE</h4>
</div>
<div class="modal-body rapp55">
    <!-- moda body -->
    <!-- fin moda body -->
    
</div>
<div class="modal-footer">
<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times fa-lg"></i>&nbsp;&nbsp;Fermer</button>
</div>
</div>
<!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>
<!-- /.modal -->