<?php 
session_start();
ini_set('session.bug_compat_42', 0);
ini_set('session.bug_compat_warn', 0);
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php");
include('inc/conv/class_conv.php');

if(isset($_GET['dev'])){
	$IdDevis0 = (int)$_GET['dev'];
}
$chp = "D.dev_ref, D.dev_objet, D.dev_date_cre, D.dev_moeuvre, C.clt_type, C.clt_nom, C.clt_abrege, C.clt_tel1, C.clt_ncc, C.clt_localisation";
$tb = DEVIS." D LEFT JOIN ".CLIENTS." C ON D.dev_clt=C.clt_id";
$cnd = "dev_id=$IdDevis0";

$reqLib = selections($chp,$tb,$cnd,1);
$res = $pdo->query($reqLib);
$col = $res->fetch();
$dev_ref 	= $col['dev_ref'];
$dev_objet 	= $col['dev_objet'];
$clt_type 	= $col['clt_type'];
$clt_nom 	= $col['clt_nom'];
$clt_abrege = $col['clt_abrege'];
$clt_tel1 	= $col['clt_tel1'];
$clt_ncc 	= $col['clt_ncc'];
$clt_localisation = $col['clt_localisation'];
$dev_date_cre = $col['dev_date_cre'];
$dev_moeuvre = $col['dev_moeuvre'];

$ref_format = str_replace("/","-",$dev_ref);
$filename = "DEVIS-".$ref_format.".doc";
header("Content-type: application/vnd.ms-word");
header("Content-Disposition: attachment; filename=$filename");

?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<div style="float:left; text-align:left;">
    <?php echo "<strong>R&eacute;f.:</strong> ".$dev_ref;?>
</div>
<div class="row">
  <div class="col-lg-12">&nbsp;</div>
</div>
<div style="float:right; text-align:right;">
    <?php 
	$formatter = new IntlDateFormatter('fr_FR',IntlDateFormatter::LONG, IntlDateFormatter::NONE, 'GMT', IntlDateFormatter::GREGORIAN );
	$date =new DateTime(date());
	echo "Abidjan, le ".$formatter->format($date);//affiche 14 février 2012
?>
</div>
<div class="row">
  <div class="col-lg-12">&nbsp;</div>
</div>
<div style="float:left;">
    <?php echo "<span style='text-decoration:underline'><strong>Objet :</strong></span>&nbsp;".stripslashes($dev_objet);?>
</div>
<div class="row">
  <div class="col-lg-12">&nbsp;</div>
</div>

<div style="float:right;">
  <table width="50%" border="1" align="right" cellpadding="0" cellspacing="0" style="border:1px solid #000000;">
  <tr valign="middle">
    <td nowrap="nowrap" style="border:none;"><strong>CLIENT</strong></td>
    <td nowrap="nowrap" style="border:none;"><span>: <?php echo $clt_abrege;?></span></td>
    </tr>
  <tr valign="middle">
    <td nowrap="nowrap" style="border:none;"><strong>N&deg; CC</strong></td>
    <td nowrap="nowrap" style="border:none;"><span>: <?php echo $clt_ncc; ?></span></td>
  </tr>
  <tr valign="middle">
    <td nowrap="nowrap" style="border:none;"><strong>ADRESSE</strong></td>
    <td nowrap="nowrap" style="border:none;"><span>: <?php echo $clt_localisation; ?></span></td>
  </tr>
  <tr valign="middle">
    <td nowrap="nowrap" style="border:none;"><strong>TEL</strong></td>
    <td nowrap="nowrap" style="border:none;"><span>: <?php echo $clt_tel1; ?></span></td>
  </tr>
  </table>
</div>
<div class="row">
  <div class="col-lg-12">&nbsp;</div>
</div><br />
<p>&nbsp;</p>
	<?php 
    $cnd1 = "devdet_devid=$IdDevis0 AND devdet_etat_enreg=1 GROUP BY devdet_rub1";
    $reqRub1 = selections("devdet_rub1",DEVIS_DET,$cnd1,"devdet_id DESC, devdet_rub1 ASC");//echo $reqRub1;
    $resRub1 = $pdo->query($reqRub1);	
	$i1 = 0;
	$totRubDevis = 0;
	$TotGleHT = 0;
	while($col1 = $resRub1->fetch()){
		$devdet_rub1 = $col1['devdet_rub1'];
		$i1++;
		$cnd2 = "devdet_rub1='$devdet_rub1' AND devdet_etat_enreg=1 AND devdet_devid=$IdDevis0 GROUP BY devdet_rub2";
    	$reqRub2 = selections("devdet_rub2",DEVIS_DET,$cnd2,"devdet_id DESC, devdet_rub1 ASC");//echo $reqRub2;
    	$resRub2 = $pdo->query($reqRub2);			
		if($devdet_rub1!=""){?>
        <div class="row">
          <div class="col-lg-12">&nbsp;</div>
</div>
<table width="100%" border="0" cellpadding="1" cellspacing="1">
          <tr>
            <td colspan="5"><span><strong><?php echo $i1.') '.$devdet_rub1; ?></strong></span></td>
  </tr>
</table>
		
		<?php
		}?>
<table width="100%" cellpadding="0" cellspacing="0">
		<?php 
		$totRub = 0;
		while($col2 = $resRub2->fetch()){
        	$devdet_rub2 = $col2['devdet_rub2'];
		?>
            <thead>
            	<?php if($devdet_rub2!=""){?>
                <tr style="padding:5px;">
                    <td style="background-color:#F2F2F2;border-top:1px solid #000000; border-right:1px solid #000000; border-left:1px solid #000000;" align="left"><strong><?php echo $devdet_rub2; ?></strong></td>
                    <td colspan="4" align="left" style="">&nbsp;</td>
                </tr>
                <?php
				}?>
                 <tr style="background-color:#FFE979; padding: 5px;">
                    <th width="52%" align="left" style="border-top:1px solid #000000; border-right:1px solid #000000; border-left:1px solid #000000;">D&Eacute;SIGNATION</th>
                    <th width="8%" align="center" style="border-top:1px solid #000000; border-right:1px solid #000000;">QT&Eacute;</th>
                    <th width="8%" align="center" style="border-top:1px solid #000000; border-right:1px solid #000000;">UNIT&Eacute;</th>
                    <th width="14%" align="left" style="border-top:1px solid #000000; border-right:1px solid #000000;">PU HT</th>
                    <th width="18%" align="left" style="border-top:1px solid #000000; border-right:1px solid #000000;">MONTANT HT</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $cndDet = "devdet_rub1='$devdet_rub1' AND devdet_rub2='$devdet_rub2' AND devdet_devid=$IdDevis0 AND devdet_etat_enreg=1";
                $chpDet = "devdet_materiel, devdet_qte, devdet_unite, devdet_prixunit";
                $reqDet = selections($chpDet,DEVIS_DET,$cndDet,"devdet_id DESC, devdet_rub1 ASC");//echo $reqRub2;
                $resDet = $pdo->query($reqDet);
                $totDetHt = 0;
                while($colDet = $resDet->fetch()){
                  $devdet_materiel 	= $colDet['devdet_materiel'];
                  $devdet_qte 		= $colDet['devdet_qte'];
                  $devdet_unite 	= $colDet['devdet_unite'];
                  $devdet_prixunit 	= $colDet['devdet_prixunit'];
                  $totDetHt = $devdet_qte*$devdet_prixunit;
                ?>
                <tr>
                  <td style="border-top:1px solid #000000; border-right:1px solid #000000; border-left:1px solid #000000;"><?php echo $devdet_materiel; ?></td>
                  <td style="border-top:0.5px solid #000000; border-right:1px solid #000000; border-bottom:0.5px solid #000000;" align="center"><?php echo $devdet_qte; ?></td>
                    <td style="border-top:0.5px solid #000000; border-right:1px solid #000000;" align="center"><?php echo $devdet_unite; ?></td>
                    <td style="border-top:0.5px solid #000000; border-right:1px solid #000000;" align="right"><?php echo number_format($devdet_prixunit,0,'',' '); ?></td>
                    <td style="border-top:0.5px solid #000000; border-right:1px solid #000000;" align="right"><?php echo number_format($totDetHt,0,'',' ');?></td>
                </tr>
                <?php 
                $totRub = $totDetHt+$totRub;
                }
                ?>
            </tbody> 
			<?php 
		}
		?>           
            <?php if($devdet_rub1!=""){?>
            <tfoot>
                 <tr>
                    <th colspan="4" align="right"  style="border:1px solid #000000;">MONTANT <?php echo $devdet_rub1; ?></th>
                    <th width="18%" align="right"  style="border:1px solid #000000;"><?php echo number_format($totRub,0,'',' '); ?></th>
                </tr>
            </tfoot>
            <?php 
			}
			?>
</table>
		<?php
		$totRubDevis = $totRub+$totRubDevis;
}

	$TotGleHT = $totRubDevis+$dev_moeuvre;
?> 
<div class="row">
  <div class="col-lg-12">&nbsp;</div>
</div>
<table width="100%" cellpadding="0" cellspacing="0">
        <thead>
            <?php if($dev_moeuvre!=0){?>
            <tr style="padding: 5px;">
               <th align="right" style="border-top:2px solid #4F81BD;">MAIN D'&OElig;UVRE :</th>
               <th width="18%" align="right" style="border-top:2px solid #4F81BD;"><?php echo  number_format($dev_moeuvre,0,'',' '); ?></th>
            </tr>
            <?php }?>
            <tr style="padding: 5px;">
              <th align="right" style="border-top:2px solid #4F81BD;">TOTAL HT :</th>
              <th width="18%" align="right" style="border-top:2px solid #4F81BD;"><?php echo  number_format($TotGleHT,0,'',' '); ?></th>
            </tr>
            <tr style="padding: 5px;">
              <th align="right" style="border-top:2px solid #4F81BD;">TVA 18% :</th>
              <th align="right" style="border-top:2px solid #4F81BD;"><?php echo number_format(($TotGleHT*TVA),0,'',' '); ?></th>
            </tr>
            <tr style="padding: 5px;">
              <th align="right" style="border-top:2px solid #4F81BD; border-bottom:2px solid #4F81BD;">TOTAL TTC :</th>
              <th width="18%" align="right" style="border-top:2px solid #4F81BD; border-bottom:2px solid #4F81BD;"><?php echo number_format($TotGleHT+($TotGleHT*TVA),0,'',' '); ?></th>
            </tr>
        </thead>
        <tbody>
        </tbody>
</table>
<?php 
$MonNbre = number_format($TotGleHT+($TotGleHT*TVA),0,'','');
$obj = new nuts($MonNbre,"CFA");
$text = $obj->convert("fr-FR");
$nb = $obj->getFormated(" ", ",");
echo "<br /><strong>$text</strong>";
?>
<div class="row">
  <div class="col-lg-12">&nbsp;</div>
</div>
<div class="row">
  <div class="col-lg-12">&nbsp;</div>
</div>
<div style="float:right; text-align:right; text-decoration:underline;">La Direction Technique</div>

<div class="row">
  <div class="col-lg-12">&nbsp;</div>
</div>

<p>&nbsp;</p>
<p>&nbsp;</p>

<table border="0" cellspacing="0" cellpadding="0" align="center" width="100%" style="font-size:13px;">
  <tr>
    <td colspan="2" valign="middle"><p><em><strong><span style="color:#F00">NB:</span></strong> <br />
      * Tous les montants sont en <strong>FCFA</strong>.</em><br />
      <em>* Un acompte vous sera demand&eacute; avant le d&eacute;marrage des travaux</em></p></td>
    <td width="22%" valign="middle"><p>&nbsp;</p></td>
    <td align="left" valign="bottom"><p align="center"><span style="font-size:16px;">Le client</span></p></td>
    <td align="center" valign="bottom"><span style="font-size:16px;">Date</span></td>
  </tr>
  <tr>
    <td colspan="2" valign="middle"><p><em>* Ce devis est valable 01 mois &agrave; compter de la date de r&eacute;ception.</em></p></td>
    <td valign="middle"><p>&nbsp;</p></td>
    <td width="22%" valign="middle"><p style="font-size:16px;">&nbsp;</p></td>
    <td width="16%" align="center" valign="middle"><p style="font-size:16px;">&nbsp;</p></td>
  </tr>
  <tr>
    <td colspan="2" valign="middle"><p>&nbsp;</p></td>
    <td valign="middle"><p>&nbsp;</p></td>
    <td valign="middle"><p>&nbsp;</p></td>
    <td valign="middle"><p>&nbsp;</p></td>
  </tr>
  <tr>
    <td colspan="2" valign="middle"><p><em>&nbsp;</em></p></td>
    <td valign="middle"><p>&nbsp;</p></td>
    <td valign="middle"><p>&nbsp;</p></td>
    <td valign="middle"><p>&nbsp;</p></td>
  </tr>
  <tr>
    <td colspan="2" valign="middle"><p><em>&nbsp;</em></p></td>
    <td valign="middle"><p>&nbsp;</p></td>
    <td valign="middle"><p>&nbsp;</p></td>
    <td valign="middle"><p>&nbsp;</p></td>
  </tr>
  <tr>
    <td width="27%" valign="middle"><p>&nbsp;</p></td>
    <td width="13%" valign="middle"><p>&nbsp;</p></td>
    <td valign="middle"><p>&nbsp;</p></td>
    <td valign="middle"><p align="center">&nbsp;</p></td>
    <td valign="middle"><p>&nbsp;</p></td>
  </tr>
  <tr>
    <td colspan="2" valign="middle"><p>Si ce devis vous convient, veuillez nous le retourner dat&eacute;, sign&eacute; avec la mention&nbsp;: &laquo;<strong><em>BON POUR ACCORD&raquo;</em></strong></p></td>
    <td valign="middle">&nbsp;</td>
    <td valign="middle"><p>&nbsp;</p></td>
    <td valign="middle"><p>&nbsp;</p></td>
  </tr>
</table>