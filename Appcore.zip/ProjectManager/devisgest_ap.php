<?php 
if($_SESSION['AP_user_profil']!="CP" && $_SESSION['AP_user_profil']!="GM"){?>
<div class="row">
  <div class="col-lg-12">
      <h3 class="page-header">GESTION DE DEVIS</h3>
  </div>
  <!--<div class="col-lg-12">
      <h4>ETAPE 2/2: DETAILS DU DEVIS: <span class="text-rouge"><?php echo stripslashes($dev_ref)."&nbsp;|&nbsp;".$dev_objet?></span></h4>
  </div>-->
  <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
<?php
$Rechwhere = "";
if (isset($_POST['rfind'])){
	if($_POST['datedeb']!=""){
		$datedeb=trim($_POST['datedeb']);
		$datedeb = dateLFrToEnDeb($datedeb);
 	}else $datedeb = dateLFrToEnDeb('0000-00-00');
	
	if($_POST['datefin']!=""){
		$datefin=trim($_POST['datefin']);
		$datefin = dateLFrToEnFin($datefin); 
	}else $datefin = date('Y-m-d H:i:s');
	
	$Rechwhere.= " AND dev_date_cre BETWEEN '$datedeb' AND '$datefin'";
	
	if($_POST['etat']!=""){
		$etat=trim($_POST['etat']); 
		$Rechwhere.= " AND dev_etat_accepte=$etat"; 
  }
		   
}else{
	$etat = 0;
	$Rechwhere= " AND dev_etat_accepte=$etat";
}
?>
<div class="row">
  <div class="col-lg-12">
      <div class="panelglobal panel-default-global">
          <div class="panel-body">
              <div class="row">
              <div class="col-lg-12">
                    <div class="panelrech panel-default">
                      <div class="panel-heading-rech">Zone de recherche</div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
              				<form role="form" method="post" id="rechUser">
                  <div class="col-lg-3">
                    <div class="form-group input-group">
                       <span class="input-group-addon">Date d&eacute;but</span>
                        <input type="date" class="form-control" placeholder="Date d&eacute;but" name="datedeb" id="datedeb" >
                    </div>
                  </div>
                  <div class="col-lg-3">
                    <div class="form-group input-group">
                       <span class="input-group-addon">Date fin</span>
                        <input type="date" class="form-control" placeholder="Date fin" name="datefin" id="datefin" >
                    </div>
                  </div>
                  <div class="col-lg-3">
                    <div class="form-group input-group">
                       <span class="input-group-addon">Statut</span>
                        <select name="etat" id="etat" class="form-control">
                           <option value="">--Tout--</option>
                           <option value="0" <?php if($etat=="0"){?>selected="selected"<?php }?>>En attente</option>
                           <option value="1" <?php if($etat=="1"){?>selected="selected"<?php }?>>Accept&eacute;</option>
                           <option value="10" <?php if($etat=="10"){?>selected="selected"<?php }?>>R&eacute;fus&eacute;</option>
                           <option value="11" <?php if($etat=="11"){?>selected="selected"<?php }?>>Annul&eacute;</option>
                         </select>
                    </div>
                  </div>
                  <div class="col-lg-3">
                  <button type="submit" class="btn btn-primary btn-block" name="rfind" id="rfind">Rechercher&nbsp;&nbsp;<i class="glyphicon glyphicon-search"></i></button>
                  </div>
               </form>
               			</div>
                    </div>
               </div>
               <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">LISTE DES DEVIS &Agrave; G&Eacute;RER</div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
							<?php 
							$chp = "dev_id, dev_ref, dev_objet, dev_date_cre, dev_etat_valid, dev_etat_accepte, dev_observ,dev_user_cre, C.clt_type, C.clt_nom, C.clt_abrege,user_nom, user_prenom, getMtDevis(dev_id) AS MONTANT, dev_moeuvre";
							$tb = "(".DEVIS." D LEFT JOIN ".CLIENTS." C ON D.dev_clt=C.clt_id) LEFT JOIN ".USERS." U ON D.dev_user_cre=U.user_id";
							$cnd = "dev_etat_enreg=1 AND dev_etat_sup=1 $Rechwhere";
							$reqDet = selections($chp,$tb,$cnd,"dev_id DESC");
							$resDet = $pdo->query($reqDet);							
							?>
                            <table width="100%" class="table table-striped table-bordered table-hover" id="tb_gestdevis">
                                <thead>
                                    <tr>
                                        <th align="center">#</th>
                                        <th align="left">R&eacute;f.</th>
                                        <th align="left">Objet</th>
                                        <th align="left">Client</th>
                                        <th align="left">Montant</th>
                                        <th align="left">Statut</th>
                                        <th align="left">Actions</th>
                                        <th align="center">D&eacute;tails</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php 
								$i = 0;
								while($col = $resDet->fetch()){
								  $dev_id 		 	= $col['dev_id'];
								  $dev_ref 	 		= $col['dev_ref'];
								  $dev_objet		= $col['dev_objet'];
								  $dev_date_cre 	= $col['dev_date_cre'];
								  $dev_etat_valid 	= $col['dev_etat_valid'];
								  $dev_etat_accepte = $col['dev_etat_accepte'];
								  $dev_observ 		= $col['dev_observ'];
								  $dev_user_cre		= $col['dev_user_cre'];
								  $clt_type 		= $col['clt_type'];
								  $clt_nom 			= $col['clt_nom'];
								  $clt_abreg 		= $col['clt_abreg'];
								  $user_nom     	= $col['user_nom'];
								  $user_prenom 	    = $col['user_prenom'];
									$MONTANT 	    = $col['MONTANT'];
									$dev_moeuvre 	    = $col['dev_moeuvre'];
									if($dev_moeuvre==0)$mo = "<em>Inclus ci-dessus</em>";else $mo = "<strong>".number_format($dev_moeuvre,0,'',' ')."</strong>";
									
								  
								  if($clt_type==0)$typeclt = "Particulier";else $typeclt="Soci&eacute;t&eacute;";
								  
								  if($dev_etat_accepte==0) $statut = '<span class=text-bleu><i class="fa fa-pencil-square-o"></i>&nbsp;En attente</span>';
                                  elseif($dev_etat_accepte==1) $statut = '<span class=text-vert><i class="fa fa-check-square-o"></i>&nbsp;Accept&eacute;</span>';
                                  elseif($dev_etat_accepte==10) $statut = '<span class=text-rouge><i class="fa fa-minus-circle"></i>&nbsp;R&eacute;fus&eacute;</span>';
                                  elseif($dev_etat_accepte==11) $statut = '<span class=text-orange><i class="fa fa-warning"></i>&nbsp;Annul&eacute;</span>';
								   
								  $i++;
								  ?>
                                    <tr id="<?php echo $dev_id;?>" class="even gradeA success">
                                        <td align="center"><?php echo $i ?></td>
                                        <td>
										<?php echo "<strong>".$dev_ref."</strong>";
										if(!empty($dev_date_cre))echo "<br /><span class=small><em>Ajout&eacute; le ".getdateL($dev_date_cre)."<br />Par ".$user_prenom." ".$user_nom."</em></span>";?>
										</td>
                                        <td><?php echo nl2br($dev_objet); ?></td>
                                        <td><?php if($clt_abreg!="")echo "<strong>".$clt_abreg."</strong>";else {echo "<strong>".$clt_nom."</strong>";}echo "<br /><span class=small><em>".$typeclt."</em></span>";?></td>
                                        <td align="right" class="small">HT:&nbsp;<?php echo "<strong>".number_format($MONTANT,0,'',' ')."</strong>"; ?><br />TTC:&nbsp;<?php echo "<strong>".number_format($MONTANT+($MONTANT*TVA),0,'',' ')."</strong>"; ?><br />Dont MO:&nbsp;<?php echo $mo ;?></td>
                                        <td align="center"><?php echo $statut; ?></td>
                                        <td align="center">
                                        <?php if($dev_etat_accepte==0){?>
                                        <div><button class="btnLien btn-link ButtonModifDevis" data-toggle="tooltip" data-placement="top" title="Modifier les infos du devis <?php echo $dev_ref; ?>" onclick="document.location.href='?yk=devisadd&act=mod&dev=<?php echo $dev_id;?>'"><i class="fa fa-pencil text-vert"></i>&nbsp;Modifier</button>&nbsp;&nbsp;&nbsp;&nbsp;</div>                                        
                                          <?php if($dev_user_cre==$_SESSION['AP_iduser'] || $_SESSION['AP_user_profil']=="DT" || $_SESSION['AP_user_profil']=="DG" || $_SESSION['AP_user_profil']=="AD"){?>
                                          <div><button class="btnLien btn-link ButtonSuppDevis" data-toggle="tooltip" data-placement="top" title="Supprimer le devis  <?php echo $dev_ref; ?>"><i class="fa fa-trash-o text-rouge"></i>&nbsp;Supprimer</button></div><?php } }else{?><i class="fa fa-lock text-jaune" title="Aucune action disponible !"></i><?php }?>
                                          </td>
                                        <td align="center">                                        <button class="btn btn-link ButtonOuvrirDetDevis" data-toggle="tooltip" data-placement="top" title="Voir les d&eacute;tails du devis <?php echo $dev_ref; ?>" onclick="document.location.href='?yk=devisdetail&dev=<?php echo $dev_id;?>'"><i class="fa fa-folder-open-o fa-lg text-bleu"></i></button>
                                        </td>
                                    </tr>
                                    <?php 
								}
									?>
                                </tbody>
                            </table>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                
              </div>
          </div>
      </div>
  </div>
</div> 
<?php 
}else{
?><script language="javascript">document.location="index.php"</script><?php 
}
?>