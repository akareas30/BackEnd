<?php
session_start();
ini_set('session.bug_compat_42', 0);
ini_set('session.bug_compat_warn', 0);
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php"); 
VerifTempsLog();

if(isset($_GET['dev']) and isset($_GET['mtmo'])){
  $IdDevis0 = trim($_GET['dev']);
  $MtMo = (int)trim($_GET['mtmo']);
  
  $req = selections("getMtDevisDetail($IdDevis0) as Mtdevis",DUAL,"1","1");
  $TotDevisDetail= $pdo->query($req)->fetchColumn();
  
  $TotDevisMo = $TotDevisDetail+$MtMo;
  $TotDevisMo = number_format($TotDevisMo,0,'',' ');
   
  $array = array($TotDevisMo);
  echo json_encode($array);
}
?>
