<?php
session_start();
ini_set('session.bug_compat_42', 0);
ini_set('session.bug_compat_warn', 0);
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php"); 
VerifTempsLog();

if(isset($_GET['id'])){
  $actid     = (int)$_GET['id'];
  if(!delete(OUTILS_REF,"outilref_id=$actid")===true){
	  $array = array($actid);
	  echo json_encode($array);
  }

}