<?php
session_start();
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php"); 
VerifTempsLog();

if(isset($_POST['datedeb']) or isset($_POST['datefin'])){
  if($_POST['datedeb']!="") $deb = trim($_POST['datedeb']); else $deb='0000-00-00';
  if($_POST['datefin']!="") $fin = trim($_POST['datefin']); else $fin=date('Y-m-d');
  $cndEtatCplt = " AND cht_date_cre BETWEEN '$deb' AND '$fin'";
}elseif(!isset($_POST['datedeb']) and !isset($_POST['datefin'])){
  $cndEtatCplt = "";
}

  
$chpEtat="COUNT(cht_id)";
$cndEtat1="cht_etat=1";//en cours
$cndEtat2="cht_etat=2";//terminé
$cndEtat3="cht_etat=3";//Annulé


$req1  = selections($chpEtat,CHANTIERS,$cndEtat1.$cndEtatCplt,1); 
$req2  = selections($chpEtat,CHANTIERS,$cndEtat2.$cndEtatCplt,1);
$req3  = selections($chpEtat,CHANTIERS,$cndEtat3.$cndEtatCplt,1);
 
$Nbre1  = $pdo->query($req1)->fetchColumn();
$Nbre2  = $pdo->query($req2)->fetchColumn();
$Nbre3  = $pdo->query($req3)->fetchColumn();

$TotNbre = $Nbre1+$Nbre2+$Nbre3;

//Les taux selon les etats
$TauxNbre1  = number_format($Nbre1*100/$TotNbre,2,',','').'%';
$TauxNbre2  = number_format($Nbre2*100/$TotNbre,2,',','').'%';
$TauxNbre3  = number_format($Nbre3*100/$TotNbre,2,',','').'%';
$TotTx 		  = number_format($TotNbre*100/$TotNbre,0,',','').'%';

//Output data
$array = array($Nbre1,$Nbre2,$Nbre3,$TotNbre,$TauxNbre1,$TauxNbre2,$TauxNbre3,$TotTx);
echo json_encode($array);
?>