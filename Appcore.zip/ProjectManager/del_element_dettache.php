<?php
session_start();
ini_set('session.bug_compat_42', 0);
ini_set('session.bug_compat_warn', 0);
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php"); 
VerifTempsLog();

if(isset($_GET['id']) and isset($_GET['dev'])){
  $actid     = (int)$_GET['id'];
  $IdChant0  = (int)$_GET['dev'];
  $tch_nature  = (int)$_GET['nat'];
  if(!delete(TACHES,"tch_id=$actid")===true){
	  $array = array($actid);
	  //echo json_encode($array);
  }

}

$chp = "tch_id, tch_libelle, tch_debut, tch_fin_prevu, dev_ref, dev_objet,tch_nature";
$tb = TACHES." LEFT JOIN ".DEVIS." ON tch_devis=dev_id"; 
$reqDet = selections($chp,$tb,"cht_id=$IdChant0 AND tch_nature=$tch_nature","tch_id ASC");
$resDet = $pdo->query($reqDet);			
?>
<tbody>
<?php 
$i = 0;
while($col = $resDet->fetch()){
  $tch_id 		 = $col['tch_id'];
  $tch_libelle 	 = $col['tch_libelle'];
  $tch_debut	 = $col['tch_debut'];
  $tch_fin_prevu = $col['tch_fin_prevu'];
  $dev_ref 	 	 = $col['dev_ref'];
  $dev_objet 	 = $col['dev_objet'];					 
  $tch_nature 	 = $col['tch_nature'];
  $i++;
  ?>
	<tr id="<?php echo $tch_id;?>" data-dev="<?php echo $IdChant0; ?>" data-nat="<?php echo $tch_nature; ?>" class="even gradeA success">
		<td align="center"><?php echo $i ?></td>
		<td><?php echo $tch_libelle ?></td>
		<td align="center"><?php echo getdateC($tch_debut).' - '.getdateC($tch_fin_prevu); ?></td>
		<td align="center"><?php echo $dev_objet; ?></td>
		<td align="center">                                        
		<button class="btn btn-link ButtonRetirer" data-toggle="tooltip" data-placement="top" title="Retirer <?php echo $tch_libelle; ?>"><i class="fa fa-trash-o fa-lg text-rouge"></i></button>
		</td>
		<td align="center">
        <div data-toggle="tooltip" data-placement="top" title="Modifier <?php echo $tch_libelle; ?>">
		<button class="btn btn-link modifButton" data-toggle="modal" data-backdrop="static"><i class="fa fa-pencil fa-lg"></i></button></div></td>
	</tr>
	<?php 
}
	?>
</tbody>
