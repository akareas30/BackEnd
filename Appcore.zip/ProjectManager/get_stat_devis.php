<?php
session_start();
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php"); 
VerifTempsLog();

if(isset($_POST['datedeb']) or isset($_POST['datefin'])){
  if($_POST['datedeb']!="") $deb = trim($_POST['datedeb']); else $deb='0000-00-00';
  if($_POST['datefin']!="") $fin = trim($_POST['datefin']); else $fin=date('Y-m-d');
  $cndEtatCplt = " AND dev_date_cre BETWEEN '$deb' AND '$fin'";
}elseif(!isset($_POST['datedeb']) and !isset($_POST['datefin'])){
  $cndEtatCplt = "";
}

  
$chpEtat="COUNT(dev_id)";
$cndEtat0="dev_etat_accepte=0";//en cours
$cndEtat1="dev_etat_accepte=1";//accepté
$cndEtat10="dev_etat_accepte=10";//Réfusé
$cndEtat11="dev_etat_accepte=11";//Annulé


$req0  = selections($chpEtat,DEVIS,$cndEtat0.$cndEtatCplt,1); 
$req1  = selections($chpEtat,DEVIS,$cndEtat1.$cndEtatCplt,1);
$req10 = selections($chpEtat,DEVIS,$cndEtat10.$cndEtatCplt,1);
$req11 = selections($chpEtat,DEVIS,$cndEtat11.$cndEtatCplt,1);
 
$Nbre0  = $pdo->query($req0)->fetchColumn();
$Nbre1  = $pdo->query($req1)->fetchColumn();
$Nbre10 = $pdo->query($req10)->fetchColumn();
$Nbre11 = $pdo->query($req11)->fetchColumn();
   
$data = array(
				array('label'=>'En cours', 'data'=>$Nbre0, 'color'=>"#3333FF"),//bleu
				array('label'=>'Accepté', 'data'=>$Nbre1, 'color'=>"#009933"),//vert
				array('label'=>'Réfusé', 'data'=>$Nbre10, 'color'=>"#FF3F3F"),//rouge
				array('label'=>'Annulé', 'data'=>$Nbre11, 'color'=>"#FFC338")//orangé
				);
				
echo json_encode($data);
$pdo=null;
?>
