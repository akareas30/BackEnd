<?php
session_start();
ini_set('session.bug_compat_42', 0);
ini_set('session.bug_compat_warn', 0);
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php"); 
VerifTempsLog();

if(isset($_GET['id']) and isset($_GET['dev'])){
  $actid     = (int)$_GET['id'];
  $IdDmd0    = (int)$_GET['dev'];
  if(!delete(DEMANDES_DET,"dmddet_id=$actid")===true){
	  $array = array($actid);
	  //echo json_encode($array);
  }
}

$chp = "dmddet_id, outilref_libelle, outilref_descrip, dmddet_etat_enreg, dmddet_etat_traite";
$tbl = DEMANDES_DET." LEFT JOIN ".OUTILS_REF." ON dmddet_outils=outilref_id";
$cnd = "dmddet_dmdid=$IdDmd0 AND dmddet_etat_enreg=1";
$reqDet = selections($chp,$tbl,$cnd,"dmddet_id DESC");
$resDet = $pdo->query($reqDet);	
?>
<tbody>
<?php 
$i = 0;
while($col = $resDet->fetch()){
  $dmddet_id 		 = $col['dmddet_id'];
  $outil_libelle 	 = $col['outilref_libelle'];
  $outilref_descrip	 = $col['outilref_descrip'];
  $dmddet_etat_enreg = $col['dmddet_etat_enreg'];
  $dmddet_etat_traite= $col['dmddet_etat_traite'];							  
  
  $i++;
  ?>
	<tr id="<?php echo $dmddet_id;?>" data-dev="<?php echo $IdDmd0; ?>" class="even gradeA success">
		<td align="center"><?php echo $i ?></td>
		<td><?php echo "<strong>".$outil_libelle."</strong>";?></td>
		<td align="left"><?php echo nl2br($outilref_descrip); ?></td>
		<td align="center">
		<?php if($dmddet_etat_traite==0){ ?>                                       
		<button class="btn btn-link ButtonRetirer" data-toggle="tooltip" data-placement="top" data-tb="myDevisDetTb" title="Retirer <?php echo $outil_libelle; ?>"><i class="fa fa-trash-o fa-lg text-rouge"></i></button>
		<?php }?>
		</td>
	</tr>
	<?php 
}
	?>
</tbody>