<?php
session_start();
ini_set('session.bug_compat_42', 0);
ini_set('session.bug_compat_warn', 0);
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php"); 
VerifTempsLog();

if(isset($_GET['dev'])){
  $IdDevis0  = (int)$_GET['dev'];
  if(!update(DEVIS,"dev_etat_sup=0","dev_id=$IdDevis0")===true){
	  $array = array($IdDevis0);
	  echo json_encode($array);
  }
}