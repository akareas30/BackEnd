<?php 
if(isset($_GET['id']) and isset($_GET['typdm'])){
?>
<div class="modal-footer">
<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times fa-lg"></i>&nbsp;&nbsp;Imprime</button>
</div>
<?php }?>