<?php 
if(isset($_GET['dev'])){
	$IdChant0 = (int)$_GET['dev'];
}
$chp = "D.cht_libelle, D.cht_debut, D.cht_fin_prevu";
$tb = CHANTIERS." D";
$cnd = "cht_id=$IdChant0";

$reqLib = selections($chp,$tb,$cnd,1);
$res = $pdo->query($reqLib);
$col = $res->fetch();
$cht_libelle 	= $col['cht_libelle'];
$cht_debut 		= $col['cht_debut'];
$cht_fin_prevu 	= $col['cht_fin_prevu'];
?>
<div class="row">
  <div class="col-lg-12">
      <h3 class="page-header">ENREGISTRER UN CHANTIER</h3>
  </div>
  <div class="col-lg-12">
      <h4>ETAPE 3/3: EQUIPE(S) DU CHANTIER: <?php echo '<span class="text-rouge">'.stripslashes($cht_libelle).' (Du '.getdateC($cht_debut).' au '.getdateC($cht_fin_prevu).")</span>";?></h4>
  </div>
  <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
<div class="row">
  <div class="col-lg-12">
      <div class="panelglobal panel-default-global">
          <div class="panel-body">
              <div class="row">
              <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">1.&nbsp;Ajouter les &eacute;quipes</div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                <form role="form" method="post" id="formAddDetEqp" action="">
                <div class="row">
                  <div class="col-lg-4">
                    <div class="form-group">
                    <input type="hidden" name="IdChant" id="IdChant" value="<?php echo $IdChant0; ?>">
                       <select name="activite" id="activite" required="required" class="form-control">
                           <option value="">-- S&eacute;lectionnez une &eacute;quipe --</option>
                           <?php 
						   $ch = "act_id, act_libelle";
						   $tab = ACTIVITES;
						   $cd = "act_etat=1";
						   deroulant($ch,$tab,$cd,"act_libelle ASC",$activite);
						   ?>
                         </select>
                     </div>
                  </div>
                  <div class="col-lg-4">
                     <div class="form-group">
                       <input type="text" class="form-control" placeholder="Nom du Responsable &eacute;quipe" name="respons" id="respons" required="required">
                    </div>
                  </div>
                  <div class="col-lg-4">
                    <div class="form-group">
                        <input type="tel" class="form-control" placeholder="Numéro t&eacute;l&eacute;phone" name="tel" id="tel">
                     </div>
                  </div>
               </div>
               </form>
                 <div class="row">
                 <div class="col-lg-4 pull-right">
                    <button class="btn btn-warning btn-block" name="ButtonAddDetEqp" id="ButtonAddDetEqp" data-action="put_detail_eqp.php"><i class="fa fa-plus-square fa-lg"></i>&nbsp;&nbsp;Ajouter&nbsp;</button>
                    </div>
                 </div>
                      </div>
                </div>
         </div>
                <?php 
				if(isset($_POST['ButtonEnregEqp'])){
				 ?><script language="javascript">document.location="?yk=chantiergest&svt&dev=<?php echo $IdChant0;?>"</script><?php
				}
				?>
               <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">2.&nbsp; Les &eacute;quipes du chantier</div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
							<?php 
							$chp = "eq_id, eq_hrnom, eq_hrcontact,act_libelle";
							$tb = CHANTIERS_EQP." LEFT JOIN ".ACTIVITES." ON eq_idact=act_id"; 
							$reqDet = selections($chp,$tb,"eq_idcht=$IdChant0","eq_id ASC");
							$resDet = $pdo->query($reqDet);							
							?>
                            <table width="100%" class="table table-bordered table-hover" id="tb_addeqp">
                                <thead>
                                    <tr>
                                        <th align="center">#</th>
                                        <th align="left">Equipe</th>
                                        <th align="center">Responsable</th>
                                        <th align="center">Contacts</th>
                                        <th align="center">&nbsp;</th>
                                        <th align="center">&nbsp;</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php 
								$i = 0;
								while($col = $resDet->fetch()){
								  $eq_id 		 = $col['eq_id'];
								  $eq_hrnom 	 = $col['eq_hrnom'];
								  $eq_hrcontact	 = $col['eq_hrcontact'];
								  $act_libelle   = $col['act_libelle'];
								  
								  $i++;
								  ?>
                                    <tr id="<?php echo $eq_id;?>" data-dev="<?php echo $IdChant0; ?>" class="even gradeA success">
                                        <td align="center"><?php echo $i ?></td>
                                        <td><?php echo $act_libelle ?></td>
                                        <td align="left"><?php echo $eq_hrnom; ?></td>
                                        <td align="center"><?php echo $eq_hrcontact; ?></td>
                                        <td align="center">                                        
                                        <button class="btn btn-link ButtonRetirer" data-toggle="tooltip" data-placement="top" title="Retirer Equipe <?php echo $act_libelle." (".$eq_hrnom.")"; ?>"><i class="fa fa-trash-o fa-lg text-rouge"></i></button>
                                        </td>
                                        <td align="center">
                                        <div data-toggle="tooltip" data-placement="top" title="Modifier Equipe <?php echo $act_libelle." (".$eq_hrnom.")"; ?>">
                                        <button class="btn btn-link modifButton" data-toggle="modal" data-backdrop="static"><i class="fa fa-pencil fa-lg"></i></button></div></td>
                                    </tr>
                                    <?php 
								}
									?>
                                </tbody>
                            </table>
                            <!-- /.table-responsive -->
                            
                            <?php 
				if(isset($_POST['ButtonEnregChantier'])){
				 if(!update(TACHES,"tch_etat=1","cht_id=$IdChant0 AND tch_etat=0")===true){
				 ?><div class="alert alert-success alert-dismissable">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
						<?php echo TXT_ALERT_SUCCES_ENREG; ?></div>
					<script language="javascript">document.location="?yk=chantieraddeqp&svt&dev=<?php echo $IdChant0;?>"</script><?php
				 }
				}
				?>
                <div class="row">
                <form method="post" id="formEnregDetTache" action="">
                <div class="col-lg-4 pull-right">
                  <button type="submit" name="ButtonEnregEqp" id="ButtonEnregEqp" class="btn btn-success btn-block"><i class="fa fa-save fa-lg"></i>&nbsp;&nbsp;Terminer&nbsp;</button>
                </div>
                </form>
                </div>
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                
              </div>
          </div>
      </div>
  </div>
</div>


<!-- Modal -->
<div class="modal fade" id="ModalModifDetEqp" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">           
            <div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
<h4 class="modal-title" id="myModalLabel">Modifier</h4>
            </div>
<div class="row">
  <div class="col-lg-12">
      <div class="panelglobal panel-default-global">
          <form role="form" action="update_detail_eqp.php" method="post" id="formModDetEqp">
          <div class="panel-body">
              <div class="row">
              <div class="col-lg-6">            
				  <div class="form-group">
                    <input type="hidden" name="IdChant" id="IdChant" value="<?php echo $IdChant0; ?>">
                    <input type="hidden" name="IdEqp" id="IdEqp" value="">
                       <label>Equipe</label>
                       <select name="activite" id="activite" required="required" class="form-control">
                           <option value="">-- S&eacute;lectionnez une &eacute;quipe --</option>
                           <?php 
						   $ch = "act_id, act_libelle";
						   $tab = ACTIVITES;
						   $cd = "act_etat=1";
						   deroulant($ch,$tab,$cd,"act_libelle ASC",$activite);
						   ?>
                         </select>
                     </div>
              </div>
               </div>
              <div class="row">              
                  <div class="col-lg-6">
                    <div class="form-group">
                    <label>Responsable Equipe</label>
                       <input type="text" class="form-control" placeholder="Nom du Responsable &eacute;quipe" name="respons" id="respons" required="required">
                    </div>
                  </div>
              </div>
              <div class="row">              
                  <div class="col-lg-6">
                    <div class="form-group">
                    <label>N&deg; T&eacute;l. Responsable</label>
                        <input type="tel" class="form-control" placeholder="Numéro t&eacute;l&eacute;phone" name="tel" id="tel">
                     </div>
                  </div>
              </div>
          </div>
          </form>
      </div>
  </div>
</div>
            </div>
            <div class="modal-footer">
                 <button name="submitFormModDeteqp" id="submitFormModDeteqp" type="button" class="btn btn-success"><i class="fa fa-save fa-lg"></i>&nbsp;&nbsp;Modifier</button>
 
 <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times fa-lg"></i>&nbsp;&nbsp;Fermer</button>
 
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->  