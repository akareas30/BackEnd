<?php
session_start();
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php");
VerifTempsLog();


if(isset($_GET['cht']) and isset($_GET['ret'])){
  $IdChant0  = $_GET['cht'];	
  include('rapportfiche_ap.php');
  $pdo=null;
}
?>