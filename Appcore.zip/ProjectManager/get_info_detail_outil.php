<?php
session_start();
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php");
VerifTempsLog();

if(isset($_GET['id'])){
  $idout  = $_GET['id'];  
  $chp = "ID_OUT, IDDET_OUT, LIBELLE_OUT, REF_OUT, SERIAL, MARQUE, DESCRIPTION, DATE_ACQUIS";
  $req = selections($chp,VT_DET_OUTIL,"ID_OUT=$idout","ID_OUT");
  $res = $pdo->query($req);
?>
<table width="100%" class="table table-bordered table-hover" id="tb_addoutil">
  <thead>
      <tr>
          <th align="center">#</th>
          <th align="left">Ref.</th>
          <th align="left">Serial</th>
          <th align="left">Marque / Mod&egrave;le</th>
          <th align="left">Description</th>
      </tr>
  </thead>
  <tbody>
  <?php 
    $i = 0;
    while($col = $res->fetch()){
      $ref_id 				= $col['IDDET_OUT'];
      $ref_lib_outil 		= $col['LIBELLE_OUT'];
      $ref_outildescrip 	= $col['DESCRIPTION'];
      $ref_outilid 			= $col['ID_OUT'];
      $ref_ref 				= $col['REF_OUT'];
      $ref_serial 			= $col['SERIAL'];
      $ref_marque 			= $col['MARQUE'];
      $ref_date_acquis 		= $col['DATE_ACQUIS'];
      $i++;
      ?>
        <tr class="even gradeA success">
            <td align="center"><?php echo $i ?></td>
            <td><?php echo "<strong>".$ref_ref."</strong>"; if(!empty(getdateC($ref_date_acquis)))echo "<br /><span class=small><em>Acquis le ".getdateC($ref_date_acquis)."</em></span>";?></td>
            <td><?php echo $ref_serial ?></td>
            <td><?php echo nl2br($ref_marque);?></td>
            <td><?php echo nl2br($ref_outildescrip); ?></td>
        </tr>
        <?php 
    }
        ?>
  </tbody>
</table>
<?php 
$pdo=null;
}
?>