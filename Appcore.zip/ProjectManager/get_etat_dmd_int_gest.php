<?php
session_start();
ini_set('session.bug_compat_42', 0);
ini_set('session.bug_compat_warn', 0);
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php");
VerifTempsLog();

$IdDmd0 = (int)trim($_GET['idDmd']);
$reqDet = selections("dmd_etat_approuv",DEMANDES,"dmd_id=$IdDmd0","dmd_id");
$dmd_etat_approuv = $pdo->query($reqDet)->fetchColumn();
$array = array($dmd_etat_approuv);
echo json_encode($array)
?>