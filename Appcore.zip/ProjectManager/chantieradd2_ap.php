<?php 
if($_SESSION['AP_user_profil']=="AD" || $_SESSION['AP_user_profil']=="DG" || $_SESSION['AP_user_profil']=="DT" || $_SESSION['AP_user_profil']=="CC"){
	
if(isset($_GET['dev'])){
	$IdChant0 = (int)$_GET['dev'];
}

if(isset($_GET['act'])){
	$titre = "GESTION DE CHANTIER";
	$soustitre = "ENREGISTRER LES TRAVAUX SUPPL&Eacute;MENTAIRES:";
	$n1 = "Saisir les travaux suppl&eacute;mentaires";
	$n2 = "Les travaux suppl&eacute;mentaires";
	$tblib = "Travaux supp.";
	$natTache = 1;
}else{
	$titre = "ENREGISTRER UN CHANTIER";
	$soustitre = "ETAPE 2/3: PLANNING DU CHANTIER:";
	$n1 = "1.&nbsp;Saisir le planning";
	$n2 = "2.&nbsp;Le planning des t&acirc;ches";
	$tblib = "T&acirc;ches Chantier";
	$natTache = 0;
}

$chp = "D.cht_libelle, D.cht_debut, D.cht_fin_prevu, D.cht_etat";
$tb = CHANTIERS." D";
$cnd = "cht_id=$IdChant0";

$reqLib = selections($chp,$tb,$cnd,1);
$res = $pdo->query($reqLib);
$col = $res->fetch();
$cht_libelle 	= $col['cht_libelle'];
$cht_debut 		= $col['cht_debut'];
$cht_fin_prevu 	= $col['cht_fin_prevu'];
$cht_etat 		= $col['cht_etat'];
if($cht_etat == 1){
?>
<div class="row">
  <div class="col-lg-12">
      <h3 class="page-header"><?php echo $titre; ?></h3>
  </div>
  <div class="col-lg-12">
      <h4><?php echo $soustitre; ?> <?php echo '<span class="text-rouge">'.stripslashes($cht_libelle).' (Du '.getdateC($cht_debut).' au '.getdateC($cht_fin_prevu).")</span>";?></h4>
  </div>
  <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
<div class="row">
  <div class="col-lg-12">
      <div class="panelglobal panel-default-global">
          <div class="panel-body">
              <div class="row">
              <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading"><?php echo $n1; ?></div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                <form role="form" method="post" id="formAddDetTache" action="">
                  <div class="col-lg-4">
                    <div class="form-group">
                    <input type="hidden" name="IdChant" id="IdChant" value="<?php echo $IdChant0; ?>">
                       <select name="devis" id="devis" required="required" class="form-control">
                           <option value="">-- S&eacute;lectionnez le devis --</option>
                           <?php 
						   $ch = "dev_id, dev_ref";
						   $tab = DEVIS." LEFT JOIN ".CHANTIERS." ON dev_clt=cht_client";
						   $cd = "dev_etat_accepte=1 AND dev_etat_sup=1 AND cht_id=$IdChant0";
						   deroulant($ch,$tab,$cd,"dev_ref",$devis);
						   ?>
                         </select>
                     </div>
                  </div>
                  <div class="col-lg-4">
                     <div class="form-group">
                       <input type="text" class="form-control" disabled="disabled" name="obj" id="obj">
                    </div>
                  </div>
                  <div class="col-lg-4">
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Libell&eacute; de la t&acirc;che" name="tache" id="tache" required="required">
                     </div>
                  </div>
                  <div class="col-lg-4">
                     <div class="form-group input-group">
                       <span class="input-group-addon">Date d&eacute;but</span>
                        <input type="date" class="form-control" placeholder="Date d&eacute;but" name="datedeb" id="datedeb" required="required">
                        <input type="hidden" name="datedebInit" id="datedebInit" value="<?php echo $cht_debut; ?>">
                        
                        <input type="hidden" name="natTache" id="natTache" value="<?php echo $natTache; ?>">
                    </div>
                  </div>
                  <div class="col-lg-4">
                    <div class="form-group input-group">
                       <span class="input-group-addon">Date fin</span>
                        <input type="date" class="form-control" placeholder="Date fin" name="datefin" id="datefin" required="required">
                        <input type="hidden" name="datefinInit" id="datefinInit" value="<?php echo $cht_fin_prevu; ?>">
                    </div>
                  </div> 
               </form>
               <div class="col-lg-4">
                  <button class="btn btn-warning btn-block" name="ButtonAddDetTache" id="ButtonAddDetTache" data-action="put_detail_tache.php"><i class="fa fa-plus-square fa-sm"></i>&nbsp;&nbsp;Ajouter&nbsp;</button>
                  </div>
               			</div>
                    </div>
               </div>
               
               <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading"><?php echo $n2; ?></div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
							<?php 
							$chp = "tch_id, tch_libelle, tch_debut, tch_fin_prevu, dev_ref, dev_objet, tch_nature";
							$tb = TACHES." LEFT JOIN ".DEVIS." ON tch_devis=dev_id"; 
							$reqDet = selections($chp,$tb,"cht_id=$IdChant0 AND tch_nature=$natTache","tch_id ASC");
							$resDet = $pdo->query($reqDet);							
							?>
                            <table width="100%" class="table table-bordered table-hover" id="tb_addtache">
                                <thead>
                                    <tr>
                                        <th align="center">#</th>
                                        <th align="left"><?php echo $tblib; ?></th>
                                        <th align="center">P&eacute;riode</th>
                                        <th align="center">Objet devis</th>
                                        <th align="center">&nbsp;</th>
                                        <th align="center">&nbsp;</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php 
								$i = 0;
								while($col = $resDet->fetch()){
								  $tch_id 		 = $col['tch_id'];
								  $tch_libelle 	 = $col['tch_libelle'];
								  $tch_debut	 = $col['tch_debut'];
								  $tch_fin_prevu = $col['tch_fin_prevu'];
								  $dev_ref 	 	 = $col['dev_ref'];
								  $dev_objet 	 = $col['dev_objet'];
								  $tch_nature 	 = $col['tch_nature'];					 
								  
								  $i++;
								  ?>
                                    <tr id="<?php echo $tch_id;?>" data-dev="<?php echo $IdChant0; ?>" data-nat="<?php echo $tch_nature; ?>" class="even gradeA success">
                                        <td align="center"><?php echo $i ?></td>
                                        <td><?php echo $tch_libelle ?></td>
                                        <td align="center"><?php echo getdateC($tch_debut).' - '.getdateC($tch_fin_prevu); ?></td>
                                        <td align="center"><?php echo $dev_objet; ?></td>
                                        <td align="center">                                        
                                        <button class="btn btn-link ButtonRetirer" data-toggle="tooltip" data-placement="top" title="Retirer <?php echo $tch_libelle; ?>"><i class="fa fa-trash-o fa-lg text-rouge"></i></button>
                                        </td>
                                        <td align="center">
                                        <div data-toggle="tooltip" data-placement="top" title="Modifier <?php echo $tch_libelle; ?>">
                                        <button class="btn btn-link modifButton" data-toggle="modal" data-backdrop="static"><i class="fa fa-pencil fa-lg"></i></button></div></td>
                                    </tr>
                                    <?php 
								}
									?>
                                </tbody>
                            </table>
                            <!-- /.table-responsive -->
                <div class="row">
                <div class="col-lg-4 pull-right">
                <?php if(isset($_GET['act'])){?>
                  <a href="?yk=chantiergest&svt&dev=<?php echo $IdChant0;?>" class="btn btn-success btn-block"><i class="fa fa-save fa-sm"></i>&nbsp;&nbsp;Terminer&nbsp;</a>                  
                  <?php }else{?>
                  <a href="?yk=chantieraddeqp&svt&dev=<?php echo $IdChant0;?>" class="btn btn-success btn-block"><i class="fa fa-save fa-sm"></i>&nbsp;&nbsp;Terminer et g&eacute;rer les &eacute;quipes&nbsp;</a>                  
                  <p class="help-block">Cliquer pour terminer le planning puis cr&eacute;er les &eacute;quipes chantiers</p>
                  <?php }?>
                </div>
                </div>          
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                
              </div>
          </div>
      </div>
  </div>
</div>


<!-- Modal -->
<div class="modal fade" id="ModalModifDetTache" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">           
            <div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
<h4 class="modal-title" id="myModalLabel">Modifier</h4>
            </div>
<div class="row">
  <div class="col-lg-12">
      <div class="panelglobal panel-default-global">
          <form role="form" action="update_detail_tache.php" method="post" id="formModDetTache">
          <div class="panel-body">
              <div class="row">              
				  <div class="col-lg-6">
                    <div class="form-group">
                    <input type="hidden" name="IdTache" id="IdTache" value="">
                    <input type="hidden" name="IdChant" id="IdChant" value="<?php echo $IdChant0; ?>">
                       <select name="devis" id="devis" required="required" class="form-control">
                           <option value="">-- S&eacute;lectionnez le devis --</option>
                           <?php 
						   $ch = "dev_id, dev_ref";
						   $tab = DEVIS." LEFT JOIN ".CHANTIERS." ON dev_clt=cht_client";
						   $cd = "dev_etat_accepte=1 AND dev_etat_sup=1 AND cht_id=$IdChant0";
						   deroulant($ch,$tab,$cd,"dev_ref",$devis);
						   ?>
                         </select>
                     </div>
                  </div>
                  <div class="col-lg-6">
                     <div class="form-group">
                       <input type="text" class="form-control" disabled="disabled" name="obj" id="obj">
                       <input type="hidden" name="objHid" id="objHid">
                    </div>
                  </div>
               </div>
              <div class="row">              
                  <div class="col-lg-12">
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Libell&eacute; de la t&acirc;che" name="tache" id="tache" required="required">
                     </div>
                  </div>
              </div>
              <div class="row">              
                  <div class="col-lg-6">
                     <div class="form-group input-group">
                       <span class="input-group-addon">Date d&eacute;but</span>
                        <input type="date" class="form-control" placeholder="Date d&eacute;but" name="datedeb" id="datedeb" required="required">
                        <input type="hidden" name="datedebInit" id="datedebInit" value="<?php echo $cht_debut; ?>">
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="form-group input-group">
                       <span class="input-group-addon">Date fin</span>
                        <input type="date" class="form-control" placeholder="Date fin" name="datefin" id="datefin" required="required">
                        <input type="hidden" name="datefinInit" id="datefinInit" value="<?php echo $cht_fin_prevu; ?>">
                    </div>
                  </div> 
              </div>
          </div>
          </form>
      </div>
  </div>
</div>
            </div>
            <div class="modal-footer">
                 <button name="submitFormModDettache" id="submitFormModDettache" type="button" class="btn btn-success"><i class="fa fa-save fa-sm"></i>&nbsp;&nbsp;Modifier</button>
 
 <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times fa-sm"></i>&nbsp;&nbsp;Fermer</button>
 
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->  
<?php 
}
}else{
?><script language="javascript">document.location="index.php"</script><?php 
}
?>