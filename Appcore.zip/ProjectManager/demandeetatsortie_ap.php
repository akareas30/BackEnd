<?php 
if($_SESSION['AP_user_profil']=="AD" || $_SESSION['AP_user_profil']=="DG" || $_SESSION['AP_user_profil']=="GM"){?>
<div class="row">
  <div class="col-lg-12">
      <h3 class="page-header">ETAT SORTIE EN COURS</h3>
  </div>
</div>
<?php 

$reqDet = selections("*",VT_DMD_COURANTES,1,"DMDDET_ID DESC");
$resDet = $pdo->query($reqDet);

?>
<div class="row">
   <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">LES SORTIES EN COURS</div>
            <!-- /.panel-heading -->
            <div class="panel-body">
              <table width="100%" class="table table-bordered table-hover" id="tb_dmdetatsorti">
                <thead>
                    <tr>
                        <th align="center">#</th>
                        <th align="left">Outil</th>
                        <th align="left">Description</th>
                        <th align="left">Ref</th>
                        <th align="left">Date Sortie</th>
                        <th align="left">Retour pr&eacute;vu</th>
                        <th align="center">Type</th>
                    </tr>
                </thead>
                <tbody>
                <?php 
                $i = 0;
                $montant = 0;
                $Total = 0;
                while($col = $resDet->fetch()){
                  $DMDDET_ID 		= $col['DMDDET_ID'];
                  $OUTIL_ID			= $col['OUTIL_ID'];
                  $OUTIL_LIB 		= $col['OUTIL_LIB'];
                  $OUTIL_REF		= $col['OUTIL_REF'];
                  $OUTIL_DESCRIP	= $col['OUTIL_DESCRIP'];
                  $OUTIL_PRIXLOC_PART = $col['OUTIL_PRIXLOC_PART'];
                  $OUTIL_PRIXLOC_SOC  = $col['OUTIL_PRIXLOC_SOC'];
                  $NBRE_JRS 		  = $col['NBRE_JRS'];
                  $DATE_SORTIE 		  = $col['DATE_SORTIE'];
                  $DMD_REF			  = $col['DMD_REF'];
                  $DMD_TYPE 		  = $col['DMD_TYPE'];
                  $DEMANDEUR		  = $col['DEMANDEUR'];
				  $MOTIF			  = $col['MOTIF'];

				  if($DMD_TYPE==0){
					  $typedmd = "LOCATION";
					  $dateSortInit = new DateTime(getdateC($DATE_SORTIE));
					  $dateRet	  	= new DateTime(getdateC($DATE_SORTIE));
					  $dateRet->add(new DateInterval('P'.$NBRE_JRS.'D'));

					  $dateJr	  = new DateTime(date("Y-m-d"));
					  if($dateJr > $dateRet ){
						  $NbreJrRetart = $dateRet->diff($dateJr);
						  $AffDate = "<span class='text-rouge'>Le ".$dateRet->format('d-m-Y')."</span>";
						  $AffDate .= "<br /><em><span class='small text-rouge'>Delai expir&eacute; de ".$NbreJrRetart->format('%r%a Jour(s)')."</span></em>";
					  }else{
					  	$AffDate = "Le ".$dateRet->format('d-m-Y');
					  }
				  }elseif($DMD_TYPE==1){
					  $typedmd = "INTERNE";
					  $AffDate = "";
				  }
				  else $typedmd="";
                  $i++;
                  ?>
               
                    <tr class="even gradeA" data-numligne="<?php echo $i; ?>">
                      <td align="center"><?php echo $i; ?></td>
                      <td><?php echo "<strong>".$OUTIL_LIB."</strong>";?></td>
                      <td><?php echo nl2br($OUTIL_DESCRIP); ?></td>
                      <td align="left"><?php echo $OUTIL_REF; ?></td>
                      <td align="center"><?php echo getdateC($DATE_SORTIE);?></td>
                      <td align="center"><?php echo $AffDate;?></td>
                      <td align="center"><?php echo $typedmd; ?></td>
                    </tr>    
                    <?php 
                }
                    ?>
                </tbody>
              </table>
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
</div>   
<?php 
}else{
?><script language="javascript">document.location="index.php"</script><?php 
}
?>