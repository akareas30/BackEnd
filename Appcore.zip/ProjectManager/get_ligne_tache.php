<?php
session_start();
ini_set('session.bug_compat_42', 0);
ini_set('session.bug_compat_warn', 0);
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php");
VerifTempsLog();

if(isset($_GET['tache'])){
	$IdTache 	= $_GET['tache'];
	$i				= $_GET['nl'];
	$IdChant0	= $_GET['ch'];
	
}

$chp = "tch_id, tch_libelle, tch_debut, tch_fin_prevu, tch_fin_eff, dev_ref, tch_nature, tch_taux, dev_objet";	  
$tb = TACHES." LEFT JOIN ".DEVIS." ON tch_devis=dev_id"; 
$reqDet = selections($chp,$tb,"tch_id=$IdTache","tch_id ASC");
$resDet = $pdo->query($reqDet);		

$col = $resDet->fetch();
$tch_id 		 = $col['tch_id'];
$tch_libelle 	 = $col['tch_libelle'];
$tch_debut	 	 = $col['tch_debut'];
$tch_fin_prevu   = $col['tch_fin_prevu'];
$tch_fin_eff   	 = $col['tch_fin_eff'];
$tch_nature 	 = $col['tch_nature'];
$tch_taux 	     = $col['tch_taux'];
$dev_ref 	 	 = $col['dev_ref'];
$dev_objet 	     = $col['dev_objet'];

$nature = "";
if($tch_nature==1)$nature = '&nbsp;&nbsp;<span data-toggle="tooltip" data-placement="right" title="T&acirc;che suppl&eacute;mentaire" class="text-bleu"><i class="fa fa-plus"></i></span>';

$LeJour = date('Y-m-d');
$TimeJour 	 = new DateTime($LeJour);
$timeFinPrev = new DateTime($tch_fin_prevu);
$timeFinEff  = new DateTime($tch_fin_eff);

$JourFinEff = $timeFinEff->format('d-m-Y');

if($tch_taux<100){//Si taux <100 alors tache tjrs en cours
	$statut = '<span class="text-bleu"><i class="fa fa-pencil-square-o"></i>&nbsp;En cours</span>'; 
}else{//tache terminé
	$statut = '<span class="text-vert"><i class="fa fa-check-square-o"></i>&nbsp;Termin&eacute;</span>';
	if($tch_fin_eff!=0){
		$intervalEff = $timeFinPrev->diff($timeFinEff);
		$NbreJourFinEff = $intervalEff->format('J%R%a');//Nbre entre la date fin effective et celle prevue
		if(($timeFinEff>$timeFinPrev)==true){
			$statut .='<br /><span class="small text-rouge">&nbsp;&Agrave; '.$NbreJourFinEff.' ('.$JourFinEff.')</span>';
		}else{
			$statut .='<br /><span class="small text-vert">&nbsp;&Agrave; '.$NbreJourFinEff.' ('.$JourFinEff.')</span>';
		}
	}
}

if($tch_taux>=0 and $tch_taux<=50){
	$colorTx = "text-rouge";
}elseif($tch_taux>50 and $tch_taux<=90){
	$colorTx = "text-jaune";
}elseif($tch_taux>90 and $tch_taux<100){
	$colorTx = "text-orange";
}elseif($tch_taux==100){
	$colorTx = "text-vert";
}

$expire = "";
$colorExpire = "";
//Si delai expiré
if(($TimeJour>$timeFinPrev)==true){
	$expire = "Expir&eacute;";//Affiché "Expiré"
	$colorExpire = "text-rouge";//et le mettre en rouge
	$colorJ = "text-rouge";//Mettre en rouge la couleur du Jour J-
}elseif(($TimeJour==$timeFinPrev)==true){
	$colorJ = "text-rouge";//Si on est au Jour J;
}elseif(($TimeJour>$timeFinPrev)==false){
	$colorJ = "text-vert";//Sil le delai n'a pas expiré, mettre en vert la couleur du Jour J-
}
//Nbre de d'ici à la date fin prévu
$interval = $timeFinPrev->diff($TimeJour);
$NbreJourJ = $interval->format('J%R%a');

?>
	<tr class="even gradeA success" data-id="<?php echo $tch_id;?>" data-ch="<?php echo $IdChant0; ?>" data-numligne="<?php echo $i; ?>">
			<td align="center"><?php echo $i; ?></td>
			<td><?php echo "<strong>".$tch_libelle.$nature.'</strong><br /><span class="small">'.$dev_objet.'<span />'; ?></td>
			<td align="center">
			<?php echo getdateC($tch_debut).' - '.getdateC($tch_fin_prevu); 
			if($expire!="")echo '<br /><span class="small '.$colorExpire.'">'.$expire.'</span>';
			?>
			</td>
			<td align="center">
			<?php echo '<span class="'.$colorTx.'">'.$tch_taux.'%</span>';
			if($tch_taux<100)echo '<span class="small '.$colorJ.'">&nbsp;('.$NbreJourJ.')</span>';
			?>
			</td>
			<td align="center"><?php echo $statut;?></td>
			<td align="center">
			<div data-toggle="tooltip" data-placement="top" title="Rapport d'ex&eacute;cution de la t&acirc;che">
			<button class="btn btn-link RapportTacheButton" data-title="<?php echo $tch_libelle; ?>" data-toggle="modal" data-backdrop="static"><i class="glyphicon glyphicon-edit"></i></button></div>
			</td>
	</tr>
