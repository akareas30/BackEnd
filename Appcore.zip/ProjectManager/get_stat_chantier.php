<?php
session_start();
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php"); 
VerifTempsLog();

if(isset($_POST['datedeb']) or isset($_POST['datefin'])){
  if($_POST['datedeb']!="") $deb = trim($_POST['datedeb']); else $deb='0000-00-00';
  if($_POST['datefin']!="") $fin = trim($_POST['datefin']); else $fin=date('Y-m-d');
  $cndEtatCplt = " AND cht_date_cre BETWEEN '$deb' AND '$fin'";
}elseif(!isset($_POST['datedeb']) and !isset($_POST['datefin'])){
  $cndEtatCplt = "";
}

  
$chpEtat="COUNT(cht_id)";
$cndEtat1="cht_etat=1";//en cours
$cndEtat2="cht_etat=2";//terminé
$cndEtat3="cht_etat=3";//Annulé


$req1  = selections($chpEtat,CHANTIERS,$cndEtat1.$cndEtatCplt,1); 
$req2  = selections($chpEtat,CHANTIERS,$cndEtat2.$cndEtatCplt,1);
$req3  = selections($chpEtat,CHANTIERS,$cndEtat3.$cndEtatCplt,1);
 
$Nbre1  = $pdo->query($req1)->fetchColumn();
$Nbre2  = $pdo->query($req2)->fetchColumn();
$Nbre3  = $pdo->query($req3)->fetchColumn();
   
$data = array(
				array('label'=>'En cours', 'data'=>$Nbre1, 'color'=>"#3333FF"),//bleu
				array('label'=>'Terminé', 'data'=>$Nbre2, 'color'=>"#009933"),//vert
				array('label'=>'Annulé', 'data'=>$Nbre3, 'color'=>"#FFC338")//orangé
				);
				
echo json_encode($data);
$pdo=null;
?>
