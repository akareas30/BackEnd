<?php
session_start();
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php");
VerifTempsLog();


if(isset($_GET['dev']) and isset($_GET['ret'])){
  $IdDevis0  = $_GET['dev'];	
  include('devisdetail_ap.php');
  $pdo=null;
}
?>