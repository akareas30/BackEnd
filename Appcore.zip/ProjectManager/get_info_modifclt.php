<?php
session_start();
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php"); 
VerifTempsLog();
if(isset($_GET['id'])){

  $idclt  = $_GET['id'];
  $chp = "clt_id, clt_type, clt_nom, clt_abrege, clt_code, clt_tel1, clt_mail, clt_ncc, clt_localisation, clt_interloc, DATE_FORMAT(clt_date_cre, '%d/%m/%Y %H:%i:%s') AS date_cre, clt_etat";
  $req = selections($chp,CLIENTS,"clt_id=$idclt","clt_id");
  $res = $pdo->query($req);
  $donnees = $res->fetch();
  echo json_encode($donnees);
  $pdo=null;
}
?>
