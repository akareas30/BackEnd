<?php 
if($_SESSION['AP_user_profil']=="AD" || $_SESSION['AP_user_profil']=="DG" || $_SESSION['AP_user_profil']=="DT" || $_SESSION['AP_user_profil']=="CC"){
if(isset($_GET['act']) and  $_GET['act']=="add"){ ?>
<div class="row">
  <div class="col-lg-12">
      <h3 class="page-header">ENREGISTRER UN CHANTIER</h3>
  </div>
  <div class="col-lg-12">
      <h4>ETAPE 1/3: INFOS GENERALES DU CHANTIER</h4>
  </div>
  <!-- /.col-lg-12 -->
</div>
<?php 
if(isset($_POST['suiv'])){
	$clientId  		= trim($_POST['clientId']);
	$libelle  		= htmlspecialchars(strtoupper(trim(addslashes($_POST['libelle']))));
	$chef  			= htmlspecialchars(strtoupper(trim(addslashes($_POST['chef']))));
	$ref  			= htmlspecialchars(strtoupper(trim(addslashes($_POST['ref']))));
	$datedebut  	= trim($_POST['datedebut']);
	$datefin  		= trim($_POST['datefin']);
	$descrip  		= htmlspecialchars(strtoupper(trim(addslashes($_POST['descrip']))));
	$localisation  	= htmlspecialchars(strtoupper(trim(addslashes($_POST['localisation']))));
	if(empty($ref))$ref=$libelle;
	if($libelle=="" or $datedebut=="" or $datefin==""){
		?><div class="alert alert-warning alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <?php echo TXT_AVERT_CHP_OBLIGE; ?></div><?php
	}else{	
	 $tb = CHANTIERS."(cht_client, cht_chef, cht_ref, cht_libelle, cht_descrip, cht_localise, cht_debut, cht_fin_prevu, cht_date_cre, cht_user_cre)";
	 $val = "'$clientId','$chef','$ref','$libelle','$descrip','$localisation','$datedebut','$datefin',NOW(),".$_SESSION['AP_iduser'];
	 if($IdChant0 = AjoutBDGetId($tb,$val)){
		 ?><script language="javascript">document.location="?yk=chantieradd2&svt&dev=<?php echo $IdChant0;?>"</script><?php
	 }else{
		 ?><div class="alert alert-danger alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <?php echo TXT_ALERT_ERROR_ENREG; ?></div><?php
	 }
	}
}
?>
<!-- /.row -->
<div class="row">
  <div class="col-lg-12">
      <div class="panelglobal panel-default-global">
          <form role="form" action="" method="post" id="formAddChantier">
          <div class="panel-body">
              <div class="row">              
                  <div class="col-lg-4">
                  <div class="form-group">
                  <label>Client *</label>
                  <input class="form-control bs-autocomplete" id="libclt" value="" placeholder="Indiquez le client" type="text" data-source="get_rech_client.php" data-hidden_field_id="clientId" data-item_id="clt_id" data-item_label="clt_nom" autocomplete="off" autofocus="autofocus" required="required">
                        <input class="form-control" id="clientId" name="clientId" value="" type="hidden" readonly>
                  </div>
                  	<div class="form-group">
                        <label>Libell&eacute; *</label>
                        <input class="form-control" id="libelle" name="libelle" value="" placeholder="Le nom d&eacute;signant du chantier" type="text" required="required" autofocus="autofocus">
                     </div>
                     <div class="form-group">
                        <label>R&eacute;f&eacute;rence</label>
                        <input class="form-control" id="ref" name="ref" value="" placeholder="La r&eacute;f&eacute;rence du chantier" type="text">
                     </div>
                     <div class="form-group">
                        <label>Date de d&eacute;but *</label>
                        <input class="form-control" id="datedebut" name="datedebut" value="" placeholder="Date de d&eacute;but" type="date" required="required">
                    </div>
                    <div class="form-group">
                        <label>Date de fin pr&eacute;vu *</label>
                        <input class="form-control" id="datefin" name="datefin" value="" placeholder="Date de fin pr&eacute;vu" type="date" required="required">
                     </div>
                  </div>
                  <div class="col-lg-4">
                  <div class="form-group">
                        <label>Chef du chantier</label>
                        <input class="form-control" id="chef" name="chef" value="" placeholder="Le nom du Chef du chantier" type="text">
                     </div>
                     <div class="form-group">
                       <label>Description</label>
                        <textarea name="descrip" rows="3" class="form-control" id="descrip" placeholder="La description du chantier"></textarea>
                    </div>
                    <div class="form-group">
                       <label>Localisation</label>
                        <textarea name="localisation" rows="3" class="form-control" id="localisation" placeholder="La localisation du chantier"></textarea>
                    </div>
                  </div>
              </div>
              <div class="row">
              <div class="col-lg-4 center-block">
                  <button name="suiv" id="suiv" type="submit" class="btn btn-warning btn-block">&nbsp;Suivant pour ajouter les t&acirc;ches...&nbsp;<i class="fa fa-long-arrow-right fa-lg"></i></button>
                  <p class="help-block">Cliquer sur Suivant pour ajouter le planning</p>
              </div>
              </div>
          </div>
          </form>
      </div>
  </div>
</div>
<?php 
}

if(isset($_GET['act']) and $_GET['act']=="mod"){
	$idcht = $_GET['cht'];
	$chp = "cht_id, cht_chef, cht_ref, cht_libelle, cht_descrip, cht_localise, cht_debut, cht_fin_prevu, cht_fin_eff, cht_observ, clt_id, clt_abrege, cht_etat";
	$tb = CHANTIERS." CH LEFT JOIN ".CLIENTS." C ON CH.cht_client=C.clt_id";
	$cnd = "cht_id=$idcht";
	$req = selections($chp,$tb,$cnd,"cht_id DESC");
	$res = $pdo->query($req);
	$col = $res->fetch(); 
	$old_cht_id   	 	= $col['cht_id'];
	$old_cht_chef  	 	= $col['cht_chef'];
	$old_cht_ref  	 	= $col['cht_ref'];
	$old_cht_libelle 	= $col['cht_libelle'];
	$old_cht_descrip   	= $col['cht_descrip'];
	$old_cht_localise 	= $col['cht_localise'];
	$old_cht_debut   	= $col['cht_debut'];
	$old_cht_fin_prevu  = $col['cht_fin_prevu'];
	$old_cht_fin_eff	= $col['cht_fin_eff'];
	$old_cht_observ   	= $col['cht_observ'];
	$old_clt_id 		= $col['clt_id'];
	$old_clt_abrege   	= $col['clt_abrege'];
	$old_cht_etat  		= $col['cht_etat'];
?>
<div class="row">
  <div class="col-lg-12">
      <h3 class="page-header">MODIFIER UN CHANTIER</h3>
  </div>
  <div class="col-lg-12">
      <h4>SAISIR LES INFOS A MODIFIER</h4>
  </div>
  <!-- /.col-lg-12 -->
</div>
<?php 

if(isset($_POST['modif']) or isset($_POST['modifSuiv'])){
	$clientId  		= trim($_POST['clientId']);
	$libelle  		= htmlspecialchars(strtoupper(trim(addslashes($_POST['libelle']))));
	$chef  			= htmlspecialchars(strtoupper(trim(addslashes($_POST['chef']))));
	$ref  			= htmlspecialchars(strtoupper(trim(addslashes($_POST['ref']))));
	$datedebut  	= trim($_POST['datedebut']);
	$datefin  		= trim($_POST['datefin']);
	$descrip  		= htmlspecialchars(strtoupper(trim(addslashes($_POST['descrip']))));
	$localisation  	= htmlspecialchars(strtoupper(trim(addslashes($_POST['localisation']))));
	$datefineff  	= trim($_POST['datefineff']);
	$etat  			= trim($_POST['etat']);
	$observ  		= htmlspecialchars(strtoupper(trim(addslashes($_POST['observ']))));
	
	if(empty($ref))$ref=$libelle;
	
	$NbreTacheEncours = getRefTacheEncours($idcht);
	
	if($libelle=="" or $datedebut=="" or $datefin==""){
		?><div class="alert alert-warning alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <?php echo TXT_AVERT_CHP_OBLIGE; ?></div><?php
	}else{	
	 $mod = "cht_chef='$chef', cht_ref='$ref', cht_libelle='$libelle', cht_descrip='$descrip', cht_localise='$localisation', cht_debut='$datedebut', cht_fin_prevu='$datefin', cht_fin_eff='$datefineff', cht_observ='$observ', cht_etat='$etat',cht_date_mod=NOW(), cht_user_mod=".$_SESSION['AP_iduser'];
	  if($etat==2 and $NbreTacheEncours>0){//si l'option "Terminé" est selectionné et qu'il y a des taches en cours
		?><div class="alert alert-danger alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <?php echo "Ce chantier ne peut &ecirc;tre marqu&eacute; comme &quot;Termin&eacute;&quot; car ".$NbreTacheEncours." t&acirc;ches ont (a) le statut &quot;En cours&quot; !"; ?></div><?php
	  }else{
	   if(!update(CHANTIERS,$mod,"cht_id=$old_cht_id")===true){
		 ?><div class="alert alert-success alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <?php echo TXT_ALERT_SUCCES_MODIF; ?></div>
        <?php 
		if(isset($_POST['modif'])){?>
			<script language="javascript">document.location="?yk=chantiergest&act=add"</script><?php
		}elseif(isset($_POST['modifSuiv']) and $etat==1){?>
			<script language="javascript">document.location="?yk=chantieradd2&svt&dev=<?php echo $old_cht_id;?>"</script><?php
		}else{?>
			<script language="javascript">document.location="?yk=chantiergest&act=add"</script><?php
			}
	 }else{
		 ?><div class="alert alert-danger alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <?php echo TXT_ALERT_ERROR_MODIF; ?></div><?php
	 }
	   }
	}
}

?>
<!-- /.row -->
<div class="row">
  <div class="col-lg-12">
      <div class="panelglobal panel-default-global">
          <form role="form" action="" method="post" id="formModChantier">
          <div class="panel-body">
              <div class="row">              
                  <div class="col-lg-4">
                  <div class="form-group">
                  <label>Client *</label>
                  <input class="form-control bs-autocomplete" id="libclt" placeholder="Indiquez le client" type="text" data-source="get_rech_client.php" data-hidden_field_id="clientId" data-item_id="clt_id" data-item_label="clt_nom" autocomplete="off" required="required" value="<?php echo $old_clt_abrege; ?>" disabled="disabled">
                        <input class="form-control" id="clientId" name="clientId" value="<?php echo $old_clt_id ; ?>" type="hidden" readonly="readonly">
                  </div>
                  	<div class="form-group">
                        <label>Libell&eacute; *</label>
                        <input class="form-control" id="libelle" name="libelle" placeholder="Le nom d&eacute;signant du chantier" type="text" required="required" autofocus="autofocus" value="<?php echo $old_cht_libelle; ?>">
                     </div>
                     <div class="form-group">
                        <label>R&eacute;f&eacute;rence</label>
                        <input class="form-control" id="ref" name="ref" value="<?php echo $old_cht_ref; ?>" placeholder="La r&eacute;f&eacute;rence du chantier" type="text">
                     </div>
                     <div class="form-group">
                        <label>Date de d&eacute;but *</label>
                        <input class="form-control" id="datedebut" name="datedebut" value="<?php echo $old_cht_debut ; ?>" placeholder="Date de d&eacute;but" type="date" required="required">
                    </div>
                    <div class="form-group">
                        <label>Date de fin pr&eacute;vu *</label>
                        <input class="form-control" id="datefin" name="datefin" value="<?php echo $old_cht_fin_prevu; ?>" placeholder="Date de fin pr&eacute;vu" type="date" required="required">
                     </div>
                  </div>
                  <div class="col-lg-4">
                  <div class="form-group">
                        <label>Chef du chantier</label>
                        <input class="form-control" id="chef" name="chef" value="<?php echo $old_cht_chef; ?>" placeholder="Le nom du Chef du chantier" type="text">
                     </div>
                     <div class="form-group">
                       <label>Description</label>
                        <textarea name="descrip" rows="3" class="form-control" id="descrip" placeholder="La description du chantier"><?php echo $old_cht_descrip; ?></textarea>
                    </div>
                    <div class="form-group">
                       <label>Localisation</label>
                        <textarea name="localisation" rows="3" class="form-control" id="localisation" placeholder="La localisation du chantier"><?php echo $old_cht_localise; ?></textarea>
                    </div>
                  </div>
                  <div class="col-lg-4">
                    <div class="form-group">
                        <label>Changer le statut</label>
                        <select name="etat" id="etat" class="form-control">
                                 <option value="1" <?php if($old_cht_etat=="1"){?>selected="selected"<?php }?>>En cours</option>
                                 <option value="2" <?php if($old_cht_etat=="2"){?>selected="selected"<?php }?>>Termin&eacute;</option>
                                 <option value="3" <?php if($old_cht_etat=="3"){?>selected="selected"<?php }?>>Annul&eacute;</option>                                 
                               </select>
                    </div>
                    <div class="form-group">
                        <label>Date de fin effective</label>
                        <input class="form-control" id="datefineff" name="datefineff" value="<?php if($old_cht_fin_eff!=0)echo $old_cht_fin_eff; ?>" placeholder="Date de fin effective" type="date">
                     </div>
                     <div class="form-group">
                        <label>Observations</label>
                        <textarea name="observ" rows="3" class="form-control" id="observ" placeholder="Faire des observations"><?php echo $old_cht_observ; ?></textarea>
                    </div>
                    
                  </div>
              </div>
              <div class="row">
              <div class="col-lg-4 center-block" id="blcModChantSuiv">
                  <button name="modifSuiv" id="modifSuiv" type="submit" class="btn btn-warning  btn-block" onClick="return confirm('Confirmez-vous la modification ?');"><i class="fa fa-save fa-lg"></i>&nbsp;&nbsp;Modifier le chantier et poursuivre</button>
                  <p class="help-block"><?php echo TXT_AVERT_CHP_OBLIGE; ?></p>
              </div>
              <div class="col-lg-4 center-block">
                  <button name="modif" id="modif" type="submit" class="btn btn-success btn-block" onClick="return confirm('Confirmez-vous la modification ?');"><i class="fa fa-save fa-lg"></i>&nbsp;&nbsp;Modifier et Terminer</button><p class="help-block">&nbsp;</p>
              </div>
              <div class="col-lg-4">
                  <a href="?yk=chantiergest&act=add" class="btn btn-danger btn-block"><i class="fa fa-undo fa-lg"></i>&nbsp;&nbsp;Annuler</a>
              </div>
              </div>
          </div>
          </form>
      </div>
  </div>
</div>
<?php 
}
}else{
?><script language="javascript">document.location="index.php"</script><?php 
}
?>