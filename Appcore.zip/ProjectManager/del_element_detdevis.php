<?php
session_start();
ini_set('session.bug_compat_42', 0);
ini_set('session.bug_compat_warn', 0);
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php"); 
VerifTempsLog();

if(isset($_GET['id']) and isset($_GET['dev'])){
  $actid     = (int)$_GET['id'];
  $IdDevis0  = (int)$_GET['dev'];
  if(!delete(DEVIS_DET,"devdet_id=$actid")===true){
	  $array = array($actid);
	  //echo json_encode($array);
  }

}

$req = selections("dev_moeuvre",DEVIS,"dev_id=$IdDevis0",1);
$dev_moeuvre = $pdo->query($req)->fetchColumn();

$chp = "devdet_id, devdet_devid, devdet_rub1, devdet_rub2, devdet_materiel, devdet_qte,devdet_unite, devdet_prixunit, devdet_etat_enreg";
$reqDet = selections($chp,DEVIS_DET,"devdet_devid=$IdDevis0","devdet_rub1 ASC, devdet_rub2 ASC, devdet_id DESC");
$resDet = $pdo->query($reqDet);	
?>
<tbody>
<?php 
$i = 0;
$temoin1 = "";
$temoin2 = "";
$mtLigne = 0;
$MtTot = 0;
$MtTotMo = 0;
while($col = $resDet->fetch()){
  $devdet_id 		 = $col['devdet_id'];
  $devdet_devid 	 = $col['devdet_devid'];
  $devdet_rub1		 = $col['devdet_rub1'];
  $devdet_rub2 		 = $col['devdet_rub2'];
  $devdet_materiel 	 = $col['devdet_materiel'];
  $devdet_qte	     = $col['devdet_qte'];
  $devdet_unite 	 = $col['devdet_unite'];
  $devdet_prixunit 	 = $col['devdet_prixunit'];
  $devdet_etat_enreg = $col['devdet_etat_enreg'];								  
	
	$mtLigne = $devdet_qte*$devdet_prixunit;
  
	if($temoin1 != $devdet_rub1){
	  $temoin1 = $devdet_rub1;
	  $affRub1 = $temoin1;
	  $class1 = '';
	}else{
		$affRub1='&quot;';
		$class1 = 'align="center"';
	}
  $temoin1 = $devdet_rub1;
  
  if($temoin2 != $devdet_rub2){
	  $temoin2 = $devdet_rub2;
	  $affRub2 = $temoin2;
	  $class2 = '';
	}else{
		$affRub2='&quot;';
		$class2 = 'align="center"';
	}
  $temoin2 = $devdet_rub2;							  
  
  $i++;
  ?>
	<tr id="<?php echo $devdet_id;?>" data-dev="<?php echo $IdDevis0; ?>" class="even gradeA success">
		<td align="center"><?php echo $i ?></td>
		<td <?php echo $class1; ?>><?php echo "<strong>".$affRub1."</strong>";?></td>
		<td <?php echo $class2; ?>><?php echo $affRub2 ?></td>
		<td><?php echo $devdet_materiel;?></td>
		<td align="center"><?php echo $devdet_qte; ?></td>
		<td align="center"><?php echo $devdet_unite; ?></td>
		<td align="right"><?php echo number_format($devdet_prixunit,0,'',' '); ?></td>
		<td align="center">                                        
		<button class="btn btn-link ButtonRetirer" data-toggle="tooltip" data-placement="top" data-tb="myDevisDetTb" title="Retirer <?php echo $devdet_materiel; ?>"><i class="fa fa-trash-o fa-lg text-rouge"></i></button>
		
		</td>
		<td align="center">
        <div data-toggle="tooltip" data-placement="top" title="Modifier <?php echo $devdet_materiel; ?>">
		<button class="btn btn-link modifButton" data-toggle="modal" data-backdrop="static"><i class="fa fa-pencil fa-lg"></i></button></div></td>
	</tr>
	<?php 
		$MtTot = $MtTot+$mtLigne;
}
$MtTotMo = $MtTot+$dev_moeuvre;
	?>
</tbody>
<tfoot>
	<tr id="totFoot">
		<th colspan="6" align="right">TOTAL HT</th>
		<th align="right"><?php echo number_format($MtTot,0,'',' '); ?></th>
		<th colspan="2" align="center">&nbsp;</th>
	</tr>
	<tr id="totMoFoot">
		<th colspan="6" align="right">TOTAL DEVIS HT (Main d'&oelig;uvre incluse)</th>
		<th align="right"><?php echo '<span class="text-rouge">'.number_format($MtTotMo,0,'',' ').'</span>'; ?></th>
		<th colspan="2" align="center">&nbsp;</th>
	</tr>
</tfoot>
