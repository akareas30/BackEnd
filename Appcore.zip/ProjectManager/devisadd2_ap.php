<?php 
if(isset($_GET['dev'])){
	$IdDevis0 = (int)$_GET['dev'];
}
$chp = "D.dev_ref, D.dev_objet, D.dev_moeuvre, C.clt_type, C.clt_nom, C.clt_abrege, D.dev_etat_accepte";
$tb = DEVIS." D LEFT JOIN ".CLIENTS." C ON D.dev_clt=C.clt_id";
$cnd = "dev_id=$IdDevis0";

$reqLib = selections($chp,$tb,$cnd,1);
$res = $pdo->query($reqLib);
$col = $res->fetch();
$dev_ref 	= $col['dev_ref'];
$dev_objet 	= $col['dev_objet'];
$clt_type 	= $col['clt_type'];
$clt_nom 	= $col['clt_nom'];
$clt_abrege = $col['clt_abrege'];
$dev_moeuvre = $col['dev_moeuvre'];
$dev_etat_accepte = $col['dev_etat_accepte'];
if($dev_etat_accepte==0){
?>
<div class="row">
  <div class="col-lg-12">
      <h3 class="page-header">ENREGISTRER UN DEVIS</h3>
  </div>
  <div class="col-lg-12">
      <h4>ETAPE 2/2: DETAILS DU DEVIS: <?php echo '<span class="text-rouge">'.stripslashes($dev_ref)."</span>&nbsp;|&nbsp;";if($clt_abreg!="")echo '<span class="text-rouge">'.$clt_abreg.'</span>';else {echo '<span class="text-rouge">'.$clt_nom.'</span>';} echo '&nbsp;|&nbsp;<span class="text-rouge">'.$dev_objet.'</span>';?></h4>
  </div>
  <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
<div class="row">
  <div class="col-lg-12">
      <div class="panelglobal panel-default-global">
          <div class="panel-body">
              <div class="row">
              <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">1.&nbsp;Ajouter les d&eacute;tails</div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                <form role="form" method="post" id="formAddDetDevis" action="">
                  <div class="col-lg-4">
                    <div class="form-group">
                    <input type="hidden" name="IdDevis" id="IdDevis" value="<?php echo $IdDevis0; ?>">
                       <input type="text" class="form-control" placeholder="Rubrique 1: Exple: Travaux RDC..." autofocus="autofocus" name="rub1" id="rub1" >
                     </div>
                  </div>
                  <div class="col-lg-4">
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Rubrique 2: Exple: MACONNERIE" name="rub2" id="rub2" >
                     </div>
                  </div>
                  <div class="col-lg-4">
                    <div class="form-group">
                       <input type="text" class="form-control" placeholder="D&eacute;signation..." name="materiel" id="materiel" required="required" > 
                     </div>
                  </div>
                  <div class="col-lg-3">
                    <div class="form-group">
                       <input type="number" class="form-control" placeholder="Quantit&eacute;" name="qte" id="qte" required="required" >
                     </div>
                  </div>
                  <div class="col-lg-3">
                    <div class="form-group">
                       <input type="text" class="form-control" placeholder="L'unit&eacute;: Exple: U, Kg, m&sup3;, ..." name="unite" id="unite">
                     </div>
                  </div>
                  <div class="col-lg-3">
                    <div class="form-group">
                       <input type="text" class="form-control" placeholder="Prix Unitaire HT" name="prixu" id="prixu" >
                     </div>
                  </div>
                  
               </form>
               <div class="col-lg-3">
                  <button class="btn btn-warning btn-block" name="ButtonAddDetDevis" id="ButtonAddDetDevis" data-action="put_detail_devis.php"><i class="fa fa-plus-square fa-lg"></i>&nbsp;&nbsp;Ajouter&nbsp;</button>
                  </div>
               			</div>
                    </div>
               </div>
               
               <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">2.&nbsp; Les D&eacute;tails du devis</div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
							<?php 
							$chp = "devdet_id, devdet_devid, devdet_rub1, devdet_rub2, devdet_materiel, devdet_qte,devdet_unite, devdet_prixunit, devdet_etat_enreg";
							$reqDet = selections($chp,DEVIS_DET,"devdet_devid=$IdDevis0","devdet_rub1 ASC, devdet_rub2 ASC, devdet_id DESC");
							$resDet = $pdo->query($reqDet);							
							?>
                            <table width="100%" class="table table-bordered table-hover" id="tb_adddevis">
                                <thead>
                                    <tr>
                                        <th align="center">#</th>
                                        <th align="left">Rub. 1</th>
                                        <th align="left">Rub. 2</th>
                                        <th align="left">D&eacute;signation</th>
                                        <th align="left">Qt&eacute;</th>
                                        <th align="left">Unit&eacute;</th>
                                        <th align="left">PU</th>
                                        <th align="center">&nbsp;</th>
                                        <th align="center">&nbsp;</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php 
								$i = 0;
								$temoin1 = "";
								$temoin2 = "";
								$mtLigne = 0;
								$MtTot = 0;
								$MtTotMo = 0;
								while($col = $resDet->fetch()){
								  $devdet_id 		 = $col['devdet_id'];
								  $devdet_devid 	 = $col['devdet_devid'];
								  $devdet_rub1		 = $col['devdet_rub1'];
								  $devdet_rub2 		 = $col['devdet_rub2'];
								  $devdet_materiel 	 = $col['devdet_materiel'];
								  $devdet_qte	     = $col['devdet_qte'];
								  $devdet_unite 	 = $col['devdet_unite'];
								  $devdet_prixunit 	 = $col['devdet_prixunit'];
								  $devdet_etat_enreg = $col['devdet_etat_enreg'];								  
									
									$mtLigne = $devdet_qte*$devdet_prixunit;
								  
									if($temoin1 != $devdet_rub1){
									  $temoin1 = $devdet_rub1;
									  $affRub1 = $temoin1;
									  $class1 = '';
									}else{
										$affRub1='&quot;';
										$class1 = 'align="center"';
									}
								  $temoin1 = $devdet_rub1;
								  
								  if($temoin2 != $devdet_rub2){
									  $temoin2 = $devdet_rub2;
									  $affRub2 = $temoin2;
									  $class2 = '';
									}else{
										$affRub2='&quot;';
										$class2 = 'align="center"';
									}
								  $temoin2 = $devdet_rub2;							  
								  
								  $i++;
								  ?>
                                    <tr id="<?php echo $devdet_id;?>" data-dev="<?php echo $IdDevis0; ?>" class="even gradeA success">
                                        <td align="center"><?php echo $i ?></td>
                                        <td <?php echo $class1; ?>><?php echo "<strong>".$affRub1."</strong>";?></td>
                                        <td <?php echo $class2; ?>><?php echo $affRub2 ?></td>
                                        <td><?php echo $devdet_materiel;?></td>
                                        <td align="center"><?php echo $devdet_qte; ?></td>
                                        <td align="center"><?php echo $devdet_unite; ?></td>
                                        <td align="right"><?php echo number_format($devdet_prixunit,0,'',' '); ?></td>
                                        <td align="center">                                        
                                        <button class="btn btn-link ButtonRetirer" data-toggle="tooltip" data-placement="top" data-tb="myDevisDetTb" title="Retirer <?php echo $devdet_materiel; ?>"><i class="fa fa-trash-o fa-lg text-rouge"></i></button>
                                        
                                        </td>
                                        <td align="center">
                                        <div data-toggle="tooltip" data-placement="top" title="Modifier <?php echo $devdet_materiel; ?>">
                                        <button class="btn btn-link modifButton" data-toggle="modal" data-backdrop="static"><i class="fa fa-pencil fa-lg"></i></button></div></td>
                                    </tr>
                                    <?php 
										$MtTot = $MtTot+$mtLigne;
								}
								$MtTotMo = $MtTot+$dev_moeuvre;
									?>
                                </tbody>
                                <tfoot>
                                    <tr id="totFoot">
                                        <th colspan="6" align="right">TOTAL HT</th>
                                        <th align="right"><?php echo number_format($MtTot,0,'',' '); ?></th>
                                        <th colspan="2" align="center">&nbsp;</th>
                                    </tr>
                                    <tr id="totMoFoot">
                                        <th colspan="6" align="right">TOTAL DEVIS HT (Main d'&oelig;uvre incluse)</th>
                                        <th align="right"><?php echo '<span class="text-rouge">'.number_format($MtTotMo,0,'',' ').'</span>'; ?></th>
                                        <th colspan="2" align="center">&nbsp;</th>
                                    </tr>
                                </tfoot>
                            </table>
                            <!-- /.table-responsive -->
                            <div class="row">
                       		 <form method="post" id="formEnregDetDev" action="put_devis.php">
                <div class="col-lg-4">&nbsp;
                </div>
                <div class="col-lg-4">
                  <div class="form-group">
                  <input type="hidden" class="form-control" name="devis" id="devis" value="<?php echo $IdDevis0; ?>">
                        <label>Main d'&oelig;uvre *</label>
                        <input type="number" class="form-control" placeholder="Saisissez le montant" name="mainoeuv" id="mainoeuv" required="required" value="<?php echo $dev_moeuvre; ?>">
                        <p class="help-block">0 pour les devis à &ldquo;Main d'&oelig;uvre int&eacute;gr&eacute;&rdquo;</p>
                    </div>
                </div>
                <div class="col-lg-4">
                <label>&nbsp;</label>
                  <button type="submit" name="ButtonEnregDevis" id="ButtonEnregDevis" class="btn btn-success btn-block"><i class="fa fa-save fa-lg"></i>&nbsp;&nbsp;Enregistrer la main d'&oelig;uvre et Terminer&nbsp;</button>
                  <p class="help-block">Cliquer pour enregistrer le devis</p>
                </div>
                </form>
                			</div>
                		</div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                
              </div>
          </div>
      </div>
  </div>
</div>


<!-- Modal -->
<div class="modal fade" id="ModalModifDetDevis" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">           
            <div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
<h4 class="modal-title" id="myModalLabel">Modifier</h4>
            </div>
<div class="row">
  <div class="col-lg-12">
      <div class="panelglobal panel-default-global">
          <form action="update_detail_devis.php" method="post" id="formModDetDevis">
          <div class="panel-body">
              <div class="row">              
                  <div class="col-lg-6">
                    <div class="form-group">
                    <label>Rubrique 1</label>
                        <input type="text" class="form-control" placeholder="Rubrique 1: Exple: Travaux RDC..." autofocus="autofocus" name="rub1" id="rub1" disabled="disabled">                        
                        </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="form-group">
                        <label>Rubrique 2</label>
                        <input type="text" class="form-control" placeholder="Rubrique 2: Exple: MACONNERIE" name="rub2" id="rub2" disabled="disabled" >
                        </div>
                  </div>
              </div>
              <div class="row">              
                  <div class="col-lg-6">
                    <div class="form-group">
                    <input type="hidden" name="IdDet" id="IdDet" value="">
                    <input type="hidden" name="IdDev" id="IdDev" value="">                   
                        <label>D&eacute;signation *</label>
                        <input type="text" class="form-control" placeholder="D&eacute;signation du mat&eacute;riel" name="materiel" id="materiel" required="required" >
                        </div>
                  </div>
                  <!-- /.col-lg-6 (nested) -->
                  <div class="col-lg-6">
                    <div class="form-group">
                    <label>Quantité *</label>
                    <input type="number" class="form-control" placeholder="Quantit&eacute;" name="qte" id="qte" required="required" >
                    </div>
                  </div>
                  
                  <div class="col-lg-6">
                    <div class="form-group">
                    <label>Unit&eacute;</label>
                       <input type="text" class="form-control" placeholder="L'unit&eacute;: Exple: U, Kg, m&sup3;, ..." name="unite" id="unite">
                     </div>
                  </div>
                  
                  <div class="col-lg-6">
                 	<div class="form-group">
                        <label>Prix Unitaire *</label>
                        <input type="text" class="form-control" placeholder="Prix Unitaire HT" name="prixu" id="prixu" >
                    </div>
                  </div>
              </div>
          </div>
          </form>
      </div>
  </div>
</div>
            </div>
            <div class="modal-footer">
                 <button name="submitFormModDetDevis" id="submitFormModDetDevis" type="button" class="btn btn-success"><i class="fa fa-save fa-lg"></i>&nbsp;&nbsp;Modifier</button>
 
 <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times fa-lg"></i>&nbsp;&nbsp;Fermer</button>
 
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->  
<?php 
}
?>