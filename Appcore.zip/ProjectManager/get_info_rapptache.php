<?php
session_start();
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php");
VerifTempsLog();

if(isset($_GET['id']) and isset($_GET['ch'])){
  $IdTache  = $_GET['id'];
  $IdChant  = $_GET['ch'];	
	$nl 	    = $_GET['nl'];
}

$chp = "C.cht_id, cht_libelle, cht_debut, cht_fin_prevu, cht_fin_eff, cht_etat, 
tch_id, tch_libelle, tch_debut, tch_fin_prevu, tch_fin_eff, tch_nature, tch_taux";
$tb = CHANTIERS." C LEFT JOIN ".TACHES." T ON C.cht_id=T.cht_id";
$cnd = "tch_id = $IdTache";
$req = selections($chp,$tb,$cnd,"tch_id");
$res = $pdo->query($req);	
$col = $res->fetch();
$cht_id 		= $col['cht_id'];
$cht_libelle 	= $col['cht_libelle'];
$cht_debut 		= $col['cht_debut'];
$cht_fin_prevu 	= $col['cht_fin_prevu'];
$cht_fin_eff 	= $col['cht_fin_eff'];
$cht_etat 		= $col['cht_etat'];
$tch_id 		= $col['tch_id'];
$tch_libelle 	= $col['tch_libelle'];
$tch_debut 		= $col['tch_debut'];
$tch_fin_prevu 	= $col['tch_fin_prevu'];
$tch_fin_eff 	= $col['tch_fin_eff'];
$tch_nature 	= $col['tch_nature'];
$tch_taux 		= $col['tch_taux'];

$nature = "";
if($tch_nature==1)$nature = '<span data-toggle="tooltip" data-placement="right" title="T&acirc;che suppl&eacute;mentaire"><i class="fa fa-plus text-bleu"></i></span>&nbsp;&nbsp;';

$LeJour = date('Y-m-d');
$TimeJour 	 = new DateTime($LeJour);
$timeFinPrev = new DateTime($tch_fin_prevu);
$timeFinEff  = new DateTime($tch_fin_eff);
$JourFinEff = $timeFinEff->format('d-m-Y');


$expire = "";
//Si delai expiré
if(($TimeJour>$timeFinPrev)==true){
	$expire = "Expir&eacute;";//Affiché "Expiré"
}
				
if($tch_taux<100){//Si taux <100 alors tache tjrs en cours
	$statut = '<span class="text-bleu">En cours ('.$tch_taux.'%)</span>'; 
}else{//tache terminé
	$statut = '<span class="text-vert">Termin&eacute;</span>';
	if($tch_fin_eff!=0){
	  $intervalEff = $timeFinPrev->diff($timeFinEff);
	  $NbreJourFinEff = $intervalEff->format('J%R%a');//Nbre entre la date fin effective et celle prevue
	  if(($timeFinEff>$timeFinPrev)==true){
		  $statut .='<span class="small text-rouge">&nbsp;&Agrave; '.$NbreJourFinEff.' ('.$JourFinEff.')</span>';
	  }else{
		  $statut .='<span class="small text-vert">&nbsp;&Agrave; '.$NbreJourFinEff.' ('.$JourFinEff.')</span>';
	  }
	}
}


?>
<div class="row">
  <div class="col-sm-12">
      <h4 class="rapp">CHANTIER: <span class="text-rouge"><?php echo $cht_libelle;?></span></h4>
  </div>
</div>
<div class="row page-header-st">
  <div class="col-sm-12">
      <div><h5>T&Acirc;CHE: <?php echo $nature; ?><span class="text-rouge"><?php echo $tch_libelle;?></span></h5></div>
  </div>
  <div class="col-sm-7">
      <h5>D&Eacute;LAI EXEC.: 
      <span class="text-bleu"><?php echo getdateC($tch_debut).' au '.getdateC($tch_fin_prevu);?></span>
      <?php if($expire!="")echo ' <span class="text-rouge">('.$expire.')</span>'; ?>
   </div>
   <div class="col-sm-5">
      <h5><div id="stattachemodal">&nbsp;&nbsp;Statut: <?php echo $statut; ?></div></h5>
   </div>
</div>

<div class="chat-panel panelglobal panel-default">
  <div class="panel-body">
      <ul class="chat" id="ulrapport">
      <?php 
	  $chpt = "rap_id, rap_taux, rap_libelle, rap_date_cre, user_nom, user_prenom ";
	  $tbt = "(".TACHES_RAPP." R LEFT JOIN ".TACHES." T ON R.rap_tache=T.tch_id)	  
	  		LEFT JOIN ".USERS." U ON R.rap_user_cre=U.user_id";
	  $cndt = "T.tch_id = $IdTache";
	  $reqt = selections($chpt,$tbt,$cndt,"rap_id DESC");//echo $reqt;
	  $rest = $pdo->query($reqt);	
	  while($colt = $rest->fetch()){
		  $rap_id 		= $colt['rap_id'];
		  $rap_taux 	= $colt['rap_taux'];
		  $rap_libelle 	= $colt['rap_libelle'];
		  $rap_date_cre = $colt['rap_date_cre'];
		  $user_nom 	= $colt['user_nom'];
		  $user_prenom 	= $colt['user_prenom'];
	  ?>
          <li class="right clearfix">
              <div class="chat-body clearfix">
                  <div class="header">
                      <strong class="text-datetache" data-toggle="tooltip" data-placement="top" title="Date d'&eacute;dition"><i class="fa fa-calendar fa-fw"></i> <?php echo getdateC($rap_date_cre); ?></strong>
                      &nbsp;&nbsp;|&nbsp;&nbsp;
                      <small class="text-muted" data-toggle="tooltip" data-placement="top" title="Taux d'ex&eacute;cution &agrave; la date d'&eacute;dition"><?php echo $rap_taux.'%'; ?></small>
                      &nbsp;&nbsp;|&nbsp;&nbsp;
                      <small class="text-muted"><?php echo $user_prenom.' '.$user_nom; ?></small>
                  </div>
                  <p><?php echo nl2br(html_entity_decode($rap_libelle)); ?></p>
              </div>
          </li>
      <?php 
	  }
	  ?>  
      </ul>
  </div>
  <!-- /.panel-body -->
  <div class="panel-footer">
      <div class="row">
      <?php if($tch_taux<100){ ?>
      <form role="form" method="post" id="formAddRapport">              
        <div class="col-sm-8">
          <div class="form-group">
          <input type="hidden" name="numLigne" id="numLigne" value="<?php echo $nl; ?>">
          <input type="hidden" name="idTache" id="idTache" value="<?php echo $IdTache; ?>">
          <input type="hidden" name="idChant" id="idChant" value="<?php echo $IdChant; ?>">
            <textarea name="txtrapp" rows="1" required="required" class="form-control input-sm" id="txtrapp" placeholder="Saisir le rapport du jour..." autofocus="autofocus"></textarea>
          </div>
        </div>
        <div class="col-sm-3">
          <div class="form-group input-group">
              <input type="number" class="form-control input-sm" placeholder="Taux" name="txjr" id="txjr" required="required">
              <span class="input-group-addon">%</span>
          </div>
        </div>
        <div class="col-sm-1">
          <div class="form-group">
              <button type="button" class="btn btn-success btn-circle" id="ButtonAddRapport" data-toggle="tooltip" data-placement="top" title="Valider" data-action="put_rapp_tache.php">
              <i class="fa fa-send"></i>
              </button>
          </div>
        </div>
        </form>
        <?php 
	  }
		?>
    </div>
  </div>
  <!-- /.panel-footer -->
</div>