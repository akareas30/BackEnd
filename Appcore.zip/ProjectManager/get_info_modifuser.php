<?php
session_start();
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php");
VerifTempsLog(); 
if(isset($_GET['id'])){
  $iduser  = $_GET['id'];
  $chp = "user_id,user_nom,user_prenom,user_fonct,user_profil,user_mail,user_pass,user_pass_modif,user_pass_datemodif,DATE_FORMAT(user_date_cre, '%d/%m/%Y %H:%i:%s') AS date_cre";
  $req = selections($chp,USERS,"user_id=$iduser","user_id");
  $res = $pdo->query($req);
  $donnees = $res->fetch();
  echo json_encode($donnees);
  $pdo=null;
}
?>
