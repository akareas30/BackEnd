<?php 
session_start();
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php");
VerifTempsLog();

if(isset($_GET['id'])){
	$IdDmd0 = (int)$_GET['id'];
}
$chp = "dmd_id, dmd_ref, dmd_type, dmd_demandeur, dmd_motif, dmd_date_cre";
$reqDet = selections($chp,DEMANDES,"dmd_id=$IdDmd0","dmd_id DESC");
$resDet = $pdo->query($reqDet);	
$col = $resDet->fetch();
$dmd_id 		= $col['dmd_id'];
$dmd_ref 		= $col['dmd_ref'];
$dmd_type 		= $col['dmd_type'];
$dmd_demandeur 	= $col['dmd_demandeur'];
$dmd_motif 		= $col['dmd_motif'];
$dmd_date_cre 	= $col['dmd_date_cre'];
?>

<div class="row">
  <div class="col-sm-12">
      <h4 class="rapp">REF. DEMANDE: <span class="text-rouge"><?php echo $dmd_ref;?></span></h4>
  </div>
</div>
<div class="row page-header-st">
  <div class="col-sm-6">
      <div><h5>DEMANDEUR: <span class="text-rouge"><?php echo $dmd_demandeur;?></span></h5></div>
  </div>
  <div class="col-sm-6">
      <h5>MOTIF: 
      <span class="text-bleu"><?php echo $dmd_motif; ?>
   </div>
</div>
<?php  
	$chp = "dmddet_id, outilref_id, outilref_libelle,outilref_ref, outilref_descrip, dmddet_etat_enreg, dmddet_etat_traite";
	$tbl = DEMANDES_DET." LEFT JOIN ".OUTILS_REF." ON dmddet_outils=outilref_id";
	$cnd = "dmddet_dmdid=$IdDmd0 AND dmddet_etat_enreg=1 AND (dmddet_etat_acc=0 OR dmddet_etat_acc=1)";
	$reqDet = selections($chp,$tbl,$cnd,"dmddet_id DESC");
	$resDet = $pdo->query($reqDet);	
?>
<div class="row">
  <div class="col-sm-12">
        <table width="100%" class="table tableDetDevis table-bordered">
            <thead>
                 <tr>
                    <th width="26%" align="left" nowrap="nowrap">Outil demand&eacute;</th>
                    <th width="44%" align="left" nowrap="nowrap">Description</th>
                    <th width="30%" align="left" nowrap="nowrap">R&eacute;f&eacute;rence</th>
                </tr>
            </thead>
            <tbody>
                <?php 
				$i = 0;
				while($col = $resDet->fetch()){
				  $dmddet_id 		 	= $col['dmddet_id'];
				  $dmddet_outils 	 	= $col['outilref_id'];
				  $outil_libelle 	 	= $col['outilref_libelle'];
				  $outilref_ref			= $col['outilref_ref'];
				  $outilref_descrip		= $col['outilref_descrip'];
				  $dmddet_etat_enreg 	= $col['dmddet_etat_enreg'];
				  $dmddet_etat_traite	= $col['dmddet_etat_traite'];
								  
				  $i++;
							  
                ?>
                  <tr class="even gradeA" data-numligne="<?php echo $i; ?>">
                    <td><?php echo $outil_libelle; ?></td>
                    <td align="left"><?php echo $outilref_descrip; ?></td>
                      <td align="left"><?php echo $outilref_ref;?></td>
                  </tr>
                <?php 
                }
                ?>
            </tbody> 
    </table>
	</div>
</div>