<?php 
session_start();
require('inc/definitions.php');
require('inc/cnt.php'); 
require('inc/fonction.php');  
?>
<!DOCTYPE html>
<html lang="fr">

<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CRB - MODIFIER LE MOT DE PASSE</title>
	<link rel="shortcut icon" type="image/x-icon" href="img/crb.ico" />
    <link href="vendor/bootstrap/css/bootstrap.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
</head>

<body>
<?php 
if($_SESSION['AP_user_mdp_datemodif']!=0){
	$dateModiPwd = "le ".getdateC($_SESSION['AP_user_mdp_datemodif']);
}else{
	$dateModiPwd = "";
}
	$info = "Vous n'avez pas encore modifi&eacute; votre Mot de Passe d&eacute;puis sa cr&eacute;ation ou sa r&eacute;initialisation $dateModiPwd<br />";
	$aletre = "Il est fortement recommand&eacute; de proc&eacute;der &agrave; la modification de celui-ci";
?>
<div class="container">
   <div class="row">
        <div class="col-lg-6 col-lg-offset-3">
            <div class="login-panel-chgmdp panelchgmdp panel-default">
            <div>
            <img src="img/logo_crb_log.png" alt="AUTHENTIFICATION UTILISATEUR" width="350" height="103" border="0" /></div>
             
                 <div class="alert alert-success"><i class="fa fa-exclamation-triangle fa-lg"></i><br><?php echo $info,$aletre; ?></div>
           
                <div class="panel-heading">
                  <h3 class="panel-title text-center text-orange"><?php echo TITLE_MAJ_USER; ?></h3>
                </div>
                <div class="panel-body">
        <?php
	if(isset($_POST['modif'])){
		$mdp         = trim($_POST['mdp']);
		$mdpnew  	 = trim($_POST['mdpnew']);
		$mdpnewconf  = trim($_POST['mdpnewconf']);
	  if($mdp!="" and $mdpnew!="" and $mdpnewconf!=""){
		  if(md5($mdp)!=$_SESSION['AP_user_mdp']){?> 
              <div class="alert alert-warning alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <?php echo INFO_MDP_INCORRECT; ?></div><?php
		  }elseif($mdpnew!=$mdpnewconf){?>
              <div class="alert alert-warning alert-dismissable">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
              <?php echo INFO_MDP_NOCONFORM; ?></div><?php
		  }else{
			  $psswdcpt = md5($mdpnew);
			  $mods = "user_pass='$psswdcpt',user_pass_modif=1,user_pass_datemodif=NOW(),user_date_mod=NOW(),user_user_mod=".$_SESSION['AP_iduser'];	
			  update(USERS,$mods,"user_id=".$_SESSION['AP_iduser']);
			  Logout();
		  }		
	  }
	}
		if(isset($_POST['later'])){
			$_SESSION['AP_deconexion'] = 1;
			?><script language="javascript">document.location="index.php"</script><?php
		}
		?> 
        
                    <form role="form" method="post" id="userChgMdp">
                        <fieldset>
                            <div class="form-group">
                            <label>E-mail </label>
                            <input class="form-control" value="<?php echo $_SESSION['AP_user_mail']; ?>" disabled >
                            </div>
                            
                            <div class="form-group">
                            <label>Mot de passe *</label>
                            <input class="form-control" placeholder="Entrer votre Mot de passe actuel" type="password" name="mdp" id="mdp" autocomplete="off" autofocus >
                            </div>
                            
                            <div class="form-group">
                            <label>Nouveau Mot de passe *</label>
                            <input class="form-control" placeholder="Entrer votre Nouveau Mot de passe" type="password" name="mdpnew" id="mdpnew" autocomplete="off" >
                            </div>
                            
                            <div class="form-group">
                            <label>Confirmez nouveau Mot de passe *</label>
                            <input class="form-control" placeholder="Confirmez votre Nouveau Mot de passe" type="password" name="mdpnewconf" id="mdpnewconf" autocomplete="off" >
                            </div>
                            
                            <p class="help-block"><?php echo TXT_AVERT_CHP_OBLIGE; ?></p>  
                            
                            <div class="col-lg-6"><button name="modif" id="modif" type="submit" class="btn btn-sm btn-success btn-block">Modifier maintenant&nbsp;&nbsp; <i class="fa fa-thumbs-o-up fa-lg"></i></button></div>             
                            <div class="col-lg-6"><button name="later" id="later" type="submit" class="btn btn-sm btn-latermdp btn-block" onclick="Javascript:return confirm('Vous pouvez toujours modifier votre mot de passe une fois connect&eacute; dans le logiciel.\nCliquez sur OK pour continuer dans PROJECT MANAGER');" >Modifier plus tard&nbsp;&nbsp; <i class="fa fa-mail-forward fa-lg"></i></button></div>
                        </fieldset>
                    </form>
                    
                </div>
          </div>
        </div>
    </div>
</div>

    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>
    
    <!-- jQuery Validation -->
    <script src="vendor/jquery-validation/dist/jquery.validate.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="dist/js/sb-admin-2.js"></script>
    
    <script>
  		//$("#userChgMdp").validate();
	</script> 
    <script>
	  $(document).ready(function() {
		  $("#userChgMdp").validate({
			  rules: {
    		   "mdpnewconf": {
      		   	  equalTo: "#mdpnew"
   			  	}
		  	  }
		  });
	  });
    </script> 
    
</body>

</html>
