<?php
session_start();
ini_set('session.bug_compat_42', 0);
ini_set('session.bug_compat_warn', 0);
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php"); 
VerifTempsLog();

if(isset($_GET['id']) and isset($_GET['dev'])){
  $actid     = (int)$_GET['id'];
  $IdChant0  = (int)$_GET['dev'];
  if(!delete(CHANTIERS_EQP,"eq_id=$actid")===true){
	  $array = array($actid);
	  //echo json_encode($array);
  }

}



$chp = "eq_id, eq_hrnom, eq_hrcontact,act_libelle";
$tb = CHANTIERS_EQP." LEFT JOIN ".ACTIVITES." ON eq_idact=act_id"; 
$reqDet = selections($chp,$tb,"eq_idcht=$IdChant0","eq_id ASC");
$resDet = $pdo->query($reqDet);				
?>
<tbody>
<?php 
$i = 0;
while($col = $resDet->fetch()){
  $eq_id 		 = $col['eq_id'];
  $eq_hrnom 	 = $col['eq_hrnom'];
  $eq_hrcontact	 = $col['eq_hrcontact'];
  $act_libelle   = $col['act_libelle'];
  
  $i++;
  ?>
	<tr id="<?php echo $eq_id;?>" data-dev="<?php echo $IdChant0; ?>" class="even gradeA success">
		<td align="center"><?php echo $i ?></td>
		<td><?php echo $act_libelle ?></td>
		<td align="left"><?php echo $eq_hrnom; ?></td>
		<td align="center"><?php echo $eq_hrcontact; ?></td>
		<td align="center">                                        
		<button class="btn btn-link ButtonRetirer" data-toggle="tooltip" data-placement="top" title="Retirer Equipe <?php echo $act_libelle." (".$eq_hrnom.")"; ?>"><i class="fa fa-trash-o fa-lg text-rouge"></i></button>
		</td>
		<td align="center">
        <div data-toggle="tooltip" data-placement="top" title="Modifier Equipe <?php echo $act_libelle." (".$eq_hrnom.")"; ?>">
		<button class="btn btn-link modifButton" data-toggle="modal" data-backdrop="static"><i class="fa fa-pencil fa-lg"></i></button></div></td>
	</tr>
	<?php 
}
	?>
</tbody>
