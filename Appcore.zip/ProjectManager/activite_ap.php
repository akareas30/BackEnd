<?php if(isset($_GET['act']) and  $_GET['act']=="add"){ ?>
<div class="row">
  <div class="col-lg-12">
      <h3 class="page-header">ENREGISTRER UNE ACTIVITE</h3>
  </div>
  <div class="col-lg-12">
      <h4>SAISIR LES INFOS ACTIVITES</h4>
  </div>
  <!-- /.col-lg-12 -->
</div>

<div class="row">
  <div class="col-lg-6">
<?php 
if(isset($_POST['enreg'])){
	$nom    = strtoupper(trim(addslashes($_POST['nom'])));
	$descrip = strtoupper(trim(addslashes($_POST['descrip'])));

	if($nom==""){
		?><div class="alert alert-warning alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <?php echo TXT_AVERT_CHP_OBLIGE; ?></div><?php
	}else{	
	 $tb = ACTIVITES."(act_libelle, act_descrip, act_user_cre, act_date_cre)";
	 $val = "'$nom','$descrip',".$_SESSION['AP_iduser'].",NOW()";
	 if(!AjoutBD($tb,$val)===true){
		 ?><div class="alert alert-success alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <?php echo TXT_ALERT_SUCCES_ENREG; ?></div><?php
	 }else{
		 ?><div class="alert alert-danger alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <?php echo TXT_ALERT_ERROR_ENREG; ?></div><?php
	 }
	}
}
?>
  </div>
</div>
<!-- /.row -->
<div class="row">
  <div class="col-lg-12">
      <div class="panelglobal panel-default-global">
          <form role="form" action="" method="post" id="formCreActivite">
          <div class="panel-body">
              <div class="row">
                  <div class="col-lg-6">
                    <div class="form-group">
                        <label>D&eacute;signation *</label>
                        <input name="nom" id="nom" type="text" class="form-control" placeholder="La d&eacute;signation de l'activit&eacute;" autofocus="autofocus" required="required" value="<?php echo $nom; ?>">
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea name="descrip" id="descrip" class="form-control" rows="3" placeholder="La description de l'activit&eacute;"><?php echo $descrip; ?></textarea>
                    </div>
                  </div>
              </div>
              <div class="row">
              <div class="col-lg-4 center-block">
                  <button name="enreg" id="enreg" type="submit" class="btn btn-success btn-block"><i class="fa fa-save fa-lg"></i>&nbsp;&nbsp;Enregistrer</button>
                  <p class="help-block"><?php echo TXT_AVERT_CHP_OBLIGE; ?></p>
              </div>&nbsp;
              <div class="col-lg-4 center-block">
                  <a href="?yk=activite&amp;act=li" class="btn btn-danger btn-block"><i class="fa fa-undo fa-lg"></i>&nbsp;&nbsp;Annuler</a>
              </div>
              </div>
          </div>
          </form>
      </div>
  </div>
</div>
<?php 
}
?>


<?php if(isset($_GET['act']) and  $_GET['act']=="li"){?>
<div class="row">
  <div class="col-lg-12">
      <h3 class="page-header">LISTE DES ACTIVITES</h3>
  </div>
</div>
<!-- /.row -->
<?php
if (isset($_POST['rfind'])){
	 if($_POST['etat']!=""){
		$etat=trim($_POST['etat']); 
		$Rechwhere.= " AND act_etat=$etat"; 
   }
}
?>
<div class="row">
  <div class="col-lg-12">
      <div class="panelglobal panel-default-global">
          <div class="panel-body">
              <div class="row">
              <div class="col-lg-12">
                    <div class="panelrech panel-default">
                      <div class="panel-heading-rech">Zone de recherche</div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
              				<form role="form" method="post" id="rechClt">
                  <div class="col-lg-3">
                    <div class="form-group input-group">
                       <span class="input-group-addon">Etat</span>
                        <select name="etat" id="etat" class="form-control">
                     <option value="">-- Tout --</option>
                     <option value="1">ACTIF</option>
                     <option value="0">INACTIF</option>
                   </select>
                    </div>
                  </div>
                  <div class="col-lg-3">
                  <button type="submit" class="btn btn-primary btn-block" name="rfind" id="rfind">Rechercher&nbsp;&nbsp;<i class="glyphicon glyphicon-search"></i></button>
                  </div>
               </form>
               			</div>
                    </div>
               </div>
               <?php 
				  $chp = "act_id, act_libelle, act_descrip, act_user_cre, act_date_cre, act_etat";
				  $cnd = "1 $Rechwhere";
				  $req = selections($chp,ACTIVITES,$cnd,"act_id DESC");
				  $res = $pdo->query($req);
			   ?>
               <div class="col-lg-12">
                             <table width="100%" class="table table-bordered table-hover" data-page-length='10' id="tb_listestand" >
                                <thead>
                                    <tr>
                                        <th align="center">#</th>
                                        <th align="left">Activit&eacute;</th>
                                        <th align="left">Description</th>
                                        <th align="center">Etat</th>
                                        <th align="center">Modif.</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php 
								$i=0;
								while($col = $res->fetch()){
									$act_id 			= $col['act_id'];
									$act_libelle 		= $col['act_libelle'];
									$act_descrip	 	= $col['act_descrip'];
									$act_user_cre 		= $col['act_user_cre'];
									$act_date_cre 		= $col['act_date_cre'];
									$act_etat 	 		= $col['act_etat'];
									$i++;
									if($clt_type==0)$typeClt="PARTICULIER"; else $typeClt="SOCI&Eacute;T&Eacute;";
								?>
                                    <tr class="even gradeA success">
                                        <td align="center"><?php echo $i;?></td>
                                        <td><?php echo "<strong>".$act_libelle."</strong>";if(!empty($act_date_cre))echo "<br /><span class=small><em>Ajout&eacute; le ".getdateL($act_date_cre)."</em></span>";?></td>
                                        <td><?php echo $act_descrip; ?></td>
                                        <td align="center" class="center">
                                        <?php 
										if($act_etat == 1){?>											
										<button class="btn btn-link ButtonActiver" value="1" data-id="<?php echo $act_id;?>" data-toggle="tooltip" data-placement="top" data-tb="myActiviteTb" title="Actif: Cliquez pour D&eacute;sactiver"><i class="fa fa-check-circle fa-lg text-vert"></i></button>
                                        <button class="btn btn-link ButtonDesactiver" value="0" data-id="<?php echo $act_id;?>" data-toggle="tooltip" data-placement="top" data-tb="myActiviteTb" title="Inactif: Cliquez pour Activer" style="display:none;"><i class="fa fa-minus-circle fa-lg text-jaune"></i></button><?php 
										}else {?>
										<button data-tb="myActiviteTb" class="btn btn-link ButtonActiver" value="1" data-id="<?php echo $act_id;?>" data-toggle="tooltip" data-placement="top" title="Actif: Cliquez pour D&eacute;sactiver" style="display:none;"><i class="fa fa-check-circle fa-lg text-vert"></i></button>
                                        <button data-tb="myActiviteTb" class="btn btn-link ButtonDesactiver" value="0" data-id="<?php echo $act_id;?>" data-toggle="tooltip" data-placement="top" title="Inactif: Cliquez pour Activer"><i class="fa fa-minus-circle fa-lg text-jaune"></i></button> <?php 
										}?>
                                        </td>
                                     <td align="center" class="center">
                                 <div data-toggle="tooltip" data-placement="top"  title="Modifier <?php echo $act_libelle; ?>">                                <button class="btn btn-link editActivite" data-id="<?php echo $act_id;?>" data-toggle="modal" data-backdrop="static"><i class="fa fa-pencil fa-lg"></i></button></div>
                                      </td>
                                    </tr>
									<?php 
								}
									?>
                                </tbody>
                            </table>
                        <!--</div>
                    </div>-->
                </div>
              </div>
          </div>
      </div>
  </div>
</div>
<!-- Modal -->
<div class="modal fade" id="ModalModifAct" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">           
            <div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
<h4 class="modal-title" id="myModalLabel">Modifier</h4>
            </div>
<div class="row">
  <div class="col-lg-12">
      <div class="panelglobal panel-default-global">
          <form action="update_info_act.php" method="POST" id="formModAct">
          <div class="panel-body">
              <div class="row">
                  <div class="col-lg-6">
                    <div class="form-group">
                    	<input name="id" id="id" type="hidden" value="" />
                    	<input name="dateadd" id="dateadd" type="hidden" value="" />
                        <label>D&eacute;signation *</label>
                        <input name="nom" id="nom" type="text" class="form-control" placeholder="La d&eacute;signation de l'activit&eacute;" autofocus="autofocus" required="required" value="">
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea name="descrip" id="descrip" class="form-control" rows="3" placeholder="La description de l'activit&eacute;"></textarea>
                    </div>
                  </div>
              </div>
          </div>
          </form>
      </div>
  </div>
</div>
            </div>
            <div class="modal-footer">
                 <button name="submitAct" id="submitAct" type="button" class="btn btn-success"><i class="fa fa-save fa-lg"></i>&nbsp;&nbsp;Modifier</button>
 
 <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times fa-lg"></i>&nbsp;&nbsp;Fermer</button>
 
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->   
<?php 
}
?>