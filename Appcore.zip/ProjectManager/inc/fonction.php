<?php
include("definitions.php");	
function AjoutBD($table,$values){
	include("cnt.php");	
	$req = "INSERT INTO ".$table." VALUES(".$values.")";//echo "<br />".$req;
	if($pdo->exec($req)===true){return true;
	}else{return false;
	}
}


function AjoutBDGetId($table,$values){
	include("cnt.php");	
	$req = "INSERT INTO ".$table." VALUES(".$values.")";//echo $req;
	$res = $pdo->exec($req);
	$id =  $pdo->lastInsertId();
	return $id;	
}


function update($table,$mods,$where){
	include("cnt.php");
	$req = "UPDATE ".$table." SET ".$mods." WHERE ".$where;//echo $req."<br />";
	if($pdo->exec($req)===true){return true;
	}else{return false;
	}
}

function delete($table,$where){
	include("cnt.php");
	$req = "DELETE FROM ".$table." WHERE ".$where;
	if($pdo->exec($req)===true){return true;
	}else{return false;
	}
}

function selections($champs,$table,$where,$tri){
	$req = "SELECT ".$champs." FROM ".$table." WHERE ".$where." ORDER BY ".$tri;//echo $req;
	return $req;
}

function deroulant($champs,$table,$where,$tri,$select){
	include("cnt.php");
	$req = selections($champs,$table,$where,$tri);
	$res = $pdo->query($req);
		while($ligne = $res->fetch()){
			$id = $ligne[0];
			$libelle1 = stripslashes($ligne[1]);
			$libelle2 = stripslashes($ligne[2]);
			if($libelle2!="")$libelle = $libelle1." - ".$libelle2;
			else $libelle = $libelle1;
			?>
		<option <?php if($select==$id){?> selected <?php }?>  value="<?php echo $id;?>"><?php echo $libelle;?></option>
	  <?php	
	  }	
}

function profilUser($select){
	include("cnt.php");
	$req = selections("prof_code,prof_name",PROFIL,1,"prof_name ASC");
	$res = $pdo->query($req);
		while($ligne = $res->fetch()){
			$prof_code = stripslashes($ligne[0]);
			$prof_name = stripslashes($ligne[1]);
			?>
		<option <?php if($select==$prof_code){?> selected <?php }?>  value="<?php echo $prof_code;?>"><?php echo $prof_name;?></option>
	  <?php	
	  }	
}

function getMdpAlea($nbr) {
  /*
  chr(rand(0, 25)+97); // for [a-z]
  chr(rand(0, 25)+65); // for [A-Z]
  chr(rand(0, 9)+48); // for [0-9]
  */
  $str = "";
  $ascii = array(48, 65, 97);
  for($i=0; $i<$nbr; $i++){
	$tbl = $ascii[rand(0,2)];
	$str .= ($tbl != 48) ? chr(rand(0, 25)+$tbl) : chr(rand(0, 9)+$tbl);
  }
  return $str;
}

function getCodeClt($typeclt){
	if($typeclt==0)$Typ="PART"; else $Typ="SOC";
	
}

function getRefDevis(){
	include("cnt.php");
	$req = selections("COUNT(dev_id)",DEVIS,1,"dev_id");
	$NbreDevis = $pdo->query($req)->fetchColumn();
	$NbreDevis+=1;
	while(mb_strlen($NbreDevis)<5){
		$NbreDevis = "0".$NbreDevis;
	}
	$ref = "DT/".$NbreDevis."/".date("d")."/".date("m")."/".date("Y");
	return $ref;
}

function getRefDmd($type){
	include("cnt.php");
	$req = selections("COUNT(dmd_id)",DEMANDES,1,"dmd_id");
	$NbreDmd = $pdo->query($req)->fetchColumn();
	$NbreDmd+=1;
	while(mb_strlen($NbreDmd)<5){
		$NbreDmd = "0".$NbreDmd;
	}
	if($type==0)$dm = "DA/LOC/";
	if($type==1)$dm = "DA/MAT/";
	$ref = $dm.$NbreDmd."/".date("d")."/".date("m")."/".date("Y");
	return $ref;
}


function getRefTacheEncours($chantier){
	include("cnt.php");
	$tb = CHANTIERS." C LEFT JOIN ".TACHES." T ON C.cht_id=T.cht_id";
	$cd = "T.cht_id = $chantier AND T.tch_taux<100";
	$req = selections("COUNT(T.tch_id)",$tb,$cd,1);
	$NbreTacheEncours = $pdo->query($req)->fetchColumn();
	return $NbreTacheEncours;
}

function checkDateTache($chantier,$debut,$fin){
	include("cnt.php");
	$req = selections("cht_debut, cht_fin_prevu",CHANTIERS,"cht_id=$chantier",1);
	$res = $pdo->query($req);
	$lim = $res->fetch();
	$debutChant = $lim[0];
	$finChant = $lim[1];
	if($debut<$debutChant or $debut>$finChant){
		return 10;
	}elseif($fin<$debutChant or $fin>$finChant){
		return 11;
	}else return 1;
}

function enregDevis($idDevis,$mOeuvre){
	$modDev = "dev_moeuvre=$mOeuvre";
	if(!update(DEVIS,$modDev,"dev_id=$idDevis")===true){
		return true;
	}
}

function getMontantDevis($idDevis){
	$modDet = "devdet_etat_enreg=1";
	$modDev = "dev_etat_enreg=1,dev_moeuvre=$mOeuvre";
	if( (!update(DEVIS_DET,$modDet,"devdet_devid=$idDevis AND devdet_etat_enreg=0")===true) and (!update(DEVIS,$modDev,"dev_id=$idDevis")===true) ){
		return true;
	}
}

function dateLFrToEnDeb($date){
	if($date!=0){
	  $newTime = new DateTime($date);
	  $newTime->setTime(0,0,0);
	  return $newTime->format('Y-m-d H:i:s');
	}	
}

function dateLFrToEnFin($date){
	if($date!=0){
	  $newTime = new DateTime($date);
	  $newTime->setTime(23,59,59);
	  return $newTime->format('Y-m-d H:i:s');
	}
}

function dateCFrToEn($date){
	if($date!=0){
	  $newTime = new DateTime($date);
	  return $newTime->format('Y-m-d');
	}	
}

function getdateL($date){
	if($date!=0){
	  $newTime = new DateTime($date);
	  return $newTime->format('d-m-Y H:i');
	}
}

function getdateC($date){
	if($date!=0){
	  $newTime = new DateTime($date);
	  return $newTime->format('d-m-Y');
	}
}

function Logout(){
    $_SESSION['AP_deconexion']=0;	
		if(isset($_SESSION['AP_iduser'])){
			//deleteSM(LIVRAISONS,"liv_etatenreg=0 AND liv_usercre=".$_SESSION['AP_iduser']);
			//deleteSM(DISTRIBUES,"dist_etatenreg=0 AND dist_usercre=".$_SESSION['AP_iduser']);
			//deleteSM(CHANTIERS_QTIF,"qtif_etatenreg=0 AND qtif_usercre=".$_SESSION['AP_iduser']);
			//deleteSM(EQUIPES_NEW,"equip_actif=0 AND equip_usercre=".$_SESSION['AP_iduser']);
		}
	?><script language="javascript">document.location="log.php"</script><?php
    exit;	
}

function VerifTempsLog(){
	if(time()-$_SESSION['AP_last_access'] > SESSION_TIMEOUT) {
	   Logout();
	}else{
	   $_SESSION['AP_last_access'] = time();
	}
}

//-- Fonction pour r�cup�rer l'adresse IP
function RecupIp(){
    if( isset ( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ){
      $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    }
    elseif( isset ( $_SERVER['HTTP_CLIENT_IP'] ) ){
      $ip  = $_SERVER['HTTP_CLIENT_IP'];
    }else{
      $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

//-- Fonction pour r�cup�rer l'URL
function RecupURL(){
	if(isset($_SERVER['HTTPS'])){
		if ($_SERVER['HTTPS'] == 'on'){			
			$prot = "https";		
		}else{		
			$prot = "http";
		}		
	}else{
		$prot = "http";
	}	
	$url = $prot."://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
	return $url;
}
?>