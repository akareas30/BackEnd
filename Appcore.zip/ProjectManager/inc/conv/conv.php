<?php

include('class_conv.php');

$MonNbre = "100500000";

$obj = new nuts($MonNbre,"CFA");
$text = $obj->convert("fr-FR");
$nb = $obj->getFormated(" ", ",");

echo $nb;
echo "<br />$text";
?>