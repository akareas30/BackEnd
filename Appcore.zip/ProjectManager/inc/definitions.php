<?php
define('SESSION_TIMEOUT',1200);//Dur�e d'inactivit�
define("TVA", 0.18);

define("ACTIVITES", "tb_activites");
define("CHANTIERS", "tb_chantiers");
define("CHANTIERS_EQP", "tb_chantiers_eqp");
define("TACHES_RAPP", "tb_chantiers_taches_rapp");
define("TACHES", "tb_chantiers_taches");
define("CLIENTS", "tb_clients");
define("COMMENTAIRES", "tb_commentaires");
define("CONTRACTUELS", "tb_contractuels");
define("DEMANDES", "tb_demandes");
define("DEMANDES_DET", "tb_demandes_det");
define("DEMANDES_DET_APPROUV", "tb_demandes_det_approuv");
define("DEVIS", "tb_devis");
define("DEVIS_DET", "tb_devis_det");
define("INTERV_CONTRACT", "tb_interv_contract");
define("OUTILS", "tb_outils");
define("OUTILS_REF", "tb_outils_ref");
define("USERS", "tb_users");
define("PROFIL", "tb_profil");
define("VT_DET_OUTIL", "vt_det_outil");
define("VT_DEVCHANT", "vt_devis_chantier");
define("VT_DETDMD_APPROUV", "vt_detdmd_approuv");
define("VT_DMD_COURANTES", "vt_dmd_courantes");

define("DTB", "crbapp");
define("ONZE", "root");
  
define("INFO_CPTE_INACTIF", "Votre compte n'est pas actif, veuillez contacter l'administrateur !");
define("INFO_CPTE_INCORRECT", "Votre nom d'utilisateur ou votre mot de passe est incorrect !");

define("INFO_MDP_INCORRECT", "Le mot de passe actuel n'est pas correct");
define("INFO_MDP_NOCONFORM", "Les deux mots de passe ne sont pas conformes !");

define("TXT_MDP_OUBLIE", "Mot de passe oubli&eacute; ?");
define("TITLE_CNX_USER", "Authentification utilisateur");
define("TITLE_MAJ_USER", "Mise &agrave; jour du mot de passe");

define("TXT_AVERT_CHP_OBLIGE", "Les champs dont le libell&eacute; est suivi de * sont obligatoires");

define("TXT_ALERT_SUCCES_ENREG", "Enregistrement effectu&eacute; avec succ&egrave;s");
define("TXT_ALERT_SUCCES_MODIF", "Modification effectu&eacute;e avec succ&egrave;s");
define("TXT_ALERT_ERROR_ENREG", "Une erreur est survenue lors de l'enregistrement");
define("TXT_ALERT_ERROR_MODIF", "Une erreur est survenue lors de la modification");

define("TXT_ALERT_ERROR_MDP_ACTU", "Le mot de passe actuel fourni n'est pas correct");
define("TXT_ALERT_ERROR_MDF_CONFIRM", "Les deux mots de passe ne sont pas conformes");
  

$entete = "From: CRB-PROJECT MANAGER <no-reply@appcore.com>\n";
//$entete .= "Reply-To: CRB - APPCORE <apptest.mail.2018@gmail.com>\n";
$entete .= "MIME-version: 1.0\n";
$entete .= "Content-type: text/html; charset=utf-8\n";
define("EXPMAIL",$entete);

?>