<?php 
try{
  $connStr = 'mysql:host=localhost;dbname=cmcsci_appcore';
  $arrExtraParam = array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8");
  $pdo = new PDO($connStr, 'cmcsci_angegnahoue', '@k@re25021989', $arrExtraParam);
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}catch(PDOException $e){
  $msg = 'ERREUR PDO dans ' . $e->getFile() . '<br />Ligne ' . $e->getLine() . ' : ' . $e->getMessage();
  //die($msg);
}
?>