<?php 
if($_SESSION['AP_user_profil']=="AD" || $_SESSION['AP_user_profil']=="DG" || $_SESSION['AP_user_profil']=="DT" || $_SESSION['AP_user_profil']=="CC"){
	
if(isset($_GET['cht'])){
	$IdChant0 = (int)$_GET['cht'];
}
$chp = "D.cht_libelle, D.cht_debut, D.cht_fin_prevu, cht_etat";
$tb = CHANTIERS." D";
$cnd = "cht_id=$IdChant0";

$reqLib = selections($chp,$tb,$cnd,1);
$res = $pdo->query($reqLib);
$col = $res->fetch();
$cht_libelle 	= $col['cht_libelle'];
$cht_debut 		= $col['cht_debut'];
$cht_fin_prevu 	= $col['cht_fin_prevu'];
$cht_etat 		= $col['cht_etat'];

?>
<div class="row">
  <div class="col-lg-12">
      <h3 class="page-header">GESTION DE CHANTIERS</h3>
  </div>
  <div class="col-lg-8">
      <h4>PLANNING DU CHANTIER: <?php echo '<span class="text-rouge">'.stripslashes($cht_libelle).'</span>';?></h4>
  </div>
  
  <div class="col-lg-4">
      <h5>PERIODE EXEC.: <?php echo '<span class="text-rouge">Du '.getdateC($cht_debut).' au '.getdateC($cht_fin_prevu).'</span>';?></h5>
  </div>
  
  <!-- /.col-lg-12 -->
</div>
<!-- /.row -->

<div class="row">
 <div class="col-lg-12">
  <div class="panel panel-default">
      <div class="panel-heading">LA LISTE DES T&Acirc;CHES</div>
      <!-- /.panel-heading -->
      <div class="panel-body">
          <?php 
          $chp = "tch_id, tch_libelle, tch_debut, tch_fin_prevu, tch_fin_eff, dev_ref, tch_nature, tch_taux, dev_objet";	  
          $tb = TACHES." LEFT JOIN ".DEVIS." ON tch_devis=dev_id"; 
          $reqDet = selections($chp,$tb,"cht_id=$IdChant0","tch_id ASC");
          $resDet = $pdo->query($reqDet);							
          ?>
          <table width="100%" class="table table-bordered table-hover" id="tb_plann">
              <thead>
                  <tr>
                      <th align="center">#</th>
                      <th align="left">T&acirc;ches Chantier</th>
                      <th align="center">D&eacute;lai</th>
                      <th align="center">Taux r&eacute;alisat.</th>
                      <th align="center">Statut</th>
                      <th align="center">Rapport</th>
                  </tr>
              </thead>
              <tbody>
              <?php 
              $i = 0;
              while($col = $resDet->fetch()){
                $tch_id 		 = $col['tch_id'];
                $tch_libelle 	 = $col['tch_libelle'];
                $tch_debut	 	 = $col['tch_debut'];
                $tch_fin_prevu   = $col['tch_fin_prevu'];
				$tch_fin_eff   	 = $col['tch_fin_eff'];
				$tch_nature 	 = $col['tch_nature'];
                $tch_taux 	     = $col['tch_taux'];
                $dev_ref 	 	 = $col['dev_ref'];
                $dev_objet 	     = $col['dev_objet'];
				
				//$tch_fin_eff = "2017-12-24";
				//$tch_taux = 80;
				$nature = "";
				if($tch_nature==1)$nature = '&nbsp;&nbsp;<span data-toggle="tooltip" data-placement="right" title="T&acirc;che suppl&eacute;mentaire" class="text-bleu"><i class="fa fa-plus"></i></span>';
				
				$LeJour = date('Y-m-d');
				$TimeJour 	 = new DateTime($LeJour);
				$timeFinPrev = new DateTime($tch_fin_prevu);
				$timeFinEff  = new DateTime($tch_fin_eff);
				
				$JourFinEff = $timeFinEff->format('d-m-Y');
				
				if($tch_taux<100){//Si taux <100 alors tache tjrs en cours
					$statut = '<span class="text-bleu"><i class="fa fa-pencil-square-o"></i>&nbsp;En cours</span>'; 
				}else{//tache terminé
					$statut = '<span class="text-vert"><i class="fa fa-check-square-o"></i>&nbsp;Termin&eacute;</span>';
					if($tch_fin_eff!=0){
						$intervalEff = $timeFinPrev->diff($timeFinEff);
						$NbreJourFinEff = $intervalEff->format('J%R%a');//Nbre entre la date fin effective et celle prevue
						if(($timeFinEff>$timeFinPrev)==true){
							$statut .='<br /><span class="small text-rouge">&nbsp;&Agrave; '.$NbreJourFinEff.' ('.$JourFinEff.')</span>';
						}else{
							$statut .='<br /><span class="small text-vert">&nbsp;&Agrave; '.$NbreJourFinEff.' ('.$JourFinEff.')</span>';
						}
					}
				}
				
				if($tch_taux>=0 and $tch_taux<=50){
					$colorTx = "text-rouge";
				}elseif($tch_taux>50 and $tch_taux<=90){
					$colorTx = "text-jaune";
				}elseif($tch_taux>90 and $tch_taux<100){
					$colorTx = "text-orange";
				}elseif($tch_taux==100){
					$colorTx = "text-vert";
				}
				
				$expire = "";
				$colorExpire = "";
				//Si delai expiré
				if(($TimeJour>$timeFinPrev)==true){
					$expire = "Expir&eacute;";//Affiché "Expiré"
					$colorExpire = "text-rouge";//et le mettre en rouge
					$colorJ = "text-rouge";//Mettre en rouge la couleur du Jour J-
				}elseif(($TimeJour==$timeFinPrev)==true){
					$colorJ = "text-rouge";//Si on est au Jour J;
				}elseif(($TimeJour>$timeFinPrev)==false){
					$colorJ = "text-vert";//Sil le delai n'a pas expiré, mettre en vert la couleur du Jour J-
				}
				//Nbre de d'ici à la date fin prévu
				$interval = $timeFinPrev->diff($TimeJour);
				$NbreJourJ = $interval->format('J%R%a');
				
                $i++;
                ?>
                  <tr class="even gradeA success" data-id="<?php echo $tch_id;?>" data-ch="<?php echo $IdChant0; ?>" data-numligne="<?php echo $i ?>">
                      <td align="center"><?php echo $i ?></td>
                      <td><?php echo "<strong>".$tch_libelle.$nature.'</strong><br /><span class="small">'.$dev_objet.'<span />'; ?>
                      </td>
                      <td align="center">
					  <?php echo getdateC($tch_debut).' - '.getdateC($tch_fin_prevu); 
                      if($expire!="")echo '<br /><span class="small '.$colorExpire.'">'.$expire.'</span>';?>
                      </td>
                      <td align="center">
					  <?php echo '<span class="'.$colorTx.'">'.$tch_taux.'%</span>';
					  if($tch_taux<100)echo '<span class="small '.$colorJ.'">&nbsp;('.$NbreJourJ.')</span>';?>
                      </td>
                      <td align="center"><?php echo $statut;?></td>
                      <td align="center">
                      <div data-toggle="tooltip" data-placement="top" title="Rapport d'ex&eacute;cution de la t&acirc;che">
                      <button class="btn btn-link RapportTacheButton" data-title="<?php echo $tch_libelle; ?>" data-toggle="modal" data-backdrop="static"><i class="glyphicon glyphicon-edit"></i></button></div>
                      </td>
                  </tr>
                  <?php 
              }
                  ?>
              </tbody>
          </table>
          <!-- /.table-responsive -->

        <div class="row">
          <div class="col-lg-4 pull-right">
          <a href="?yk=chantiergest&act=add" class="btn btn-danger btn-block"><i class="fa fa-undo fa-lg"></i>&nbsp;&nbsp;Retour &agrave; la liste des chantiers</a>
          </div>
        </div>          
      </div>
      <!-- /.panel-body -->
  </div>
 </div>
</div>

<!-- Modal -->
<div class="modal fade" id="ModalRapportTache" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header rapp55">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    <h4 class="modal-title" id="myModalLabel">LE RAPPORT D'EX&Eacute;CUTION DE T&Acirc;CHE</h4>
</div>
<div class="modal-body rapp55">
    
</div>
<div class="modal-footer">
<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times fa-lg"></i>&nbsp;&nbsp;Fermer</button>
</div>
</div>
<!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>
<!-- /.modal -->
<?php 
}else{
?><script language="javascript">document.location="index.php"</script><?php 
}?>