<?php
session_start();
ini_set('session.bug_compat_42', 0);
ini_set('session.bug_compat_warn', 0);
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php"); 

if(isset($_GET['id']) and isset($_GET['etat']) and isset($_GET['tb'])){
  switch ($_GET['tb']) {
  case "myActiviteTb": 
	  $TbVal 	 = ACTIVITES;
	  $ChpId 	 = "act_id";
	  $ChpEtat 	 = "act_etat"; 
	  break;
	  
  case "myChtTb": 
	  $TbVal 	= CHANTIERS;
	  $ChpId 	= "cht_id";
	  $ChpEtat  = "cht_etat";  
	  break;
	  
  case "myCltTb": 
	  $TbVal 	= CLIENTS;
	  $ChpId 	= "clt_id";
	  $ChpEtat  = "clt_etat"; 
	  break;
	  
  case "myCommentTb": 
	  $TbVal    = COMMENTAIRES;
	  $ChpId 	= "com_id";
	  $ChpEtat  = "com_etat"; 
	  break;
	  
  case "myContractTb": 
	  $TbVal    = CONTRACTUELS;
	  $ChpId 	= "cont_id";
	  $ChpEtat  = "cont_etat"; 
	  break;
	  
  case "DEMANDES": 
	  $TbVal    = DEMANDES;
	  $ChpId 	= "dmd_id";
	  $ChpEtat  = "dmd_etat_enreg"; 
	  break;
	  
  case "myDevisTb": 
	  $TbVal    = DEVIS;
	  $ChpId 	= "dev_id";
	  $ChpEtat  = "dev_etat_enreg"; 
	  break;
	  
  case "myOutilTb": 
	  $TbVal    = OUTILS_REF;
	  $ChpId 	= "outilref_id";
	  $ChpEtat  = "outilref_etatenreg"; 
	  break;
	  
  case "myTacheTb": 
	  $TbVal    = TACHES;
	  $ChpId 	= "tch_id";
	  $ChpEtat  = "tch_etat"; 
	  break;
	  
  case "myUserTb": 
	  $TbVal    = USERS;
	  $ChpId 	= "user_id";
	  $ChpEtat  = "user_etat"; 
	  break;
  }

  $actid  = (int)$_GET['id'];
  $stat   = (int)$_GET['etat'];
  if($stat==1)$newstat=0; elseif($stat==0)$newstat=1;
  if(!update($TbVal,"$ChpEtat=$newstat","$ChpId=$actid")===true){
	  $array = array($actid,$newstat);
	  echo json_encode($array);
  }
 $pdo=null;
}
?>
