<?php
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php");
function SansAccent($chaine){
 $a = array('À', 'Á', 'Â', 'Ã', 'Ä', 'Å', 'Æ', 'Ç', 'È', 'É', 'Ê', 'Ë', 'Ì', 'Í', 'Î', 'Ï', 'Ð',
                'Ñ', 'Ò', 'Ó', 'Ô', 'Õ', 'Ö', 'Ø', 'Ù', 'Ú', 'Û', 'Ü', 'Ý', 'ß', 'à', 'á', 'â', 'ã',
                'ä', 'å', 'æ', 'ç', 'è', 'é', 'ê', 'ë', 'ì', 'í', 'î', 'ï', 'ñ', 'ò', 'ó', 'ô', 'õ',
                'ö', 'ø', 'ù', 'ú', 'û', 'ü', 'ý', 'ÿ', 'A', 'a', 'C', 'c',
                'D', 'd',
                'E', 'e', 'G', 'g', 'H', 'h', 'I', 'i',
                '?', 'J', 'j', 'K', 'k', 'L', 'l',
                'N', 'n', '?', 'O', 'o', 'Œ',
                'œ', 'R', 'r','S', 's', 'Š', 'š', 'T', 't',  
                'U', 'u', 'W', 'w', 'Y', 
                'y', 'Ÿ','Z', 'z', 'Ž', 'ž','ƒ');
                

 $b = array('A', 'A', 'A', 'A', 'A', 'A', 'AE', 'C', 'E', 'E', 'E', 'E', 'I', 'I', 'I', 'I', 'D',
                'N', 'O','O', 'O', 'O', 'O', 'O', 'U', 'U', 'U', 'U', 'Y', 'S', 'A', 'A', 'A', 'A',
                'A', 'A', 'AE', 'C','E', 'E', 'E', 'E', 'I', 'I', 'I', 'I', 'N', 'O', 'O', 'O', 'O',
                'O', 'O', 'U', 'U', 'U', 'U','Y', 'Y', 'A', 'A', 'C', 'C',
                'D', 'D',  
                'E', 'E', 'G', 'G','H', 'H', 'I', 'I', 
                '?', 'J', 'J', 'K','K', 'L', 'L', 
                'N', 'N','?', 'O', 'O', 'OE',
                'OE', 'R', 'R', 'S', 'S', 'S', 'S','T', 'T', 
                'U', 'U','W','W', 'Y',
                'Y', 'Y', 'Z', 'Z', 'Z', 'Z','F');
  return strtoupper(str_replace($a, $b, $chaine));
  //echo strtoupper(str_replace($a, $b, $chaine));
}
 
if(isset($_POST['imp'])){
  $fichier = $_FILES['monfichier']['name'];//echo $fichier;
  $csv = new SplFileObject('imp/'.$fichier, 'r');
  $csv->setFlags(SplFileObject::READ_CSV);
  $csv->setCsvControl(';', '"', '"');
  
  $i = 0;
  $cpte = 0;
  foreach($csv as $ligne){
	if($i!=0){
	  list($OUTIL,$DESCRIP,$CARACT,$MARQUE,$REF,$OBS) = $ligne;
	 // echo $OUTIL.' || '.$DESCRIP.' || '.$CARACT.' || '.$MARQUE.' || '.$REF.' || '.$OBS.'<br>';
	 
	  $REF    	= SansAccent($REF);
	  $MARQUE 	= SansAccent($MARQUE);
	  $DESCRIP 	= SansAccent($DESCRIP);
	  $OUTIL 	= SansAccent($OUTIL);
	  $CARACT 	= SansAccent($CARACT);
	  
	  $DESCRIP = str_replace('*','<br />',$DESCRIP);
	  $CARACT  = str_replace('*','<br />',$CARACT);
	  
	  $ref_ref    		= strtoupper(trim(addslashes($REF)));
	  $ref_marque 		= strtoupper(trim(addslashes($MARQUE)));
	  $ref_descrip 		= strtoupper(trim(addslashes($DESCRIP)));
	  $ref_designation 	= strtoupper(trim(addslashes($OUTIL)));
	  $ref_detail 		= strtoupper(trim(addslashes($CARACT)));
	  
	  //$tb = "tb_outils_ref2(outilref_libelle, outilref_ref, outilref_marque, outilref_descrip, outilref_detail, outilref_user_cre, outilref_date_cre)";
	  
	  $tb = OUTILS_REF."(outilref_libelle, outilref_ref, outilref_marque, outilref_descrip, outilref_detail, outilref_user_cre, outilref_date_cre)";
	  
	  $val = "'$ref_designation','$ref_ref','$ref_marque','$ref_descrip','$ref_detail',1,NOW()";
		   
	  if($ref_designation != '' && AjoutBD($tb,$val)){
		echo $i.') '.$val.'<br>';
		$cpte++;
	  }
	  
	}
	$i++;
  }
  echo '<br>'.$cpte.' LIGNES INSERES *************************************';
}
?><head>
	<meta charset="utf-8">
</head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
</head>
<form action="" method="post" enctype="multipart/form-data">
<table width="60%" border="0" align="center" cellpadding="1" cellspacing="1">
  <tr>
    <td align="right"><input name="monfichier" id="monfichier" type="file"></td>
    <td align="left"><input name="imp" id="imp" type="submit" value="Importer"></td>
  </tr>
</table>
</form>