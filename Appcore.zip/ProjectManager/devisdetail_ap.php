<?php 
if(isset($_GET['dev'])){
	$IdDevis0 = (int)$_GET['dev'];
}
$chp = "D.dev_ref, D.dev_objet, D.dev_date_cre, D.dev_moeuvre, C.clt_type, C.clt_nom, C.clt_abrege";
$tb = DEVIS." D LEFT JOIN ".CLIENTS." C ON D.dev_clt=C.clt_id";
$cnd = "dev_id=$IdDevis0";

$reqLib = selections($chp,$tb,$cnd,1);
$res = $pdo->query($reqLib);
$col = $res->fetch();
$dev_ref 	= $col['dev_ref'];
$dev_objet 	= $col['dev_objet'];
$clt_type 	= $col['clt_type'];
$clt_nom 	= $col['clt_nom'];
$clt_abrege = $col['clt_abrege'];
$dev_date_cre = $col['dev_date_cre'];
$dev_moeuvre = $col['dev_moeuvre'];
?>
<div class="row">
  <div class="col-lg-10">
      <h3>DEVIS REF.: <span class="text-rouge"><?php echo $dev_ref;?></span></h3>
  </div>
  
  <div class="col-lg-1">
      <h3 class="text-center"><a href="devisdetail_xls.php?dev=<?php echo $IdDevis0;?>"><i class="fa fa-file-excel-o fa-sm text-vert" data-toggle="tooltip" data-placement="top" title="Exporter vers Excel"></i></a></h3>
  </div>
  
  <div class="col-lg-1">
      <h3 class="text-center"><a href="devisdetail_doc.php?dev=<?php echo $IdDevis0;?>"><i class="fa fa-file-word-o fa-sm text-bleu" data-toggle="tooltip" data-placement="top" title="Exporter vers Word"></i></a></h3>
  </div>
  
</div>
<div class="row page-header-st">
  <div class="col-lg-4">
      <h4>CLIENT: <span class="text-rouge"><?php if($clt_abrege!="")echo $clt_abrege;else echo $clt_nom;?></span></h4>
  </div>
  <div class="col-lg-8">
      <h4>OBJET: <span class="text-rouge"><?php echo stripslashes($dev_objet);?></span></h4>
  </div>
</div>
<!-- /.row -->
<div class="row">
  <div class="col-lg-12">
	<?php 
    $cnd1 = "devdet_devid=$IdDevis0 AND devdet_etat_enreg=1 GROUP BY devdet_rub1";
    $reqRub1 = selections("devdet_rub1",DEVIS_DET,$cnd1,"devdet_id DESC, devdet_rub1 ASC");//echo $reqRub1;
    $resRub1 = $pdo->query($reqRub1);	
	$i1 = 0;
	$totRubDevis = 0;
	$TotGleHT = 0;
	while($col1 = $resRub1->fetch()){
		$devdet_rub1 = $col1['devdet_rub1'];
		$i1++;
		$cnd2 = "devdet_rub1='$devdet_rub1' AND devdet_etat_enreg=1 AND devdet_devid=$IdDevis0 GROUP BY devdet_rub2";
    	$reqRub2 = selections("devdet_rub2",DEVIS_DET,$cnd2,"devdet_id DESC, devdet_rub1 ASC");//echo $reqRub2;
    	$resRub2 = $pdo->query($reqRub2);			
		if($devdet_rub1!=""){?>
	<div class="col-lg-12">
		  <h4 class="text-bleu"><?php echo $i1.') '.$devdet_rub1; ?></h4>
		</div><?php
		}?>
        <table width="100%" class="table tableDetDevis table-bordered">
		<?php 
		$totRub = 0;
		while($col2 = $resRub2->fetch()){
        	$devdet_rub2 = $col2['devdet_rub2'];
		?>
            <thead>
            	<?php if($devdet_rub2!=""){?>
                <tr>
                    <td colspan="5" align="left"><?php echo $devdet_rub2; ?></td>
                </tr><?php
				}?>
                 <tr>
                    <th width="52%" align="left">D&eacute;signation</th>
                    <th width="8%" align="center">Qt&eacute;</th>
                    <th width="8%" align="center">Unit&eacute;</th>
                    <th width="14%" align="left">PU HT</th>
                    <th width="18%" align="left">MONTANT HT</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $cndDet = "devdet_rub1='$devdet_rub1' AND devdet_rub2='$devdet_rub2' AND devdet_devid=$IdDevis0 AND devdet_etat_enreg=1";
                $chpDet = "devdet_materiel, devdet_qte, devdet_unite, devdet_prixunit";
                $reqDet = selections($chpDet,DEVIS_DET,$cndDet,"devdet_id DESC, devdet_rub1 ASC");//echo $reqRub2;
                $resDet = $pdo->query($reqDet);
                $totDetHt = 0;
                while($colDet = $resDet->fetch()){
                  $devdet_materiel 	= $colDet['devdet_materiel'];
                  $devdet_qte 		= $colDet['devdet_qte'];
                  $devdet_unite 	= $colDet['devdet_unite'];
                  $devdet_prixunit 	= $colDet['devdet_prixunit'];
                  $totDetHt = $devdet_qte*$devdet_prixunit;
                ?>
                <tr class="even gradeA ">
                  <td><?php echo $devdet_materiel; ?></td>
                  <td align="center"><?php echo $devdet_qte; ?></td>
                    <td align="center"><?php echo $devdet_unite; ?></td>
                    <td align="right"><?php echo number_format($devdet_prixunit,0,'',' '); ?></td>
                    <td align="right"><?php echo number_format($totDetHt,0,'',' ');?></td>
                </tr>
                <?php 
                $totRub = $totDetHt+$totRub;
                }
                ?>
            </tbody> 
			<?php 
		}
		?>           
            <?php if($devdet_rub1!=""){?>
            <tfoot>
                 <tr>
                    <th colspan="4" align="right"><span class="text-vert">MONTANT <?php echo $devdet_rub1; ?></span> </th>
                    <th width="18%" align="right"><span class="text-vert"><?php echo number_format($totRub,0,'',' '); ?></span></th>
                </tr>
            </tfoot>
            <?php 
			}
			?>
        </table>
		<?php
		$totRubDevis = $totRub+$totRubDevis;
}

	$TotGleHT = $totRubDevis+$dev_moeuvre;
?> 
<div class="row">
  <div class="col-lg-12">&nbsp;</div>
</div>
<table width="100%" class="table borderbleu table-striped">
        <thead>
            <?php if($dev_moeuvre!=0){?>
            <tr>
               <th align="right">Main d'&oelig;uvre </th>
               <th width="18%" align="right"><?php echo  number_format($dev_moeuvre,0,'',' '); ?></th>
            </tr>
            <?php }?>
            <tr>
              <th align="right">Total HT</th>
              <th width="18%" align="right"><?php echo  number_format($TotGleHT,0,'',' '); ?></th>
            </tr>
            <tr>
              <th align="right">TVA 18%</th>
              <th align="right"><?php echo number_format(($TotGleHT*TVA),0,'',' '); ?></th>
            </tr>
            <tr>
              <th align="right">Total TTC</th>
              <th width="18%" align="right"><?php echo number_format($TotGleHT+($TotGleHT*TVA),0,'',' '); ?></th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table> 
	</div>
</div>
 <?php 
  if(!isset($_GET['ret'])){
  ?>
<div class="row">
<?php 
  if(isset($_POST['ButtonRetLiDevis'])){
   ?><script language="javascript">document.location="?yk=devisgest&act=add"</script><?php
  }
  ?>
  <form method="post" id="" action="">
  <div class="col-lg-4 pull-right">
    <button type="submit" name="ButtonRetLiDevis" id="ButtonRetLiDevis" class="btn btn-warning btn-block"><i class="fa  fa-reply fa-sm"></i>&nbsp;&nbsp;Revenir &agrave; la liste des devis&nbsp;</button>
  </div>
  </form>
</div>
<div class="row">
  <div class="col-lg-12">&nbsp;</div>
</div>
<?php 
  }
?>
