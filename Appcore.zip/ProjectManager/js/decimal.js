// JavaScript Document
function FormatDecimal(id){
	//var champ = document.getElementById(id);
	//var texte = champ.value;
	var texte = id.value;
	var n = texte.length;
	var i;
	var car;
	var point = 0;
	var retour = "";
	for(i=0 ; i<n ; i++){
		car = texte.substring(i,i+1);
		nb = parseInt(car);
		// Point ou virgule
		if(car == "," || car == "."){
			// Pas de point en 1er caractère
			if(i != 0 && point == 0){
				retour += ".";
				point = 1;
			}
		}else if(Number.isInteger(nb) == true){
			if(point < 2) retour += texte.substring(i,i+1);
			// Si un point a déjà été mis, alors ce chiffre est une décimale
			//if(point == 1) point = 2; //Enlever le commentaire si on veut plus de nombre apres la virgule
		}
	}
	// Renvoi de la valeur
	id.value = retour;
}