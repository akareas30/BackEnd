$(document).ready(function () {
	$("#formModUser").on("submit", function(e) {
		var postData = $(this).serialize(); 
		var formURL = $(this).attr("action");
		$.ajax({
			url: formURL,
			type: 'POST',
			data: postData,
			dataType:"json",
			success: function(data) {
                var $button = $('button[data-id="' + data[0] + '"]'),
                    $tr     = $button.closest('tr'),
                    $cells  = $tr.find('td');
                // Update the cell data
                $cells
                    .eq(0).html('<strong>'+data[1]+' '+data[2]+'</strong><br /><span class=small><em>Ajout&eacute; le '+data[6]+'</em></span>').end()
                    .eq(1).html(data[3]).end()
                    .eq(2).html(data[4]+'<br />'+data[5]).end();
					
				alert('Modication effectuée avec succès');
				$('#ModalModifUser').modal('hide');
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});

		e.preventDefault();
	});
	 
	$("#submitForm").on('click', function() {
		var validator = $( "#formModUser" ).validate();
		if(validator.form()==true){
			$("#formModUser").submit();
		}
	});
	
	$('.editButton').on('click', function() {
        // Get the record's ID via attribute
        var id = $(this).attr('data-id');
		$.ajax({
			url: 'get_info_modifuser.php',
			type: 'GET',
			data: 'id='+id,
			dataType:"json",
			success: function(donnees) {
				$('#formModUser')      
                	.find('[id="id"]').val(donnees[0]).end()
                	.find('[id="nom"]').val(donnees[1]).end()
                	.find('[id="prenom"]').val(donnees[2]).end()
					.find('[id="fonct"]').val(donnees[3]).end()
					.find('[id="profil"]').val(donnees[4]).end()
					.find('[id="email"]').val(donnees[5]).end()
					.find('[id="dateadd"]').val(donnees[9]).end()
				 $('#ModalModifUser .modal-header .modal-title').html("MODIFIER "+donnees[1]+" "+donnees[2]);
				 $("#ModalModifUser").modal('show');
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
	});
	
	$("#formModClt").on("submit", function(e) {
		var postData = $(this).serialize(); 
		var formURL = $(this).attr("action");
		$.ajax({
			url: formURL,
			type: 'POST',
			data: postData,
			dataType:"json",
			success: function(data) {
				var idclt = data[0], typeclt = data[1],	nom = data[2],
					sigle = data[3], code = data[4], tel = data[5],
					email = data[6], ncc = data[7], adresse = data[8],
					interloc = data[9],	dateadd = data[10];
					
					if(typeclt==0) var LeType = "PARTICULIER";
					else var LeType = "SOCI&Eacute;T&Eacute;";
					
					if(tel!=''){ tel = '<i class="fa fa-phone"></i>&nbsp;'+tel; }
					if(email!=''){ email = '<br /><i class="fa fa-envelope-o"></i>&nbsp;'+email; }
					if(adresse!=''){ adresse = '<br /><i class="fa fa-location-arrow"></i>&nbsp;'+adresse; }
					//if(sigle!=''){ sigle = " ("+sigle+")"; }
					
					if(nom!=sigle){
						nom="<strong>"+nom+"</strong> ("+sigle+")";
					}else nom="<strong>"+nom+"</strong>";
					
					
				// Get the cells
                var $button = $('button[data-id="' + idclt + '"]'),
                    $tr     = $button.closest('tr'),
                    $cells  = $tr.find('td');
                // Update the cell data
                $cells
                    .eq(1).html(nom+'<br /><span class=small><em>Ajout&eacute; le '+dateadd+'</em></span>').end()
                    .eq(2).html(interloc).end()
                    .eq(3).html(LeType).end()
					.eq(4).html(tel+email+adresse).end();
					
				alert('Modication effectuée avec succès');
				$('#ModalModifClt').modal('hide');
                
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});

		e.preventDefault();
	});
	 
	$("#submitClt").on('click', function() {
		var validator = $( "#formModClt" ).validate();
		if(validator.form()==true){
			$("#formModClt").submit();
		}
	});
	
	$('.editClient').on('click', function() {
        // Get the record's ID via attribute
        var id = $(this).attr('data-id');
		$.ajax({
			url: 'get_info_modifclt.php',
			type: 'GET',
			data: 'id='+id,
			dataType:"json",
			success: function(donnees) {
				$('#formModClt')      
                	.find('[id="id"]').val(donnees[0]).end()
					.find('[id="dateadd"]').val(donnees[10]).end()
					.find('[id="nom"]').val(donnees[2]).end()
					.find('[id="typeclt"]').val(donnees[1]).end()
					.find('[id="sigle"]').val(donnees[3]).end()
					.find('[id="interloc"]').val(donnees[9]).end()
					.find('[id="email"]').val(donnees[6]).end()	
					.find('[id="tel"]').val(donnees[5]).end()
					.find('[id="adresse"]').val(donnees[8]).end()
					.find('[id="ncc"]').val(donnees[7]).end();
					
				 $('#ModalModifClt .modal-header .modal-title').html("MODIFIER LE CLIENT "+donnees[2]);
				 $("#ModalModifClt").modal('show');
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
	});

	$("#formModAct").on("submit", function(e) {
		var postData = $(this).serialize(); 
		var formURL = $(this).attr("action");
		$.ajax({
			url: formURL,
			type: 'POST',
			data: postData,
			dataType:"json",
			success: function(data) {
				var idact = data[0],
					nom = data[1],
					descrip = data[2],
					dateadd = data[3];
					
				// Get the cells
                var $button = $('button[data-id="' + idact + '"]'),
                    $tr     = $button.closest('tr'),
                    $cells  = $tr.find('td');
                // Update the cell data
                $cells
                    .eq(1).html('<strong>'+nom+'</strong><br /><span class=small><em>Ajout&eacute; le '+dateadd+'</em></span>').end()
                    .eq(2).html(descrip).end();					
					
				alert('Modication effectuée avec succès');
				$('#ModalModifAct').modal('hide');
                
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});

		e.preventDefault();
	});
	 
	$("#submitAct").on('click', function() {
		var validator = $( "#formModAct" ).validate();
		if(validator.form()==true){
			$("#formModAct").submit();
		}				
	});
	
	$('.editActivite').on('click', function() {
        // Get the record's ID via attribute
        var id = $(this).attr('data-id');
		$.ajax({
			url: 'get_info_modifactivite.php',
			type: 'GET',
			data: 'id='+id,
			dataType:"json",
			success: function(donnees) {
				$('#formModAct')      
                	.find('[id="id"]').val(donnees[0]).end()
					.find('[id="dateadd"]').val(donnees[4]).end()
					.find('[id="nom"]').val(donnees[1]).end()
					.find('[id="descrip"]').val(donnees[2]).end()
					
				 $('#ModalModifAct .modal-header .modal-title').html("MODIFIER L'ACTIVIT&Eacute; "+donnees[2]);
				 $("#ModalModifAct").modal('show');
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
	});
	
 	$('.ButtonActiver').on('click', function() {
        var id = $(this).attr('data-id');
		var etat = $(this).attr('value');
		var tb = $(this).attr('data-tb');
		$.ajax({
			url: 'chg_etatactif.php',
			type: 'GET',
			data : 'id='+id+'&etat='+etat+'&tb='+tb,
			dataType:"json",
			success: function(donnees) {
				var $buttonActive = $( '.ButtonActiver[data-id="' + donnees[0] + '"]' );
				var $buttonDesActive = $( '.ButtonDesactiver[data-id="' + donnees[0] + '"]' );
				$buttonActive.hide();
				$buttonDesActive.show();
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
		
	});
	
  	$('.ButtonDesactiver').on('click', function() {
        var id = $(this).attr('data-id');
		var etat = $(this).attr('value');
		var tb = $(this).attr('data-tb');
		$.ajax({
			url: 'chg_etatactif.php',
			type: 'GET',
			data : 'id='+id+'&etat='+etat+'&tb='+tb,
			dataType:"json",
			success: function(donnees) {
				var $buttonActive = $( '.ButtonActiver[data-id="' + donnees[0] + '"]' );
				var $buttonDesActive = $( '.ButtonDesactiver[data-id="' + donnees[0] + '"]' );
				$buttonActive.show();
				$buttonDesActive.hide();
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
		
	});

	$('.ButtonOuvrirDetOutil').on('click', function() {
        var id = $(this).attr('data-id');
		var titre = $(this).attr('data-title');
		
		$.ajax({
			url: 'get_info_detail_outil.php',
			type: 'GET',
			data: 'id='+id,
			dataType:"html",
			success: function(data, textStatus, jqXHR) {
				$('#ModalDetailOutil .modal-header .modal-title').html(titre);
                $('#ModalDetailOutil .modal-body').html(data);
				$("#ModalDetailOutil").modal('show');
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
	});
	
	$('.ButtonOuvrirEqp').on('click', function() {
        var id = $(this).attr('data-id');
		var titre = $(this).attr('data-title');
		
		$.ajax({
			url: 'get_listeEqp.php',
			type: 'GET',
			data: 'id='+id,
			dataType:"html",
			success: function(data, textStatus, jqXHR) {
				$('#modalOuvreEqp .modal-header .modal-title').html(titre);
                $('#modalOuvreEqp .modal-body').html(data);
				$("#modalOuvreEqp").modal('show');
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
	});
	
	$('#ButtonAddDetOutil').on('click', function(e) { 
		  var validator = $("#formAddDetOut").validate();
		  if(validator.form()==true){
		  var postData = $("#formAddDetOut").serialize(); 
		  var formURL = $(this).attr("data-action");
		  $.ajax({
			  url: formURL,
			  type: 'POST',
			  data: postData,
			  dataType:"html",
			  //success: function(data) {
			  success: function(data, textStatus, jqXHR) {				
				$("#tb_addoutil>tbody").prepend(data);
			  },
			  error: function(jqXHR, status, error) {
				  console.log(status + ": " + error);
			  }
		  });
  
		  e.preventDefault();
		}
 	});

	$('#ButtonAddDetDevis').on('click', function(e) { 
		  var validator = $("#formAddDetDevis").validate();
		  if(validator.form()==true){
		  var postData = $("#formAddDetDevis").serialize(); 
		  var formURL = $(this).attr("data-action");
		  $.ajax({
			  url: formURL,
			  type: 'POST',
			  data: postData,
			  dataType:"html",
			  //success: function(data) {
			  success: function(data, textStatus, jqXHR) {	
				$("#tb_adddevis>tfoot").remove();			
				$("#tb_adddevis>tbody").replaceWith(data);				
			  },
			  error: function(jqXHR, status, error) {
				  console.log(status + ": " + error);
			  }
		  });
  
		  e.preventDefault();
		}
	});
	
	$('#ButtonAddDetEqp').on('click', function(e) { 
		  var formAddDetEqp = $("#formAddDetEqp");
		  var validator = formAddDetEqp.validate();
		  if(validator.form()==true){ 
			  //alert (error);
			  var postData = formAddDetEqp.serialize();
			  var formURL = $(this).attr("data-action");
				$.ajax({
				  url: formURL,
				  type: 'POST',
				  data: postData,
				  dataType:"html",
				  //success: function(data) {
				  success: function(data, textStatus, jqXHR) {	
					$("#tb_addeqp>tbody").replaceWith(data);				
				  },
				  error: function(jqXHR, status, error) {
					  console.log(status + ": " + error);
				  }
			  });
			}
		e.preventDefault();
	  
	});
	
	$('#ButtonAddDetTache').on('click', function(e) { 
		  var formAddDetTache = $("#formAddDetTache");
		  var validator = formAddDetTache.validate();
		  if(validator.form()==true){ 
			var deb = $('#formAddDetTache input[id="datedeb"]').val();
			var fin = $('#formAddDetTache input[id="datefin"]').val();
			var debChant = $('#formAddDetTache input[id="datedebInit"]').val();
			var finChant = $('#formAddDetTache input[id="datefinInit"]').val();
			var error = 0;
			if(deb<debChant || deb>finChant){
			  error = 10;
			  alert ('La date début de la tâche ne peut être antérieure à celle du chantier ou postérieure à sa date de fin');
			}else if(fin<debChant || fin>finChant){
			  error = 11;
			  alert ('La date fin de la tâche ne peut être postérieure à celle du chantier ou antérieure à sa date de debut');
			}else{
				var postData = formAddDetTache.serialize();
				var formURL = $(this).attr("data-action");
				var tache = $(this).attr("data-tache");
				  $.ajax({
					url: formURL,
					type: 'POST',
					data: postData,
					dataType:"html",
					//success: function(data) {
					success: function(data, textStatus, jqXHR) {	
					  $("#tb_addtache>tbody").replaceWith(data);				
					},
					error: function(jqXHR, status, error) {
						console.log(status + ": " + error);
					}
				});
			  }
		  e.preventDefault();
		  }
	});
  
	$('.ButtonOuvrirDevisChant').on('click', function() {
        var id = $(this).attr('data-id');
		$.ajax({
			url: 'get_info_devischant.php',
			type: 'GET',
			data: 'dev='+id+'&ret=no',
			dataType:"html",
			success: function(data, textStatus, jqXHR) {
				$('#modalOuvrirDevisChant .modal-header').hide();
                $('#modalOuvrirDevisChant .modal-body').html(data);
				$("#modalOuvrirDevisChant").modal('show');
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
	});
	
	$('.ButtonOuvrirFicheChantier').on('click', function() {
        var id = $(this).attr('data-id');
		$.ajax({
			url: 'get_info_fiche_chantier.php',
			type: 'GET',
			data: 'cht='+id+'&ret=no',
			dataType:"html",
			success: function(data, textStatus, jqXHR) {
				/*$('#modalOuvrirFicheChantier .modal-header').hide();*/
                $('#modalOuvrirFicheChantier .modal-body').html(data);
				$("#modalOuvrirFicheChantier").modal('show');
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
	});
	
	$('.ButtonOuvrirFicheRapport').on('click', function() {
        var id = $(this).attr('data-id');
		$.ajax({
			url: 'get_info_fiche_rapport.php',
			type: 'GET',
			data: 'cht='+id+'&ret=no',
			dataType:"html",
			success: function(data, textStatus, jqXHR) {
				/*$('#modalOuvrirFicheChantier .modal-header').hide();*/
                $('#modalOuvrirFicheRapport .modal-body').html(data);
				$("#modalOuvrirFicheRapport").modal('show');
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
	});

	$('#ButtonAddDmdInt').on('click', function(e) { 
		  var validator = $("#formAddDetDmd").validate();
		  if(validator.form()==true){
			var postData = $("#formAddDetDmd").serialize(); 
			var formURL = $(this).attr("data-action");
			$.ajax({
				url: formURL,
				type: 'POST',
				data: postData,
				dataType:"html",
				success: function(data, textStatus, jqXHR) {
				  $("#tb_adddmd>tbody").replaceWith(data);
				},
				error: function(jqXHR, status, error) {
					console.log(status + ": " + error);
				}
			});
			//validator.reset();
		  }
		
		e.preventDefault();
	});
	
	$('#ButtonAddDmdLoc').on('click', function(e) { 
		  var validator = $("#formAddDetDmd").validate();
		  if(validator.form()==true){
			//var qteDmd   = $('#formAddDetDmd input[id="qte"]').val();
			//var qteDispo = $('#formAddDetDmd input[id="qtedispo"]').val();
			//qteDmd   = parseInt(qteDmd);
			//qteDispo = parseInt(qteDispo);
			var postData = $("#formAddDetDmd").serialize(); 
			var formURL = $(this).attr("data-action");
			$.ajax({
				url: formURL,
				type: 'POST',
				data: postData,
				dataType:"html",
				success: function(data, textStatus, jqXHR) {
				  console.log(postData);	
				  $("#tb_adddmd>tfoot").remove();
				  $("#tb_adddmd>tbody").replaceWith(data);				
				},
				error: function(jqXHR, status, error) {
					console.log(status + ": " + error);
				}
			});
								
		  }
		  e.preventDefault();
	});
	
	$('#buttonMajCpteGle').on('click', function(e) { 
		var validator = $("#formMajCpteGle").validate();
		if(validator.form()==true){
		  var exec = confirm('Confirmez-vous la mise à jour des informations ?');
		  if(exec){
			var postData = $("#formMajCpteGle").serialize(); 
			var formURL = $(this).attr("data-action");
			$.ajax({
				url: formURL,
				type: 'POST',
				data: postData,
				dataType:"json",
				success: function(data) {
				//success: function(data, textStatus, jqXHR) {	
				  alert(data);				
				},
				error: function(jqXHR, status, error) {
					console.log(status + ": " + error);
				}
			});
		  }
	   e.preventDefault();
	  }
	});
	
	$('#buttonMajCpteMdp').on('click', function(e) { 
		var validator = $("#formMajCpteMdp").validate();
		if(validator.form()==true){
			var exec = confirm('Confirmez-vous la modification ?');
			if(exec){
			  var postData = $("#formMajCpteMdp").serialize(); 
			  var formURL = $(this).attr("data-action");
			  $.ajax({
				  url: formURL,
				  type: 'POST',
				  data: postData,
				  dataType:"json",
				  success: function(data) {
				  //success: function(data, textStatus, jqXHR) {	
					alert(data);				
				  },
				  error: function(jqXHR, status, error) {
					  console.log(status + ": " + error);
				  }
			  });
			}
	   e.preventDefault();
	  }
	});

/*======DELEGATION===============*/

	$("#tb_adddevis").on("click", ".ButtonRetirer", function (e) {
		var exec = confirm('Confirmez-vous la suppression de cet élément ?');
		if(exec){
			var $tableau = $(this);
   			var id  = $tableau.closest('tr').attr('id');
			var dev = $tableau.closest('tr').attr('data-dev');
			$.ajax({
			  url: 'del_element_detdevis.php',
			  type: 'GET',
			  data : 'id='+id+'&dev='+dev,
			  dataType:"html",
			  //success: function(donnees) {
			  success: function(data, textStatus, jqXHR) {
					$("#tb_adddevis>tfoot").remove();
				    $("#tb_adddevis>tbody").replaceWith(data);
			  },
			  error: function(jqXHR, status, error) {
				  console.log(status + ": " + error);
			  }
		});
		}
  	});
	
	$("#tb_adddevis").on("click", ".modifButton", function (e) {
		var $tableau = $(this);
   		var id  = $tableau.closest('tr').attr('id');
		var dev = $tableau.closest('tr').attr('data-dev');
		$.ajax({
			url: 'get_info_detdevis.php',
			type: 'GET',
			data: 'id='+id,
			dataType:"json",
			success: function(donnees) {
				$('#formModDetDevis')  
					.find('[id="IdDet"]').val(donnees[0]).end()
					.find('[id="IdDev"]').val(donnees[1]).end()
					.find('[id="rub1"]').val(donnees[2]).end()
					.find('[id="rub2"]').val(donnees[3]).end() 
					.find('[id="materiel"]').val(donnees[4]).end()
					.find('[id="qte"]').val(donnees[5]).end()
					.find('[id="prixu"]').val(donnees[6]).end()
					.find('[id="unite"]').val(donnees[8]).end();
					
				 $('#ModalModifDetDevis .modal-header .modal-title').html("MODIFIER DETAIL DEVIS "+donnees[2]+" | "+donnees[4]);
				 $("#ModalModifDetDevis").modal('show');
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
  	});
	
	$("#tb_addtache").on("click", ".ButtonRetirer", function (e) {
		var exec = confirm('Confirmez-vous la suppression de cet élément ?');
		if(exec){
			var $tableau = $(this);
   			var id  = $tableau.closest('tr').attr('id');
			var dev = $tableau.closest('tr').attr('data-dev');
			var tch_nature = $tableau.closest('tr').attr('data-nat');
			$.ajax({
			  url: 'del_element_dettache.php',
			  type: 'GET',
			  data : 'id='+id+'&dev='+dev+'&nat='+tch_nature,
			  dataType:"html",
			  //success: function(donnees) {
			  success: function(data, textStatus, jqXHR) {
				    $("#tb_addtache>tbody").replaceWith(data);
			  },
			  error: function(jqXHR, status, error) {
				  console.log(status + ": " + error);
			  }
		});
		}
  	});
	
	$("#tb_addtache").on("click", ".modifButton", function (e) {
		var $tableau = $(this);
   		var id  = $tableau.closest('tr').attr('id');
		var dev = $tableau.closest('tr').attr('data-dev');
		$.ajax({
			url: 'get_info_dettache.php',
			type: 'GET',
			data: 'id='+id,
			dataType:"json",
			success: function(donnees) {
				$('#formModDetTache')
					.find('[id="IdTache"]').val(donnees[0]).end()
					.find('[id="tache"]').val(donnees[1]).end() 
					.find('[id="datedeb"]').val(donnees[2]).end()
					.find('[id="datefin"]').val(donnees[3]).end()				
					.find('[id="devis"]').val(donnees[5]).end()
					.find('[id="obj"]').val(donnees[6]).end()
					.find('[id="objHid"]').val(donnees[6]).end();
					
				 $('#ModalModifDetTache .modal-header .modal-title').html("MODIFIER LA T&Acirc;CHE: "+donnees[1]);
				 $("#ModalModifDetTache").modal('show');
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
  	});
	
	$("#tb_addeqp").on("click", ".ButtonRetirer", function (e) {
		var exec = confirm('Confirmez-vous la suppression de cet élément ?');
		if(exec){
			var $tableau = $(this);
   			var id  = $tableau.closest('tr').attr('id');
			var dev = $tableau.closest('tr').attr('data-dev');
			$.ajax({
			  url: 'del_element_deteqp.php',
			  type: 'GET',
			  data : 'id='+id+'&dev='+dev,
			  dataType:"html",
			  //success: function(donnees) {
			  success: function(data, textStatus, jqXHR) {
				    $("#tb_addeqp>tbody").replaceWith(data);
			  },
			  error: function(jqXHR, status, error) {
				  console.log(status + ": " + error);
			  }
		});
		}
  	});
	
	$("#tb_addeqp").on("click", ".modifButton", function (e) {
		var $tableau = $(this);
   		var id  = $tableau.closest('tr').attr('id');
		var dev = $tableau.closest('tr').attr('data-dev');
		$.ajax({
			url: 'get_info_deteqp.php',
			type: 'GET',
			data: 'id='+id,
			dataType:"json",
			success: function(donnees) {
				$('#formModDetEqp')
					.find('[id="IdEqp"]').val(donnees[0]).end()
					.find('[id="IdChant"]').val(donnees[1]).end()				
					.find('[id="activite"]').val(donnees[2]).end()
					.find('[id="respons"]').val(donnees[3]).end()
					.find('[id="tel"]').val(donnees[4]).end();
					
				 $('#ModalModifDetEqp .modal-header .modal-title').html("MODIFIER L'EQUIPE: "+donnees[5]+" ("+donnees[3]+")");
				 $("#ModalModifDetEqp").modal('show');
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
  	});
	
	$("#tb_addoutil").on("click", ".ButtonRetirer", function (e) {
		var exec = confirm('Confirmez-vous la suppression de cet élément ?');
		if(exec){
		  var $tableau = $(this);
		  var id  = $tableau.closest('tr').attr('id');
		  $.ajax({
			  url: 'del_element_detoutil.php',
			  type: 'GET',
			  data : 'id='+id,
			  dataType:"json",
			  success: function(donnees) {
				  var $tableau = $("#tb_addoutil"),
					  	  $tr  = $tableau.find('tr[id="'+donnees[0]+'"]');
					  $tr.remove();
					  console.log("retour: " + donnees[0]);
			  },
			  error: function(jqXHR, status, error) {
				  console.log(status + ": " + error);
			  }
		  });
		}
  	});
	
	$("#ModalModifOutil").on("click", "#submitModifOutil", function (e) {
		var validator = $("#formModDetOut" ).validate();
		if(validator.form()==true){
			var exec = confirm("Confirmez-vous cette modification?");
			if(exec){
			  var trid = $('#formModDetOut input[id="idout"]').val();
			  var formURL  = $("#formModDetOut").attr("action");
			  var postData = $("#formModDetOut").serialize();
			  $.ajax({
				url: formURL,
				type: 'POST',
				data: postData,
				dataType:"html",
				success: function(data, textStatus, jqXHR) {
				  var $tableau = $("#tb_dmdetatsorti"),
					  $tr = $tableau.find('tr[id="'+trid+'"]');
					  $tr.replaceWith(data);
					  $("#ModalModifOutil").modal('hide');
				},
				error: function(jqXHR, status, error) {
					console.log(status + ": " + error);
				}
			  });
			}
		}
		e.preventDefault();
	});
	
	$("#tb_dmdetatsorti").on("click", ".editOutil", function (e) {
		var $tableau = $(this);
		var id  = $tableau.closest('tr').attr('id');
		var numL  = $tableau.closest('tr').attr('data-numL');
	
		$.ajax({
			url: 'get_info_modif_outil.php',
			type: 'GET',
			data: 'id='+id,
			dataType:"json",
			success: function(donnees) {
				$('#formModDetOut')      
					.find('[id="idout"]').val(donnees[0]).end()
					.find('[id="ref"]').val(donnees[4]).end()
					.find('[id="serial"]').val(donnees[5]).end()
					.find('[id="marque"]').val(donnees[6]).end()
					.find('[id="descrip"]').val(donnees[7]).end()
					.find('[id="dateacquis"]').val(donnees[9]).end()	
					.find('[id="designation"]').val(donnees[1]).end()
					.find('[id="prixpart"]').val(donnees[2]).end()
					.find('[id="prixsoc"]').val(donnees[3]).end()
					.find('[id="detail"]').val(donnees[8]).end()
					.find('[id="numL"]').val(numL).end();
				 $('#ModalModifOutil .modal-header .modal-title').html("MODIFIER L'OUTIL "+donnees[1]);
				 $("#ModalModifOutil").modal('show');
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
	});
	
	$("#tb_adddmd").on("click", ".ButtonRetirer", function (e) {
		var exec = confirm('Confirmez-vous la suppression de cet élément ?');
		if(exec){
			var $tableau = $(this);
   			var id  = $tableau.closest('tr').attr('id');
			var dev = $tableau.closest('tr').attr('data-dev');
			$.ajax({
			  url: 'del_element_detdmd.php',
			  type: 'GET',
			  data : 'id='+id+'&dev='+dev,
			  dataType:"html",
			  success: function(data, textStatus, jqXHR) {
				    $("#tb_adddmd>tbody").replaceWith(data);
			  },
			  error: function(jqXHR, status, error) {
				  console.log(status + ": " + error);
			  }
		});
		}
  	});
	
	$("#tb_adddmd").on("click", ".ButtonRetirerLoc", function (e) {
		var exec = confirm('Confirmez-vous la suppression de cet élément ?');
		if(exec){
			var $tableau = $(this);
   			var id  = $tableau.closest('tr').attr('id');
			var dev = $tableau.closest('tr').attr('data-dev');
			$.ajax({
			  url: 'del_element_detdmdLoc.php',
			  type: 'GET',
			  data : 'id='+id+'&dev='+dev,
			  dataType:"html",
			  success: function(data, textStatus, jqXHR) {
				    $("#tb_adddmd>tfoot").remove();
					$("#tb_adddmd>tbody").replaceWith(data);
			  },
			  error: function(jqXHR, status, error) {
				  console.log(status + ": " + error);
			  }
		});
		}
  	});
	
	$("#formModDetDevis").on("submit", function(e) {
		var postData = $(this).serialize(); 
		var formURL = $(this).attr("action");
		$.ajax({
			url: formURL,
			type: 'POST',
			data: postData,
			dataType:"json",
			success: function(data) {
				var IdDet = data[0],
					devdet_materiel = data[4],
					devdet_qte = data[5],
					devdet_prixunit = data[6],
					devdet_unite = data[7],
					TotDevisDetail = data[8],
					TotDevisMo = data[9];
					//Formatage pour affichage
					devdet_prixunit = new Intl.NumberFormat().format(devdet_prixunit);
					TotDevisDetail = new Intl.NumberFormat().format(TotDevisDetail);
					TotDevisMo = new Intl.NumberFormat().format(TotDevisMo);
										
				var $tableau = $("#tb_adddevis"),
					$tr  = $tableau.find('tr[id="'+IdDet+'"]'),
					$cells  = $tr.find('td');
                // Update the cell data
                $cells
                    .eq(3).html(devdet_materiel).end()
                    .eq(4).html(devdet_qte).end()	
					.eq(5).html(devdet_unite).end()
					.eq(6).html(devdet_prixunit).end();	
				var $trFoot  = $tableau.find('tfoot>tr[id="totFoot"]'),
					$cellth = $trFoot.find('th');
					$cellth.eq(1).html(TotDevisDetail).end();
						
				var $trFootMo  = $tableau.find('tfoot>tr[id="totMoFoot"]'),
					$cellthMo = $trFootMo.find('th');
					$cellthMo.eq(1).html('<span class="text-rouge">'+TotDevisMo+'</span>').end();
					
				alert('Modication effectuée avec succès');
				$('#ModalModifDetDevis').modal('hide');
				
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
		e.preventDefault();
	});
	
	$("#submitFormModDetDevis").on('click', function() {
		var validator = $( "#formModDetDevis" ).validate();
		if(validator.form()==true){
			$("#formModDetDevis").submit();
		}
	});
	
	$("#formModDetTache").on("submit", function(e) {
		var postData = $(this).serialize(); 
		var formURL = $(this).attr("action");
		var deb = $('#formModDetTache input[id="datedeb"]').val();
		var fin = $('#formModDetTache input[id="datefin"]').val();
		var debChant = $('#formModDetTache input[id="datedebInit"]').val();
		var finChant = $('#formModDetTache input[id="datefinInit"]').val();
		var error = 0;
		if(deb<debChant || deb>finChant){
		  error = 10;
		  alert ('La date début de la tâche ne peut être antérieure à celle du chantier ou postérieure à sa date de fin');
		}else if(fin<debChant || fin>finChant){
		  error = 11;
		  alert ('La date fin de la tâche ne peut être postérieure à celle du chantier ou antérieure à sa date de debut');
		}else{
		  $.ajax({
			url: formURL,
			type: 'POST',
			data: postData,
			dataType:"json",
			success: function(data) {
				var tache = data[0],
					datedeb = data[1],
					datefin = data[2],
					obj = data[3],	
					IdTache = data[4];		
				var $tableau = $("#tb_addtache"),
					$tr  = $tableau.find('tr[id="'+IdTache+'"]'),
					$cells  = $tr.find('td');
                // Update the cell data
                $cells
                    .eq(1).html(tache).end()
                    .eq(2).html(datedeb+' - '+datefin).end()	
					.eq(3).html(obj).end();
					
				alert('Modication effectuée avec succès');
				$('#ModalModifDetTache').modal('hide');
				
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
		}
		e.preventDefault();
	});
	
	$("#submitFormModDettache").on('click', function() {
		var validator = $("#formModDetTache").validate();
		if(validator.form()==true){
			$("#formModDetTache").submit();
		}
	});
	
	$("#formModDetEqp").on("submit", function(e) {
		var postData = $(this).serialize(); 
		var formURL = $(this).attr("action");
		  $.ajax({
			url: formURL,
			type: 'POST',
			data: postData,
			dataType:"json",
			success: function(data) {
				var eq_id = data[0],
					eq_hrnom = data[1],
					eq_hrcontact = data[2],
					act_libelle = data[3];
				var $tableau = $("#tb_addeqp"),
					$tr  = $tableau.find('tr[id="'+eq_id+'"]'),
					$cells  = $tr.find('td');
                // Update the cell data
                $cells
                    .eq(1).html(act_libelle).end()
                    .eq(2).html(eq_hrnom).end()	
					.eq(3).html(eq_hrcontact).end();
					
				alert('Modication effectuée avec succès');
				$('#ModalModifDetEqp').modal('hide');
				
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
		e.preventDefault();
	});
	
	$("#submitFormModDeteqp").on('click', function() {
		var validator = $( "#formModDetEqp" ).validate();
		if(validator.form()==true){
			$("#formModDetEqp").submit();
		}
	});
		
	$("#tb_gestdevis").on("click", ".ButtonSuppDevis", function (e) {
		var exec = confirm('Confirmez-vous la suppression de ce devis ?');
		if(exec){
			var $tableau = $(this);
   			var dev  = $tableau.closest('tr').attr('id');
			$.ajax({
			  url: 'del_devis.php',
			  type: 'GET',
			  data : 'dev='+dev,
			  dataType:"json",
			  success: function(donnees) {
					  var $tableau = $("#tb_gestdevis"),
					  	  $tr  = $tableau.find('tr[id="'+donnees[0]+'"]');
					  $tr.remove();
			  },
			  error: function(jqXHR, status, error) {
				  console.log(status + ": " + error);
			  }
		});
		}
  	});
	
	$("#tb_gestdevis").on("click", ".ButtonSuppDmdInt", function (e) {
		var exec = confirm('Confirmez-vous la suppression de cette demande ?');
		if(exec){
			var $tableau = $(this);
   			var dev  = $tableau.closest('tr').attr('id');
			//console.log("dev: " + dev);
			$.ajax({
			  url: 'del_demande.php',
			  type: 'GET',
			  data : 'dev='+dev,
			  dataType:"json",
			  success: function(donnees) {
				var $tableau = $("#tb_gestdevis"),
					$tr  = $tableau.find('tr[id="'+donnees[0]+'"]');
				$tr.remove();
			  },
			  error: function(jqXHR, status, error) {
				  console.log(status + ": " + error);
			  }
		});
		}
  	});
	
	$("#tb_gestchantier").on("click", ".ButtonSuppChantier", function (e) {
		var exec = confirm('Confirmez-vous la suppression de ce chantier ?');
			if(exec){
				var $tableau = $(this);
					var dev  = $tableau.closest('tr').attr('id');
				$.ajax({
					url: 'del_chantier.php',
					type: 'GET',
					data : 'dev='+dev,
					dataType:"json",
					success: function(donnees) {
							var $tableau = $("#tb_gestchantier"),
									$tr  = $tableau.find('tr[id="'+donnees[0]+'"]');
									$tr.remove();
					},
					error: function(jqXHR, status, error) {
						console.log(status + ": " + error);
					}
				});
			}
  	});
		
	$("#tb_plann").on("click", ".RapportTacheButton", function (e) {
		var $tableau = $(this);
   		var id  = $tableau.closest('tr').attr('data-id');
		var ch = $tableau.closest('tr').attr('data-ch');
		var numligne = $tableau.closest('tr').attr('data-numligne');
		$.ajax({
			url: 'get_info_rapptache.php',
			type: 'GET',
			data: 'id='+id+'&ch='+ch+'&nl='+numligne,
			dataType:"html",
			success: function(data, textStatus, jqXHR) {
        		$('#ModalRapportTache .modal-body').html(data);
				$("#ModalRapportTache").modal('show');
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
	});
	
	$("#ModalRapportTache").on("click", "#ButtonAddRapport", function (e) {
		  var formAddRapport = $("#formAddRapport");
		  var validator = formAddRapport.validate();
		  if(validator.form()==true){ 
			  var postData = formAddRapport.serialize();
			  var formURL = $("#ButtonAddRapport").attr("data-action");
				var idtache = $("#formAddRapport input[id='idTache']").val();
				var numLigne = $("#formAddRapport input[id='numLigne']").val();
				var idChant = $("#formAddRapport input[id='idChant']").val();
				
				$.ajax({
				  url: formURL,
				  type: 'POST',
				  data: postData,
				  dataType:"html",
				  success: function(data, textStatus, jqXHR) {	
						$('#ModalRapportTache #ulrapport').prepend(data);
				  },
				  error: function(jqXHR, status, error) {
					  console.log(status + ": " + error);
				  }
			  });
				
				$.ajax({
					url: 'get_ligne_tache.php',
					type: 'GET',
					data : 'tache='+idtache+'&nl='+numLigne+'&ch='+idChant,
					dataType:"html",
					success: function(data, textStatus, jqXHR){
						var $tableau = $("#tb_plann"),
							$tr  		= $tableau.find('tr[data-id="'+idtache+'"]');
							$tr.replaceWith(data);
					},
					error: function(jqXHR, status, error) {
						console.log(status + ": " + error);
					}
				});
				
				$.ajax({
					url: 'get_statut_txtache_modal.php',
					type: 'GET',
					data : 'tache='+idtache,
					dataType:"html",
					success: function(data, textStatus, jqXHR){
						//$("#div[id='stattachemodal']").replaceWith(data);
						var dv = $("#ModalRapportTache div[id='stattachemodal']").html();
						//$("#ModalRapportTache .modal-body .page-header-st. #div[id='stattachemodal']").html(data);
						
						$("#ModalRapportTache div[id='stattachemodal']").html(data);
						console.log('dv' + ": " + dv);
						console.log('data' + ": " + data);
					},
					error: function(jqXHR, status, error) {
						console.log(status + ": " + error);
					}
				});
			}
		e.preventDefault();
	  
	});
	
	$("#tb_gestdevis").on("click", ".ButtonOpenTraiteDmdInt", function (e) {
		var $tableau = $(this);
   		var idDmd  = $tableau.closest('tr').attr('id');
		var ch = $tableau.closest('tr').attr('data-ch');
		var numligne = $tableau.closest('tr').attr('data-numligne');
		$.ajax({
			url: 'get_entete_demandeInt_traite_ap.php',
			type: 'GET',
			data: 'id='+idDmd+'&typdm=1',
			dataType:"html",
			success: function(data, textStatus, jqXHR) {
				$("#ModalTraiteDmdInt div[id='enteteGestDmd']").html(data);
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
		$.ajax({
			url: 'get_tbl_demandeInt_traite_ap.php',
			type: 'GET',
			data: 'id='+idDmd+'&typdm=1',
			dataType:"html",
			success: function(data, textStatus, jqXHR) {
				$("#ModalTraiteDmdInt #tb_traiteDmdInt>tbody").replaceWith(data);
				$("#ModalTraiteDmdInt").modal('show');
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
	});
	
	$("#tb_gestdevis").on("click", ".ButtonOpenTraiteDmdIntRet", function (e) {
		var $tableau = $(this);
   		var idDmd  = $tableau.closest('tr').attr('id');
		var ch = $tableau.closest('tr').attr('data-ch');
		var numligne = $tableau.closest('tr').attr('data-numligne');
		$.ajax({
			url: 'get_entete_demandeInt_traite_ap.php',
			type: 'GET',
			data: 'id='+idDmd+'&typdm=1',
			dataType:"html",
			success: function(data, textStatus, jqXHR) {
				$("#ModalTraiteDmdInt div[id='enteteGestDmd']").html(data);
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
		$.ajax({
			url: 'get_tbl_demandeInt_traite_ret_ap.php',
			type: 'GET',
			data: 'id='+idDmd+'&typdm=1',
			dataType:"html",
			success: function(data, textStatus, jqXHR) {
				$("#ModalTraiteDmdInt #tb_traiteDmdInt>tbody").replaceWith(data);
				$("#ModalTraiteDmdInt").modal('show');
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
	});
	
	$("#tb_gestdevis").on("click", ".ButtonOpenTraiteDmdLoc", function (e) {
		var $tableau = $(this);
   		var idDmd  = $tableau.closest('tr').attr('id');
		var ch = $tableau.closest('tr').attr('data-ch');
		var numligne = $tableau.closest('tr').attr('data-numligne');
		$.ajax({
			url: 'get_entete_demandeInt_traite_ap.php',
			type: 'GET',
			data: 'id='+idDmd+'&typdm=0',
			dataType:"html",
			success: function(data, textStatus, jqXHR) {
				$("#ModalTraiteDmdInt div[id='enteteGestDmd']").html(data);
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
		$.ajax({
			url: 'get_tbl_demandeInt_traite_ap.php',
			type: 'GET',
			data: 'id='+idDmd+'&typdm=0',
			dataType:"html",
			success: function(data, textStatus, jqXHR) {
				$("#ModalTraiteDmdInt #tb_traiteDmdInt>tfoot").remove();
				$("#ModalTraiteDmdInt #tb_traiteDmdInt>tbody").replaceWith(data);
				$("#ModalTraiteDmdInt").modal('show');
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
	});
	
	$("#tb_gestdevis").on("click", ".ButtonOpenTraiteDmdLocRet", function (e) {
		var $tableau = $(this);
   		var idDmd  = $tableau.closest('tr').attr('id');
		var ch = $tableau.closest('tr').attr('data-ch');
		var numligne = $tableau.closest('tr').attr('data-numligne');
		$.ajax({
			url: 'get_entete_demandeInt_traite_ap.php',
			type: 'GET',
			data: 'id='+idDmd+'&typdm=0',
			dataType:"html",
			success: function(data, textStatus, jqXHR) {
				$("#ModalTraiteDmdInt div[id='enteteGestDmd']").html(data);
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
		$.ajax({
			url: 'get_tbl_demandeInt_traite_ret_ap.php',
			type: 'GET',
			data: 'id='+idDmd+'&typdm=0',
			dataType:"html",
			success: function(data, textStatus, jqXHR) {
				//$("#ModalTraiteDmdInt #tb_traiteDmdInt>tfoot").remove();
				$("#ModalTraiteDmdInt #tb_traiteDmdInt>tbody").replaceWith(data);
				$("#ModalTraiteDmdInt").modal('show');
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
		
	});
	
	$("#tb_traiteDmdInt").on("click", ".ButtonValideTraiteDmdIntAccord", function (e) {
		var $tableau = $(this);
		var numligne = $tableau.closest('tr').attr('data-numligne');
		var IdDmd = $("#formTraiteDmdInt input[id='IdDmd_"+numligne+"']").val();
		var IdOut = $("#formTraiteDmdInt input[id='IdOutil_"+numligne+"']").val();
		var rep   = $(".ButtonValideTraiteDmdIntAccord").attr('data-rep');
		
		var exec = confirm("Confirmez-vous la sélection de cet outil ?");
		if(exec){
		  var postData = $("#formTraiteDmdInt").serialize();
		  $.ajax({
			url: 'put_dmd_gest.php',
			type: 'POST',
			data: postData+'&nl='+numligne+'&rep='+rep+'&typedmd=1',
			dataType:"html",
			success: function(data, textStatus, jqXHR) {
				var $tableau = $("#tb_traiteDmdInt"),
					$tr = $tableau.find('tr[data-numligne="'+numligne+'"]');
					$tr.replaceWith(data);
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		  });
		  
		  $.ajax({
			url: 'get_etat_dmd_int_gest.php',
			type: 'GET',
			data: 'idDmd='+IdDmd,
			dataType:"json",
			success: function(data) {
			  var etat = parseInt(data[0]);
			  if(etat==1){
				var $tableau = $("#tb_gestdevis"),
					$tr = $tableau.find('tr[id="'+IdDmd+'"]'),
					$cells  = $tr.find('td');
					$cells
					  .eq(5).html('<span class=text-vert><i class="fa fa-check-square-o"></i>&nbsp;Trait&eacute;e</span>').end()
					  .eq(6).html('<i class="fa fa-lock text-jaune" title="Aucune action disponible !"></i>').end();
			  }
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		  });
		}
	    
		e.preventDefault();
	  
	});
	
	$("#tb_traiteDmdInt").on("click", ".ButtonValideTraiteDmdIntRejet", function (e) {
		var $tableau = $(this);
		var numligne = $tableau.closest('tr').attr('data-numligne');
		var IdDmd = $("#formTraiteDmdInt input[id='IdDmd_"+numligne+"']").val();
		var IdOut = $("#formTraiteDmdInt input[id='IdOutil_"+numligne+"']").val();
		var rep   = $(".ButtonValideTraiteDmdIntRejet").attr('data-rep');
		
		var exec = confirm("Confirmez-vous le rejet de cet outil ?");
		if(exec){
		  var postData = $("#formTraiteDmdInt").serialize();
		  $.ajax({
			url: 'put_dmd_gest.php',
			type: 'POST',
			data: postData+'&nl='+numligne+'&rep='+rep+'&typedmd=1',
			dataType:"html",
			success: function(data, textStatus, jqXHR) {
				var $tableau = $("#tb_traiteDmdInt"),
					$tr = $tableau.find('tr[data-numligne="'+numligne+'"]');
					$tr.replaceWith(data);
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		  });
		  
		  $.ajax({
			url: 'get_etat_dmd_int_gest.php',
			type: 'GET',
			data: 'idDmd='+IdDmd,
			dataType:"json",
			success: function(data) {
			  var etat = parseInt(data[0]);
			  if(etat==1){
				var $tableau = $("#tb_gestdevis"),
					$tr = $tableau.find('tr[id="'+IdDmd+'"]'),
					$cells  = $tr.find('td');
					$cells
					  .eq(5).html('<span class=text-vert><i class="fa fa-check-square-o"></i>&nbsp;Trait&eacute;e</span>').end()
					  .eq(6).html('<i class="fa fa-lock text-jaune" title="Aucune action disponible !"></i>').end();
			  }
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		  });
		}
		
		e.preventDefault();
	  
	});
	
	$("#tb_traiteDmdInt").on("click", ".ButtonValideTraiteDmdIntRet", function (e) {
		var $tableau = $(this);
		var numligne = $tableau.closest('tr').attr('data-numligne');
		var IdDmd = $("#formTraiteDmdInt input[id='IdDmd_"+numligne+"']").val();
		var IdDetDmd = $("#formTraiteDmdInt input[id='IdDetDmd_"+numligne+"']").val();
		var IdOutil = $("#formTraiteDmdInt input[id='IdOutil_"+numligne+"']").val();
		
		var exec = confirm("Confirmez-vous le retour de cet outil ?");
		if(exec){
		  var postData = $("#formTraiteDmdInt").serialize();
		  $.ajax({
			url: 'put_dmd_gest_ret.php',
			type: 'POST',
			data: postData+'&nl='+numligne+'&typedmd=1',
			dataType:"html",
			success: function(data, textStatus, jqXHR) {
				var $tableau = $("#tb_traiteDmdInt"),
					$tr = $tableau.find('tr[data-numligne="'+numligne+'"]');
					$tr.replaceWith(data);
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		  });
		  
		  $.ajax({
			url: 'get_etat_dmd_int_gest_ret.php',
			type: 'GET',
			data: 'idDmd='+IdDmd,
			dataType:"json",
			success: function(data) {
			  var etat = parseInt(data[0]);
			  console.log("etat: " + etat);
			  if(etat==1){
				var $tableau = $("#tb_gestdevis"),
					$tr = $tableau.find('tr[id="'+IdDmd+'"]'),
					$cells  = $tr.find('td');
					$cells
					  .eq(5).html('<span class=text-vert><i class="fa fa-check-square-o"></i>&nbsp;Trait&eacute;e</span>').end();
			  }
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		  });
		 
		}
	  
		e.preventDefault();
	  
	});
	
	$("#tb_traiteDmdInt").on("click", ".ButtonValideTraiteDmdLocAccord", function (e) {
		var $tableau = $(this);
		var numligne = $tableau.closest('tr').attr('data-numligne');
		var IdDmd = $("#formTraiteDmdInt input[id='IdDmd_"+numligne+"']").val();
		var IdOut = $("#formTraiteDmdInt input[id='IdOutil_"+numligne+"']").val();
		var rep   = $(".ButtonValideTraiteDmdLocAccord").attr('data-rep');
		
		var exec = confirm("Confirmez-vous la sélection de cet outil ?");
		
		if(exec){
		  var postData = $("#formTraiteDmdInt").serialize();
		  $.ajax({
			url: 'put_dmd_gest.php',
			type: 'POST',
			data: postData+'&nl='+numligne+'&rep='+rep+'&typedmd=0',
			dataType:"html",
			success: function(data, textStatus, jqXHR) {
			  var $tableau = $("#tb_traiteDmdInt"),
				  $tr = $tableau.find('tr[data-numligne="'+numligne+'"]');
				  $tr.replaceWith(data);
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		  });
		  
		  $.ajax({
			url: 'get_etat_dmd_int_gest.php',
			type: 'GET',
			data: 'idDmd='+IdDmd,
			dataType:"json",
			success: function(data) {
			  var etat = parseInt(data[0]);
			  if(etat==1){
				var $tableau = $("#tb_gestdevis"),
					$tr = $tableau.find('tr[id="'+IdDmd+'"]'),
					$cells  = $tr.find('td');
					$cells
					  .eq(3).html('<span class=text-vert><i class="fa fa-check-square-o"></i>&nbsp;Trait&eacute;e</span>').end()
					  .eq(4).html('<i class="fa fa-lock text-jaune" title="Aucune action disponible !"></i>').end();
			  }
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		  });
		}
	  
		e.preventDefault();
	  
	});
	
	$("#tb_traiteDmdInt").on("click", ".ButtonValideTraiteDmdLocRejet", function (e) {
		var $tableau = $(this);
		var numligne = $tableau.closest('tr').attr('data-numligne');
		var IdDmd = $("#formTraiteDmdInt input[id='IdDmd_"+numligne+"']").val();
		var IdOut = $("#formTraiteDmdInt input[id='IdOutil_"+numligne+"']").val();
		var rep   = $(".ButtonValideTraiteDmdLocRejet").attr('data-rep');
		
		var exec = confirm("Confirmez-vous le rejet de cet outil ?");
		
		if(exec){
		  var postData = $("#formTraiteDmdInt").serialize();
		  $.ajax({
			url: 'put_dmd_gest.php',
			type: 'POST',
			data: postData+'&nl='+numligne+'&rep='+rep+'&typedmd=0',
			dataType:"html",
			success: function(data, textStatus, jqXHR) {
			  var $tableau = $("#tb_traiteDmdInt"),
				  $tr = $tableau.find('tr[data-numligne="'+numligne+'"]');
				  $tr.replaceWith(data);
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		  });
		  
		  $.ajax({
			url: 'get_etat_dmd_int_gest.php',
			type: 'GET',
			data: 'idDmd='+IdDmd,
			dataType:"json",
			success: function(data) {
			  var etat = parseInt(data[0]);
			  if(etat==1){
				var $tableau = $("#tb_gestdevis"),
					$tr = $tableau.find('tr[id="'+IdDmd+'"]'),
					$cells  = $tr.find('td');
					$cells
					  .eq(3).html('<span class=text-vert><i class="fa fa-check-square-o"></i>&nbsp;Trait&eacute;e</span>').end()
					  .eq(4).html('<i class="fa fa-lock text-jaune" title="Aucune action disponible !"></i>').end();
			  }
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		  });
		}
	  
		e.preventDefault();
	  
	});
	
	$("#tb_traiteDmdInt").on("click", ".ButtonValideTraiteDmdLocRet", function (e) {
		var $tableau = $(this);
		var numligne = $tableau.closest('tr').attr('data-numligne');
		var IdApprv = $("#formTraiteDmdInt input[id='IdApprv_"+numligne+"']").val();
		var IdDmd = $("#formTraiteDmdInt input[id='IdDmd_"+numligne+"']").val();
		var IdRefOut = $("#formTraiteDmdInt input[id='IdRefOut_"+numligne+"']").val();
		
		var exec = confirm("Confirmez-vous le retour de cet outil ?");
		if(exec){
		  var postData = $("#formTraiteDmdInt").serialize();
		  $.ajax({
			url: 'put_dmd_gest_ret.php',
			type: 'POST',
			data: postData+'&nl='+numligne+'&typedmd=0',
			dataType:"html",
			success: function(data, textStatus, jqXHR) {
				var $tableau = $("#tb_traiteDmdInt"),
					$tr = $tableau.find('tr[data-numligne="'+numligne+'"]');
					$tr.replaceWith(data);
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		  });
		  
		  $.ajax({
			url: 'get_etat_dmd_int_gest_ret.php',
			type: 'GET',
			data: 'idDmd='+IdDmd,
			dataType:"json",
			success: function(data) {
			  var etat = parseInt(data[0]);
			  console.log("etat: " + etat);
			  if(etat==1){
				var $tableau = $("#tb_gestdevis"),
					$tr = $tableau.find('tr[id="'+IdDmd+'"]'),
					$cells  = $tr.find('td');
					$cells
					  .eq(3).html('<span class=text-vert><i class="fa fa-check-square-o"></i>&nbsp;Trait&eacute;e</span>').end();
			  }
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		  });
		  
		}
	  
		e.preventDefault();
	  
	});
	
	$("#ModalTraiteDmdInt").on("click", "#submitFormTermineTraite", function (e) {
		  var formURL = $("#submitFormTermineTraite").attr("data-action");
		  var IdDmd = $("#formTraiteDmdInt input[id='IdDmd_1']").val();
		  $.ajax({
			  url: formURL,
			  type: 'POST',
			  data: postData,
			  dataType:"html",
			  success: function(data, textStatus, jqXHR) {	
					$('#ModalRapportTache #ulrapport').prepend(data);
			  },
			  error: function(jqXHR, status, error) {
				  console.log(status + ": " + error);
			  }
		  });
		 e.preventDefault();
	});
	
	$("#tb_gestdevis").on("click", ".ButtonOuvrirDetDmdInt", function (e) {
		var $tableau = $(this);
   		var idDmd  = $tableau.closest('tr').attr('id');
		$.ajax({
		  url: 'get_demandeInt_det_traite_ap.php',
		  type: 'GET',
		  data: 'id='+idDmd,
		  dataType:"html",
		  success: function(data, textStatus, jqXHR) {
              $('#ModalDetailDmd .modal-body').html(data);
			  $("#ModalDetailDmd").modal('show');
		  },
		  error: function(jqXHR, status, error) {
			  console.log(status + ": " + error);
		  }
	  });
	  e.preventDefault();
	});
	
	$("#tb_gestdevis").on("click", ".ButtonOuvrirDetDmdLoc", function (e) {
		var $tableau = $(this);
   		var idDmd  = $tableau.closest('tr').attr('id');
		$.ajax({
		  url: 'get_demandeLoc_det_traite_ap.php',
		  type: 'GET',
		  data: 'id='+idDmd,
		  dataType:"html",
		  success: function(data, textStatus, jqXHR) {
              $('#ModalDetailDmd .modal-body').html(data);
			  $("#ModalDetailDmd").modal('show');
		  },
		  error: function(jqXHR, status, error) {
			  console.log(status + ": " + error);
		  }
	  });
	  e.preventDefault();
	});
			
	$("#ButtonEnregDevis").on('click', function() {
		var validator = $( "#formEnregDetDev" ).validate();
		if(validator.form()==true){
			$("#formEnregDetDev").submit();
		}
	});
	
	$("#formEnregDetDev").on("submit", function(e) {
		var postData = $(this).serialize(); 
		var formURL  = $(this).attr("action");
		$.ajax({
			url: formURL,
			type: 'POST',
			data: postData,
			dataType:"json",
			success: function(data) {
				document.location="?yk=devisgest&act=add";
			},
			error: function(jqXHR, status, error) {
				console.log(status + ": " + error);
			}
		});
		e.preventDefault();
	});

	$('#formEnregDetDev input[id="mainoeuv"]').on('click keyup', function(e) {
		var Mo = $(this).val(),
			iddevis = $('#formEnregDetDev input[id="devis"]').val();
			$.ajax({
			  url: 'get_totdevis_mo.php',
			  type: 'GET',
			  data : 'dev='+iddevis+'&mtmo='+Mo,
			  dataType:'json',
			  success: function(data) {
				var $tableau = $("#tb_adddevis"),
				  	$trFoot  = $tableau.find('tfoot>tr[id="totMoFoot"]'),
					$cellth = $trFoot.find('th');
				$cellth.eq(1).html('<span class="text-rouge">'+data[0]+'</span>').end();
			},
			error: function(status, error) {
				console.log(status + ": " + error);
			}
		});
			
	});
	
	$('#formAddDetDmd input[id="nbrejr"]').on('focus change', function(e) {
		var idOut = $('#formAddDetDmd input[id="outilId"]').val();
		var typeClt = $('#formAddDetDmd input[id="typeclt"]').val();
			$.ajax({
			  url: 'get_qteoutildispo.php',
			  type: 'GET',
			  data : 'id='+idOut+'&tclt='+typeClt,
			  dataType:'json',
			  success: function(data) {
				//$('#formAddDetDmd input[id="qtedispo"]').val(data[0]);
				$('#formAddDetDmd input[id="pujr"]').val(data[0]);
			},
			error: function(status, error) {
				console.log(status + ": " + error);
			}
		});
			
	});
	
	$('#formAddDetTache select[id="devis"]').on('change', function(e) {
		var iddevis = $(this).val();
		$.ajax({
			  url: 'get_info_devis.php',
			  type: 'GET',
			  data : 'dev='+iddevis,
			  dataType:'json',
			  success: function(data){
				//$('#formAddDetTache input[id="clt"]').val(data[0]);
				$('#formAddDetTache input[id="obj"]').val(data[1]);
			  },
			  error: function(status, error) {
				console.log(status + ": " + error);
			  }
		});
			
	});
	
	$('#formModDetTache select[id="devis"]').on('change', function(e) {
		var iddevis = $(this).val();
		$.ajax({
			  url: 'get_info_devis.php',
			  type: 'GET',
			  data : 'dev='+iddevis,
			  dataType:'json',
			  success: function(data){
				$('#formModDetTache input[id="obj"]').val(data[1]);
				$('#formModDetTache input[id="objHid"]').val(data[1]);
			  },
			  error: function(status, error) {
				console.log(status + ": " + error);
			  }
		});
			
	});
	
	$('#formModifDevis select[id="etat"]').on('change', function(e) {
		var etat = $(this).val();
		etat = parseInt(etat);
		if(etat!=0){
			$('#formModifDevis div[id="blcModDevisSuiv"]').hide();
		}else {
			$('#formModifDevis div[id="blcModDevisSuiv"]').show();
		}
	});
	
	$('#formModChantier select[id="etat"]').on('change', function(e) {
		var etat = $(this).val();
		etat = parseInt(etat);
		if(etat!=1){
			$('#formModChantier div[id="blcModChantSuiv"]').hide();
			$('#formModChantier input[id="datefineff"]').attr('required', 'required');
		}else {
			$('#formModChantier div[id="blcModChantSuiv"]').show();
			$('#formModChantier input[id="datefineff"]').removeAttr('required');
		}
	});
	
	$('#formAddDetOut input[id="ref"]').on('keyup', function(e) {
		var debRef = $(this).val();
		var	debRefTaill = debRef.length;
		console.log("debRefTaill: " + debRefTaill);
		if(debRefTaill>1 && debRefTaill<4){
		  $('#formAddDetOut div[id="proposeref"]').show();
		  $.ajax({
			url: 'get_propose_ref_outil.php',
			type: 'GET',
			data : 'dref='+debRef+'&tail='+debRefTaill,
			dataType:'json',
			success: function(data) {
			  $('#formAddDetOut input[id="refProp"]').val(data[0]);
			},
			error: function(status, error) {
				console.log(status + ": " + error);
			}
	  	  });
		}
			
			
	});
	
	$('#formAddDetOut input[id="refProp"]').on('click', function(e) {
		var ref = $(this).val();
		$('#formAddDetOut input[id="ref"]').val(ref);
		$('#formAddDetOut div[id="proposeref"]').hide();
	});
	
});