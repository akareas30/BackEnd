<?php
session_start();
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php"); 
VerifTempsLog();

if(isset($_POST['datedeb']) or isset($_POST['datefin'])){
  if($_POST['datedeb']!="") $deb = trim($_POST['datedeb']); else $deb='0000-00-00';
  if($_POST['datefin']!="") $fin = trim($_POST['datefin']); else $fin=date('Y-m-d');
  $cndEtatCplt = " AND dev_date_cre BETWEEN '$deb' AND '$fin'";
}elseif(!isset($_POST['datedeb']) and !isset($_POST['datefin'])){
  $cndEtatCplt = "";
}else $cndEtatCplt="";

  
$chpEtat="COUNT(dev_id) AS NBRE,getMtDevis(dev_id) AS MONTANT";
$cndEtat0="dev_etat_accepte=0";//en cours
$cndEtat1="dev_etat_accepte=1";//accepté
$cndEtat10="dev_etat_accepte=10";//Réfusé
$cndEtat11="dev_etat_accepte=11";//Annulé

$req0  = selections($chpEtat,DEVIS,$cndEtat0.$cndEtatCplt,1);
$req1  = selections($chpEtat,DEVIS,$cndEtat1.$cndEtatCplt,1);
$req10 = selections($chpEtat,DEVIS,$cndEtat10.$cndEtatCplt,1);
$req11 = selections($chpEtat,DEVIS,$cndEtat11.$cndEtatCplt,1);

$Res0  = $pdo->query($req0)->fetch();
$Res1  = $pdo->query($req1)->fetch();
$Res10 = $pdo->query($req10)->fetch();
$Res11 = $pdo->query($req11)->fetch();

//Les nombres de devis selon les etats
$Nbre0  = $Res0['NBRE'];
$Nbre1  = $Res1['NBRE'];
$Nbre10 = $Res10['NBRE'];
$Nbre11 = $Res11['NBRE'];
$TotNbre = $Nbre0+$Nbre1+$Nbre10+$Nbre11;

//Les taux selon les etats
$TauxNbre0  = number_format($Nbre0*100/$TotNbre,2,',','').'%';
$TauxNbre1  = number_format($Nbre1*100/$TotNbre,2,',','').'%';
$TauxNbre10 = number_format($Nbre10*100/$TotNbre,2,',','').'%';
$TauxNbre11 = number_format($Nbre11*100/$TotNbre,2,',','').'%';
$TotTx 		= number_format($TotNbre*100/$TotNbre,0,',','').'%';

//Les montants TTC selon les etats		
$Mt0_br  = $Res0['MONTANT'];
$Mt1_br  = $Res1['MONTANT'];
$Mt10_br = $Res10['MONTANT'];
$Mt11_br = $Res11['MONTANT'];

$Mt0  = number_format(($Mt0_br+(TVA*$Mt0_br)),0,'',' ');
$Mt1  = number_format(($Mt1_br+(TVA*$Mt1_br)),0,'',' ');
$Mt10 = number_format(($Mt10_br+(TVA*$Mt10_br)),0,'',' ');
$Mt11 = number_format(($Mt11_br+(TVA*$Mt11_br)),0,'',' ');

$TotMt_br = $Mt0_br+$Mt1_br+$Mt10_br+$Mt11_br;
$TotMt = number_format(($TotMt_br+(TVA*$TotMt_br)),0,'',' ');

//Output data
$array = array($Nbre0,$Nbre1,$Nbre10,$Nbre11,$TotNbre,$TauxNbre0,$TauxNbre1,$TauxNbre10,$TauxNbre11,$Mt0,$Mt1,$Mt10,$Mt11,$TotMt,$TotTx);
echo json_encode($array);
?>