<?php 
include('statdevis_ap.php');
?>