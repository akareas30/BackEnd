<?php		
	session_start();
	ini_set('session.bug_compat_42', 0);
	ini_set('session.bug_compat_warn', 0);
	require('inc/definitions.php');
	include("inc/cnt.php");
	include("inc/fonction.php");
	
	$q = strtoupper($_GET["q"]);
	if (!$q) return;
	 /* 
	//$q = strtoupper($_GET["term"]);
	$q = strtoupper($_GET["query"]);
	*/
	$qc = strtoupper(trim(addslashes($q)));
	$cnd = "clt_nom LIKE '%$qc%' AND clt_etat=1";
	$req = selections("clt_id,clt_nom",CLIENTS,$cnd,"clt_nom ASC");
	$res = $pdo->query($req);
	while($col = $res->fetch(PDO::FETCH_ASSOC)) {
		$data[] = $col;
	}
	echo json_encode($data);
	$res->closeCursor();
	//echo 'inconnu ...';

?>

