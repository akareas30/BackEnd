<?php
session_start();
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php");
VerifTempsLog();

if(isset($_GET['id'])){
  $IdChant0  = $_GET['id'];  
  $chp = "eq_id, eq_hrnom, eq_hrcontact,act_libelle";
  $tb = CHANTIERS_EQP." LEFT JOIN ".ACTIVITES." ON eq_idact=act_id"; 
  $reqDet = selections($chp,$tb,"eq_idcht=$IdChant0","eq_id ASC");
  $resDet = $pdo->query($reqDet);		
							
?>
<table width="100%" class="table table-bordered table-hover" id="tb_addeqp">
  <thead>
      <tr>
          <th align="center">#</th>
          <th align="left">Equipe</th>
          <th align="center">Responsable</th>
          <th align="center">Contacts</th>
      </tr>
  </thead>
  <tbody>
  <?php 
  $i = 0;
  while($col = $resDet->fetch()){
    $eq_id 		 = $col['eq_id'];
    $eq_hrnom 	 = $col['eq_hrnom'];
    $eq_hrcontact	 = $col['eq_hrcontact'];
    $act_libelle   = $col['act_libelle'];
    
    $i++;
    ?>
      <tr id="<?php echo $eq_id;?>" data-dev="<?php echo $IdChant0; ?>" class="even gradeA success">
          <td align="center"><?php echo $i ?></td>
          <td><?php echo $act_libelle ?></td>
          <td align="left"><?php echo $eq_hrnom; ?></td>
          <td align="center"><?php echo $eq_hrcontact; ?></td>
      </tr>
      <?php 
  }
      ?>
  </tbody>
  </table>
<?php 
$pdo=null;
}
?>