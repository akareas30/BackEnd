<?php
session_start();
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php"); 
VerifTempsLog();
if(isset($_GET['dev'])){
  $iddevis  = $_GET['dev'];
  $ch = "clt_abrege, dev_objet";
  $tab = DEVIS." LEFT JOIN ".CLIENTS." on dev_clt=clt_id";
  $cd = "dev_id=$iddevis";
  $req = selections($ch,$tab,$cd,"dev_id");
  $res = $pdo->query($req);
  $donnees = $res->fetch();
  echo json_encode($donnees);
  $pdo=null;
}
?>
