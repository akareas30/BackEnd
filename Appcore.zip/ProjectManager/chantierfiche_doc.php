<?php 
session_start();
ini_set('session.bug_compat_42', 0);
ini_set('session.bug_compat_warn', 0);
require('inc/definitions.php');
include("inc/cnt.php");
include("inc/fonction.php"); 
?>

<?php
if(isset($_GET['cht'])){
	$IdChant0 = (int)$_GET['cht'];
}
$chp = "D.cht_libelle, D.cht_debut, D.cht_fin_prevu, cht_etat, cht_descrip, clt_abrege";
$tb = CHANTIERS." D LEFT JOIN ".CLIENTS." C ON D.cht_client=C.clt_id";
$cnd = "cht_id=$IdChant0";
$reqLib = selections($chp,$tb,$cnd,1);
$res = $pdo->query($reqLib);
$col = $res->fetch();
$cht_libelle 	= $col['cht_libelle'];
$cht_debut 		= $col['cht_debut'];
$cht_fin_prevu 	= $col['cht_fin_prevu'];
$cht_etat 		= $col['cht_etat'];
$cht_descrip	= $col['cht_descrip'];
$clt_abrege		= $col['clt_abrege'];

$ref_format = str_replace(" ","-",stripslashes($cht_libelle));
$filename = "SYNTHESE_CHANTIER-".stripslashes($ref_format).".doc";
header("Content-type: application/vnd.ms-word");
header("Content-Disposition: attachment; filename=$filename");
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<!--<link href="vendor/bootstrap/css/bootstrap.css" rel="stylesheet">
<link href="vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">
<link href="dist/css/sb-admin-2.css" rel="stylesheet">-->
</head>

<div style="margin-right:15px; margin-left:15px;">
  <div style="width:100%">
      <h4>CHANTIER / PROJET : <?php echo '<span class="text-bleu">'.stripslashes($cht_libelle).'</span>';?></h4>
  </div>
</div>

<div style="padding-bottom: 0px;  margin: 0 0 5px 0;  border-bottom: 1px solid #E36E07;  color:#000066; margin-right:15px; margin-left:15px;">
  <div style="width:100%">
      <h4>DESCRIPTION: <span class="text-bleu"><?php echo stripslashes($cht_descrip);?></span></h4>
  </div>
  <div>
      <h5>CLIENT: <span class="text-bleu"><?php echo $clt_abrege;?></span>
      &nbsp;&nbsp;/&nbsp;&nbsp;PERIODE EXEC.: <span class="text-bleu"><?php echo 'Du '.getdateC($cht_debut).' au '.getdateC($cht_fin_prevu);?></span></h5>
  </div>
</div>

<div style="margin-right: -15px;  margin-left: -15px;">
 <div style="min-height: 1px;  padding-right: 15px;  padding-left: 15px;  width: 100%;">
  <div style="margin-bottom: 10px;  background-color: #FDFDFD;  border: 1px solid transparent; border-color: #F6B210;">
      <div style="color: #006600; background-color: #FFFFCC;	border-color: #F6B210;	font-weight: bold;"> T&Acirc;CHES INITIALES</div>
      <!-- /.panel-heading -->
      <div style="padding: 10px;">
          <?php 
          $chp = "tch_id, tch_libelle, tch_debut, tch_fin_prevu, tch_fin_eff, dev_ref, tch_nature, tch_taux, dev_objet";	  
          $tb = TACHES." LEFT JOIN ".DEVIS." ON tch_devis=dev_id"; 
          $reqDet = selections($chp,$tb,"cht_id=$IdChant0 and tch_nature=0","tch_id ASC");
          $resDet = $pdo->query($reqDet);							
          ?>
        <table style="border-spacing: 0;  border-collapse: collapse;  width: 100%;  margin-bottom: 10px; border: 1px solid #ddd;">
              <thead>
                  <tr>
                      <th align="center" style="border: 1px solid #ddd;">#</th>
                      <th align="left" style="border: 1px solid #ddd;">Travaux</th>
                      <th align="center" style="border: 1px solid #ddd;">D&eacute;lai</th>
                      <th align="center" style="border: 1px solid #ddd;">Taux r&eacute;alisat.</th>
                      <th align="center" style="border: 1px solid #ddd;">Statut</th>
                  </tr>
              </thead>
              <tbody>
              <?php 
              $i = 0;
              while($col = $resDet->fetch()){
                $tch_id 		 = $col['tch_id'];
                $tch_libelle 	 = $col['tch_libelle'];
                $tch_debut	 	 = $col['tch_debut'];
                $tch_fin_prevu   = $col['tch_fin_prevu'];
				$tch_fin_eff   	 = $col['tch_fin_eff'];
				$tch_nature 	 = $col['tch_nature'];
                $tch_taux 	     = $col['tch_taux'];
                $dev_ref 	 	 = $col['dev_ref'];
                $dev_objet 	     = $col['dev_objet'];
				
				//$tch_fin_eff = "2017-12-24";
				//$tch_taux = 80;
				$nature = "";
				if($tch_nature==1)$nature = '&nbsp;&nbsp;<span data-toggle="tooltip" data-placement="right" title="T&acirc;che suppl&eacute;mentaire" class="text-bleu"><i class="fa fa-plus"></i></span>';
				
				$LeJour = date('Y-m-d');
				$TimeJour 	 = new DateTime($LeJour);
				$timeFinPrev = new DateTime($tch_fin_prevu);
				$timeFinEff  = new DateTime($tch_fin_eff);
				
				$JourFinEff = $timeFinEff->format('d-m-Y');
				
				if($tch_taux<100){//Si taux <100 alors tache tjrs en cours
					$statut = '<span class="text-bleu"><i class="fa fa-pencil-square-o"></i>&nbsp;En cours</span>'; 
				}else{//tache terminé
					$statut = '<span class="text-vert"><i class="fa fa-check-square-o"></i>&nbsp;Termin&eacute;</span>';
					if($tch_fin_eff!=0){
						$intervalEff = $timeFinPrev->diff($timeFinEff);
						$NbreJourFinEff = $intervalEff->format('J%R%a');//Nbre entre la date fin effective et celle prevue
						if(($timeFinEff>$timeFinPrev)==true){
							$statut .='<br /><span class="small text-rouge">&nbsp;&Agrave; '.$NbreJourFinEff.' ('.$JourFinEff.')</span>';
						}else{
							$statut .='<br /><span class="small text-vert">&nbsp;&Agrave; '.$NbreJourFinEff.' ('.$JourFinEff.')</span>';
						}
					}
				}
				
				if($tch_taux>=0 and $tch_taux<=50){
					$colorTx = "text-rouge";
				}elseif($tch_taux>50 and $tch_taux<=90){
					$colorTx = "text-jaune";
				}elseif($tch_taux>90 and $tch_taux<100){
					$colorTx = "text-orange";
				}elseif($tch_taux==100){
					$colorTx = "text-vert";
				}
				
				$expire = "";
				$colorExpire = "";
				//Si delai expiré
				if(($TimeJour>$timeFinPrev)==true){
					$expire = "Expir&eacute;";//Affiché "Expiré"
					$colorExpire = "text-rouge";//et le mettre en rouge
					$colorJ = "text-rouge";//Mettre en rouge la couleur du Jour J-
				}elseif(($TimeJour==$timeFinPrev)==true){
					$colorJ = "text-rouge";//Si on est au Jour J;
				}elseif(($TimeJour>$timeFinPrev)==false){
					$colorJ = "text-vert";//Sil le delai n'a pas expiré, mettre en vert la couleur du Jour J-
				}
				//Nbre de d'ici à la date fin prévu
				$interval = $timeFinPrev->diff($TimeJour);
				$NbreJourJ = $interval->format('J%R%a');
				
                $i++;
                ?>
                  <tr class="success">
                      <td align="center" style="border: 1px solid #ddd;"><?php echo $i ?></td>
                      <td style="border: 1px solid #ddd;"><?php echo "<strong>".$tch_libelle.$nature.'</strong><br /><span class="small">'.$dev_objet.'<span />'; ?>
                      </td>
                      <td align="center" style="border: 1px solid #ddd;">
					  <?php echo getdateC($tch_debut).' - '.getdateC($tch_fin_prevu); 
                      if($expire!="")echo '<br /><span class="small '.$colorExpire.'">'.$expire.'</span>';?>
                      </td>
                      <td align="center" style="border: 1px solid #ddd;">
					  <?php echo '<span class="'.$colorTx.'">'.$tch_taux.'%</span>';
					  if($tch_taux<100)echo '<span class="small '.$colorJ.'">&nbsp;('.$NbreJourJ.')</span>';?>
                      </td>
                      <td align="center" style="border: 1px solid #ddd;"><?php echo $statut;?></td>
                  </tr>
                  <?php 
              }
                  ?>
              </tbody>
        </table>
          <!-- /.table-responsive -->
                  
      </div>
      <!-- /.panel-body -->
  </div>
 </div>
</div>

<div style="margin-right: -15px;  margin-left: -15px;">
 <div style="min-height: 1px;  padding-right: 15px;  padding-left: 15px;  width: 100%;">
  <div style="margin-bottom: 10px;  background-color: #FDFDFD;  border: 1px solid transparent; border-color: #F6B210;">
      <div style="color: #006600; background-color: #FFFFCC;	border-color: #F6B210;	font-weight: bold;"> T&Acirc;CHES SUPPLEMENTAIRES</div>
      <!-- /.panel-heading -->
      <div style="padding: 10px;">
          <?php 
          $chp = "tch_id, tch_libelle, tch_debut, tch_fin_prevu, tch_fin_eff, dev_ref, tch_nature, tch_taux, dev_objet";	  
          $tb = TACHES." LEFT JOIN ".DEVIS." ON tch_devis=dev_id"; 
          $reqDet = selections($chp,$tb,"cht_id=$IdChant0 and tch_nature=1","tch_id ASC");
          $resDet = $pdo->query($reqDet);							
          ?>
        <table style="border-spacing: 0;  border-collapse: collapse;  width: 100%;  margin-bottom: 10px; border: 1px solid #ddd;">
              <thead>
                  <tr>
                      <th width="8%" align="center" style="border: 1px solid #ddd;">#</th>
                      <th width="23%" align="left" style="border: 1px solid #ddd;">Travaux</th>
                      <th width="15%" align="center" style="border: 1px solid #ddd;">D&eacute;lai</th>
                      <th width="37%" align="center" style="border: 1px solid #ddd;">Taux r&eacute;alisat.</th>
                      <th width="17%" align="center" style="border: 1px solid #ddd;">Statut</th>
                  </tr>
              </thead>
              <tbody>
              <?php 
              $i = 0;
              while($col = $resDet->fetch()){
                $tch_id 		 = $col['tch_id'];
                $tch_libelle 	 = $col['tch_libelle'];
                $tch_debut	 	 = $col['tch_debut'];
                $tch_fin_prevu   = $col['tch_fin_prevu'];
				$tch_fin_eff   	 = $col['tch_fin_eff'];
				$tch_nature 	 = $col['tch_nature'];
                $tch_taux 	     = $col['tch_taux'];
                $dev_ref 	 	 = $col['dev_ref'];
                $dev_objet 	     = $col['dev_objet'];
				
				//$tch_fin_eff = "2017-12-24";
				//$tch_taux = 80;
				$nature = "";
				if($tch_nature==1)$nature = '&nbsp;&nbsp;<span data-toggle="tooltip" data-placement="right" title="T&acirc;che suppl&eacute;mentaire" class="text-bleu"><i class="fa fa-plus"></i></span>';
				
				$LeJour = date('Y-m-d');
				$TimeJour 	 = new DateTime($LeJour);
				$timeFinPrev = new DateTime($tch_fin_prevu);
				$timeFinEff  = new DateTime($tch_fin_eff);
				
				$JourFinEff = $timeFinEff->format('d-m-Y');
				
				if($tch_taux<100){//Si taux <100 alors tache tjrs en cours
					$statut = '<span class="text-bleu"><i class="fa fa-pencil-square-o"></i>&nbsp;En cours</span>'; 
				}else{//tache terminé
					$statut = '<span class="text-vert"><i class="fa fa-check-square-o"></i>&nbsp;Termin&eacute;</span>';
					if($tch_fin_eff!=0){
						$intervalEff = $timeFinPrev->diff($timeFinEff);
						$NbreJourFinEff = $intervalEff->format('J%R%a');//Nbre entre la date fin effective et celle prevue
						if(($timeFinEff>$timeFinPrev)==true){
							$statut .='<br /><span class="small text-rouge">&nbsp;&Agrave; '.$NbreJourFinEff.' ('.$JourFinEff.')</span>';
						}else{
							$statut .='<br /><span class="small text-vert">&nbsp;&Agrave; '.$NbreJourFinEff.' ('.$JourFinEff.')</span>';
						}
					}
				}
				
				if($tch_taux>=0 and $tch_taux<=50){
					$colorTx = "text-rouge";
				}elseif($tch_taux>50 and $tch_taux<=90){
					$colorTx = "text-jaune";
				}elseif($tch_taux>90 and $tch_taux<100){
					$colorTx = "text-orange";
				}elseif($tch_taux==100){
					$colorTx = "text-vert";
				}
				
				$expire = "";
				$colorExpire = "";
				//Si delai expiré
				if(($TimeJour>$timeFinPrev)==true){
					$expire = "Expir&eacute;";//Affiché "Expiré"
					$colorExpire = "text-rouge";//et le mettre en rouge
					$colorJ = "text-rouge";//Mettre en rouge la couleur du Jour J-
				}elseif(($TimeJour==$timeFinPrev)==true){
					$colorJ = "text-rouge";//Si on est au Jour J;
				}elseif(($TimeJour>$timeFinPrev)==false){
					$colorJ = "text-vert";//Sil le delai n'a pas expiré, mettre en vert la couleur du Jour J-
				}
				//Nbre de d'ici à la date fin prévu
				$interval = $timeFinPrev->diff($TimeJour);
				$NbreJourJ = $interval->format('J%R%a');
				
                $i++;
                ?>
                  <tr class="even gradeA success">
                      <td align="center" style="border: 1px solid #ddd;"><?php echo $i ?></td>
                      <td style="border: 1px solid #ddd;"><?php echo "<strong>".$tch_libelle.$nature.'</strong><br /><span class="small">'.$dev_objet.'<span />'; ?>
                      </td>
                      <td align="center" style="border: 1px solid #ddd;">
					  <?php echo getdateC($tch_debut).' - '.getdateC($tch_fin_prevu); 
                      if($expire!="")echo '<br /><span class="small '.$colorExpire.'">'.$expire.'</span>';?>
                      </td>
                      <td align="center" style="border: 1px solid #ddd;">
					  <?php echo '<span class="'.$colorTx.'">'.$tch_taux.'%</span>';
					  if($tch_taux<100)echo '<span class="small '.$colorJ.'">&nbsp;('.$NbreJourJ.')</span>';?>
                      </td>
                      <td align="center" style="border: 1px solid #ddd;"><?php echo $statut;?></td>
                  </tr>
                  <?php 
              }
                  ?>
              </tbody>
        </table>
          <!-- /.table-responsive -->
                  
      </div>
      <!-- /.panel-body -->
  </div>
 </div>
</div>

<div style="margin-right: -15px;  margin-left: -15px;">
 <div style="min-height: 1px;  padding-right: 15px;  padding-left: 15px;  width: 100%;">
  <div style="margin-bottom: 10px;  background-color: #FDFDFD;  border: 1px solid transparent; border-color: #F6B210;">
      <div style="color: #006600; background-color: #FFFFCC;	border-color: #F6B210;	font-weight: bold;"> &Eacute;QUIPES CHANTIER</div>
      <!-- /.panel-heading -->
      <div style="padding: 10px;">
          <?php 
		  $chp = "eq_id, eq_hrnom, eq_hrcontact,act_libelle";
		  $tb = CHANTIERS_EQP." LEFT JOIN ".ACTIVITES." ON eq_idact=act_id"; 
		  $reqDet = selections($chp,$tb,"eq_idcht=$IdChant0","eq_id ASC");
		  $resDet = $pdo->query($reqDet);						
          ?>
        <table style="border-spacing: 0;  border-collapse: collapse;  width: 100%;  margin-bottom: 10px; border: 1px solid #ddd;">
  <thead>
      <tr>
          <th align="center" style="border: 1px solid #ddd;">#</th>
          <th align="left" style="border: 1px solid #ddd;">Equipe</th>
          <th align="center" style="border: 1px solid #ddd;">Responsable</th>
          <th align="center" style="border: 1px solid #ddd;">Contacts</th>
      </tr>
  </thead>
  <tbody>
  <?php 
  $i = 0;
  while($col = $resDet->fetch()){
    $eq_id 		 = $col['eq_id'];
    $eq_hrnom 	 = $col['eq_hrnom'];
    $eq_hrcontact	 = $col['eq_hrcontact'];
    $act_libelle   = $col['act_libelle'];
    
    $i++;
    ?>
      <tr class="even gradeA success">
          <td align="center" style="border: 1px solid #ddd;"><?php echo $i ?></td>
          <td style="border: 1px solid #ddd;"><?php echo $act_libelle ?></td>
          <td align="left" style="border: 1px solid #ddd;"><?php echo $eq_hrnom; ?></td>
          <td align="center" style="border: 1px solid #ddd;"><?php echo $eq_hrcontact; ?></td>
      </tr>
      <?php 
  }
      ?>
  </tbody>
  </table>
      <!-- /.table-responsive --></div>
      <!-- /.panel-body -->
  </div>
 </div>
</div>	
</body>

</html>