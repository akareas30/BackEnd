<?php if(isset($_GET['act']) and  $_GET['act']=="add"){ ?>
<div class="row">
  <div class="col-lg-12">
      <h3 class="page-header">MON COMPTE UTILISATEUR</h3>
  </div>
  <div class="col-lg-12">
      <h4>MISE &Agrave; DES INFOS</h4>
  </div>
  <!-- /.col-lg-12 -->
</div>

<?php
$iduser = $_SESSION['AP_iduser'];
$chp = "user_id,user_nom,user_prenom,user_fonct,user_profil,user_mail,user_pass,user_pass_modif,user_pass_datemodif";
$req = selections($chp,USERS,"user_id=$iduser","user_id");
$res = $pdo->query($req);
$col = $res->fetch();
$user_id 		= $col['user_id'];
$user_profil 	= $col['user_profil'];
$user_nom	 	= $col['user_nom'];
$user_prenom 	= $col['user_prenom'];
$user_fonct 	= $col['user_fonct'];
$user_mail 	 	= $col['user_mail'];
$user_pass 	 	= $col['user_pass'];
?>

<div class="row">
  <div class="col-lg-12">
     <div class="panel-group" id="accordion">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h4 class="panel-title">
                    <a data-toggle="collapse" data-parent="#accordion" href="#collapseGeneral">G&eacute;n&eacute;ral</a>
                </h4>
            </div>
            <div id="collapseGeneral" class="panel-collapse collapse in">
                <div class="panel-body">
                    <form role="form" action="" method="post" id="formMajCpteGle">
                      <div class="panel-body">
                          <div class="row">              
                              <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Nom *</label>
                                    <input name="nom" id="nom" type="text" class="form-control" placeholder="Le nom" required="required" autofocus="autofocus" value="<?php echo $user_nom; ?>" />
                                </div>
                                <div class="form-group">
                                    <label>Pr&eacute;nom *</label>
                                    <input name="prenom" id="prenom" type="text" class="form-control" placeholder="Le pr&eacute;nom" required="required" value="<?php echo $user_prenom; ?>" />
                                </div>
                                <div class="form-group">
                                    <label>Fonction</label>
                                    <input name="fonct" id="fonct" type="text" class="form-control" placeholder="La fonction" value="<?php echo $user_fonct; ?>" />
                                </div>
                              </div>
                              <!-- /.col-lg-6 (nested) -->
                              <div class="col-lg-6">
                                <div class="form-group">
                                <label>Profil *</label>
                                <select name="profil" id="profil" class="form-control" required="required" disabled="disabled">
                                 <option value="">-- Selectionner un profil --</option>
                                 <?php profilUser($user_profil);?>
                                </select>
                                </div>
                                <div class="form-group">
                                    <label>Email *</label>
                                    <input name="email" id="email" type="email" class="form-control" placeholder="L'adresse mail" required="required" value="<?php echo $user_mail; ?>" />
                                </div>
                                
                              </div>
                          </div>
                          <div class="row">
                          <div class="col-lg-4 center-block">
                              <button name="buttonMajCpteGle" id="buttonMajCpteGle" type="button" class="btn btn-success btn-block" data-action="update_info_cpte_gle.php"><i class="fa fa-save fa-lg"></i>&nbsp;&nbsp;Enregistrer</button>
                          </div>&nbsp;
                          </div>
                      </div>
                      </form>
                </div>
            </div>
        </div>

        <div class="row">
          <div class="col-lg-6">&nbsp;</div>
        </div>  
              
        <div class="panel panel-default">
            <div class="panel-heading">
                <h4 class="panel-title">
                    <a data-toggle="collapse" data-parent="#accordion" href="#collapseMdp">Mot de passe</a>
                </h4>
            </div>
            <div id="collapseMdp" class="panel-collapse collapse">
                <div class="panel-body">
                    <form role="form" action="" method="post" id="formMajCpteMdp">
                      <div class="panel-body">
                          <div class="row">              
                              <!-- /.col-lg-6 (nested) -->
                              <div class="col-lg-6">
                                <div class="form-group">
                                    <label>Mot de passe actuel</label>
                                    <input name="mdp" id="mdp" type="password" class="form-control" placeholder="Le mot de passe actuel" autofocus="autofocus" autocomplete="off" value="" required="required" />
                                </div>
                                <div class="form-group">
                                    <label>Nouveau Mot de passe</label>
                                    <input name="mdpnew" id="mdpnew" type="password" class="form-control" placeholder="Nouveau Mot de passe" autocomplete="off" value="" required="required" />
                                </div>
                                <div class="form-group">
                                    <label>Confirmer nouveau</label>
                                    <input name="mdpnew_conf" id="mdpnew_conf" type="password" class="form-control" placeholder="Confirmer le nouveau Mot de passe" autocomplete="off" value="" required="required" />
                                </div>
                              </div>
                          </div>
                          <div class="row">
                          <div class="col-lg-4 center-block">
                              <button name="buttonMajCpteMdp" id="buttonMajCpteMdp" type="button" class="btn btn-success btn-block" data-action="update_info_cpte_mdp.php"><i class="fa fa-save fa-lg"></i>&nbsp;&nbsp;Enregistrer</button>
                          </div>&nbsp;
                          </div>
                      </div>
                      </form>
                </div>
            </div>
        </div>
        
    </div>         
  </div>
</div>
<?php 
}
?>
