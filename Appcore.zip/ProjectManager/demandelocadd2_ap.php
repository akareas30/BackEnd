<?php 
if(isset($_GET['dev'])){
	$IdDmd0 = (int)$_GET['dev'];
}

$chp = "dmd_ref, dmd_type, dmd_type_clt, dmd_clt, dmd_etat_enreg, dmd_etat_approuv";
$tb = DEMANDES." D";
$cnd = "dmd_id=$IdDmd0";

$reqLib = selections($chp,$tb,$cnd,1);
$res = $pdo->query($reqLib);
$col = $res->fetch();
$dmd_ref 		= $col['dmd_ref'];
$dmd_type 		= $col['dmd_type'];
$dmd_type_clt 	= $col['dmd_type_clt'];
$dmd_clt 		= $col['dmd_clt'];
$dmd_etat_enreg = $col['dmd_etat_enreg'];
$dmd_etat_approuv = $col['dmd_etat_approuv'];
if($dmd_etat_approuv==0){?>
<div class="row">
  <div class="col-lg-12">
      <h3 class="page-header">ENREGISTRER UNE DEMANDE DE LOCATION</h3>
  </div>
  <div class="col-lg-12">
      <h4>ETAPE 2/2: DETAILS DEMANDE: REF.: <?php echo '<span class="text-rouge">'.stripslashes($dmd_ref)."</span>&nbsp;|&nbsp;";?> CLIENT: <?php echo '<span class="text-rouge">'.stripslashes($dmd_clt).'</span>';?></h4>
  </div>
  <!-- /.col-lg-12 -->
</div>
<!-- /.row -->
<div class="row">
  <div class="col-lg-12">
      <div class="panelglobal panel-default-global">
          <div class="panel-body">
              <div class="row">
              <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">1.&nbsp;Ajouter les d&eacute;tails</div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                <form role="form" method="post" id="formAddDetDmd" action="">
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                    <input type="hidden" name="IdDmd" id="IdDmd" value="<?php echo $IdDmd0; ?>" />
                    <input type="hidden" name="typeclt" id="typeclt" value="<?php echo $dmd_type_clt; ?>" />
                    <input class="form-control" id="outilId" name="outilId" type="hidden" readonly />
                        <input class="form-control bs-autocomplete" id="liboutil" placeholder="D&eacute;signation de l'outil" type="text" data-source="get_rech_outil_locat.php" data-hidden_field_id="outilId" data-item_id="outilref_id" data-item_label="libelle" autocomplete="off" autofocus="autofocus" required="required" />
                        
                     </div>
                  </div>
                  <!--<div class="col-lg-3">
                    <div class="form-group">
                       <input type="number" class="form-control" placeholder="Qt&eacute; demand&eacute;e" name="qte" id="qte" required="required" />
                    </div>
                  </div>-->
                  <!--<div class="col-lg-3">
                    <div class="form-group input-group">
                       <span class="input-group-addon">Qt&eacute; Dispo.</span>
                        <input type="text" class="form-control" name="qtedispo" id="qtedispo" readonly="readonly" />
                     </div>
                  </div>-->
                  <div class="col-sm-2">
                    <div class="form-group">
                       <input type="number" class="form-control" placeholder="Nbre Jour" name="nbrejr" id="nbrejr" required="required" />
                    </div>
                  </div>
                  <div class="col-sm-2">
                    <div class="form-group input-group">
                       <span class="input-group-addon">PU/Jr</span>
                        <input type="text" class="form-control" name="pujr" id="pujr" readonly="readonly" />
                     </div>
                  </div>
                  <div class="col-sm-2">
                  <button class="btn btn-warning btn-block" name="ButtonAddDmdLoc" id="ButtonAddDmdLoc" data-action="put_dmd_loc.php"><i class="fa fa-plus-square fa-lg"></i>&nbsp;&nbsp;Ajouter&nbsp;</button>
                  </div>
                </div>
                <div class="row">
                  
                </div>
                  </form>
               			</div>
                    </div>
               </div>
               
               <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">2.&nbsp; Les D&eacute;tails de la demande de location</div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
							<?php 
							$chp = "dmddet_id, outilref_libelle, outilref_descrip, outilref_prixloc_part, outilref_prixloc_soc, dmddet_nbrejrs, dmddet_etat_enreg, dmddet_etat_traite";
							$tbl = DEMANDES_DET." LEFT JOIN ".OUTILS_REF." ON dmddet_outils=outilref_id";
							$cnd = "dmddet_dmdid=$IdDmd0 AND dmddet_etat_enreg=1";
							$reqDet = selections($chp,$tbl,$cnd,"dmddet_id DESC");
							$resDet = $pdo->query($reqDet);	
							?>
                            <table width="100%" class="table table-bordered table-hover" id="tb_adddmd">
                                <thead>
                                    <tr>
                                        <th align="center">#</th>
                                        <th align="left">Outil</th>
                                        <th align="center">Description</th>
                                        <th align="center">Nbre Jr</th>
                                        <th align="center">PU/Jr (FCFA)</th>
                                        <th align="center">Montant (FCFA)</th>
                                        <th align="center">&nbsp;</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php 
								$i = 0;
								$montant = 0;
								$Total = 0;
								while($col = $resDet->fetch()){
								  $dmddet_id 		 	= $col['dmddet_id'];
								  $outil_libelle 	 	= $col['outilref_libelle'];
								  $outilref_descrip		= $col['outilref_descrip'];
								  $dmddet_etat_enreg 	= $col['dmddet_etat_enreg'];
								  $outil_prix_loc_part 	= $col['outilref_prixloc_part'];
								  $outil_prix_loc_scte 	= $col['outilref_prixloc_soc'];
								  $dmddet_nbrejrs 		= $col['dmddet_nbrejrs'];
								  $dmddet_etat_traite	= $col['dmddet_etat_traite'];
								  
								  if($dmd_type_clt==0)$Prix = $outil_prix_loc_part;
								  elseif($dmd_type_clt==1)$Prix = $outil_prix_loc_scte;
								  else $Prix = "";
								  $montant = $dmddet_nbrejrs*$Prix ;
								  $i++;
								  ?>
                                    <tr id="<?php echo $dmddet_id;?>" data-dev="<?php echo $IdDmd0; ?>" class="even gradeA success">
                                        <td align="center"><?php echo $i ?></td>
                                      <td><?php echo "<strong>".$outil_libelle."</strong>";?></td>
                                        <td align="left"><?php echo nl2br($outilref_descrip); ?></td>
                                        <td align="center"><?php echo $dmddet_nbrejrs; ?></td>
                                        <td align="right"><?php echo number_format($Prix,0,'',' '); ?></td>
                                        <td align="right"><?php echo number_format($montant,0,'',' '); ?></td>
                                        <td align="center">    
                                        <?php if($dmddet_etat_traite==0){ ?>                                     
                                        <button class="btn btn-link ButtonRetirerLoc" data-toggle="tooltip" data-placement="top" data-tb="myDevisDetTb" title="Retirer <?php echo $outil_libelle; ?>"><i class="fa fa-trash-o fa-lg text-rouge"></i></button>
                                        <?php }?>
                                        </td>
                                    </tr>    
									<?php 
									//$Total = $Total+$montant;
									$Total+=$montant;
								}
									?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                      <th colspan="5" align="right">Total</th>
                                      <th align="right"><?php echo number_format($Total,0,'',' '); ?></th>
                                      <th align="center">&nbsp;</th>
                                    </tr>
                                 </tfoot>
                            </table>
                            <!-- /.table-responsive -->
                            <div class="row">
                <div class="col-lg-4 pull-right">
                  <a href="?yk=demandegestLoc&svt" class="btn btn-success btn-block"><i class="fa fa-save fa-lg"></i>&nbsp;&nbsp;Terminer&nbsp;</a>
                </div>
                </div>
               		  </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                
              </div>
          </div>
      </div>
  </div>
</div> 
<?php 
}
?>